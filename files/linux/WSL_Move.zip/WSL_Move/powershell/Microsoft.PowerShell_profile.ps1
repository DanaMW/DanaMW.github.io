function prompt {
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor yellow "$ENV:LOGNAME"
    Write-Host -NoNewLine -ForegroundColor white "@"
    Write-Host -NoNewLine -ForegroundColor yellow "WSL"
    Write-Host -NoNewline -ForegroundColor red "]"
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor cyan $(Get-Location)
    Write-Host -NoNewline -ForegroundColor red "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor cyan ">>" }
    Write-Host -NoNewline -ForegroundColor gray ":"
    return " "
}
WC "~red~[~~yellow~PowerShell Core~ ~red~][~~cyan~Microsoft.PowerShell_Profile.ps1~~red~]~~white~: Loaded Prompt~";
Get-SmallVer;
WC "~red~[~~white~Welcome to ~~cyan~Linux~~red~]~";
