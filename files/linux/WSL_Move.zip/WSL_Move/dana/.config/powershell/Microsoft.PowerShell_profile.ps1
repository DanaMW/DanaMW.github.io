function prompt {
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor yellow "$ENV:LOGNAME"
    Write-Host -NoNewline -ForegroundColor white "@"
    Write-Host -NoNewline -ForegroundColor yellow "fedora"
    Write-Host -NoNewline -ForegroundColor red "]"
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor cyan $(Get-Location)
    Write-Host -NoNewline -ForegroundColor red "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor cyan ">>" }
    Write-Host -NoNewline -ForegroundColor gray ":"
    return " "
}
WC "#red#[##yellow#PowerShell Core# #red#][##cyan#Microsoft.PowerShell_Profile.ps1##red#]##white#: Loaded Prompt#";
Get-SmallVer;
Say "Welcome to $HOSTNAME";
