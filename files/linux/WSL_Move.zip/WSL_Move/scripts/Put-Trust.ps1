$FileVersion = "Version: 0.0.2"
Say "Put-Trust" $FileVersion
Say "Setting Repository PSGallery to Trusted"
Set-PSRepository -name PSGallery -InstallationPolicy Trusted
