Write-Host "[PowerShell][Nuget_Profile.ps1]: Loaded Nothng"
$MyVer = $PSVersiontable | Select-Object -property PSVERSION | Format-Table -HideTableheader |Out-String -NoNewLine
Say "PowerShell" $PSEdition $MyVer
