function prompt {
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor yellow "$ENV:LOGNAME"
    Write-Host -NoNewline -ForegroundColor white "@"
    Write-Host -NoNewline -ForegroundColor yellow "$ENV:MYDOMAIN"
    Write-Host -NoNewline -ForegroundColor red "]"
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor white $(Get-Location)
    Write-Host -NoNewline -ForegroundColor red "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor cyan ">>" }
    Write-Host -NoNewline -ForegroundColor gray ":"
    return " "
}
WC "~darkcyan~[~~darkyellow~PowerShell Core~~darkcyan~][~~red~Microsoft.VSCode_Profile.ps1~~darkcyan~]~~white~: Loaded all Functions and Aliases~";
#Get-SmallVer;
WC "~darkcyan~[~~darkyellow~Welcome to ~~red~Ubuntu~~white~@~~red~$ENV:MYDOMAIN~~darkcyan~]~";
