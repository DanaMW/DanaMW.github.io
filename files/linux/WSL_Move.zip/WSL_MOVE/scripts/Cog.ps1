param ($Message, $Bot)

if ($Message.Text -match "!bye") {
    "/quit"
}
if ($Message.Text -match "!ident") {
    "/nickserv identify Clipper22"
    "/chanserv identify $($Message.Target) Disturbing68"
}
if ($Message.Text -match "!cycle") {
    "/part $($Message.Target)"
    "/Join $($Message.Target)"
}
if ($Message.Text -match "!getnick") {
    "/nick $($Bot.Name)"
    "/nickserv identify Clipper22"
}
++$Bot.State.Counter
#"I have seen $($Bot.State.Counter) messages."

switch ($Message.Command) {
    "join" {
        if ($Message.SenderNickname -ne $Bot.Nickname) {
            # Don't say hello to ourselves!
            "Hey there $($Message.SenderNickname), what's up?"
            "/mode $($Message.channel) +v $($Message.SenderNickname)"
        }
        if ($Message.SenderNickname -eq $Bot.Nickname) {
            "/chanserv op $($Message.channel) $Bot.Nickname"
        }
    }
}

if ($Message.Text -match "!opme") {
    "/mode $($Message.channel) +o $($Message.SenderNickname)"
}
if ($Message.Text -match "!say") {
    "I am not sure i want to mess with you right now."
}
if ($Message.Text -match "!quit") {
    "/quit :I didnt like it here anyway"
}
if ($Message.Text -match "!join") {
    $tmp = ($($Message.ArgumentString) -split ' ')[2]
    "/join $tmp"
}
if ($Message.Text -match "!part") {
    $tmp = ($($Message.ArgumentString) -split ' ')[2]
    "/part $tmp"
}
if ($Message.Text -match "!run") {
    "$($message.txt)"
}
if ($Message.Text -match "dummy") {
    "I will fuck you up asshole watch your mouth"
    "mode $($Message.SenderNickname) +Dickhead"
}
if ($Message.Text -match "ping") {
    "/notice $($Message.SenderNickname) $($Message.Line)"

}
if ($Message.Text -match "commands") {
    "!say !quit !opme !getnick !cycle !ident !bye commands !join !part !run dummy"
}
