param([string]$myargs)
$FileVersion = "0.0.3"
if ($myargs -eq "") {
    $CMD = ($env:BASE + "\tc\TOTALCMD64.exe")
    $arg1 = ("/i=" + $env:BASE + "\tc\wincmd.ini")
    & $CMD $arg1
    return
}
$TheArgs = "$myargs $args"
$CMD = ($env:BASE + "\tc\TOTALCMD64.exe")
$arg1 = ("/i=" + $env:BASE + "\tc\wincmd.ini")

& $CMD $arg1 $TheArgs
