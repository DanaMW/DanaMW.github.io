$FileVersion = "Version: 0.1.0"
[string]$MyArgs = $args
Function Stop {
    Read-Host -Prompt $args
}
$hexword = $MyArgs
$hexword = $hexword -replace " ", ""
$hexword = $hexword.trim()
$n = 0
while ($n -lt $hexword.length) {
    $hexchar1 = $hexword.substring($n, 1)
    $n++
    $hexchar2 = $hexword.substring($n, 1)
    $hexval = "$hexchar1$hexchar2"
    $hexcomp = "$hexcomp$hexval" + " "
    $n++
}
$hexcomp = $hexcomp.trimend()
$hexchars = $hexcomp -split " " | ForEach-Object {[char][byte]"0x$_"}
$hexstring = $hexchars -join ""
Say ""
Say "Out-UnHex $FileVersion"
Say ""
Say $hexstring
Say ""
