﻿$FileVersion = "0.0.7"

$command = "stop-process -Id $PID"
try {
    Invoke-Expression $command
}
Catch {
    Say -ForegroundColor RED "X $FileVersion"
    Say -ForegroundColor RED "Could not Invoke" $command
}
