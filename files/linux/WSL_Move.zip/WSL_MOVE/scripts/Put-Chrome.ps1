$FileVersion = "0.1.1"
Say "Running Put Chrome $FileVersion on $env:USERDOMAIN"
Set-Location "D:\"
Set-Location "D:\MyScripts"
if ($env:USERDOMAIN -eq "TINMAN") {
    $filetmp = ($env:BASE + "\Put-Chrome.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    $Source = "D:\MyScripts\Chrome"
    $dest = "C:\Users\Dana\AppData\Roaming\Mozilla\Firefox\Profiles\7d6fyn5r.default\chrome"
    Get-ChildItem -Path ($Source + "\*") | Sort-Object | Format-List Name | Out-file $Filetmp
    (Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | set-content $filetmp
    (Get-Content $filetmp) | Foreach-Object { $_.replace("Name : ", "") } | set-content $filetmp
    $i = 0
    $lines = (Get-Content $filetmp).count
    While ($i -lt $lines) {
        $Read = (Get-Content $filetmp)[$i]
        Copy-Item $Source\$read -Destination $dest\$read -Force
        Say "Putting $Source\$read to Firefox...Chrome\$read"
        $i++
    }
    Copy-Item D:\MyScripts\userChrome.css -Destination $dest\userChrome.css -Force
    Say "Putting D:\MyScripts\userChrome.css to Firefox...Chrome\userChrome.css"
    $i++
    Copy-Item D:\MyScripts\userContent.css -Destination $dest\userContent.css -Force
    Say "Putting D:\MyScripts\userContent.css to Firefox...Chrome\userContent.css"
    $i++
    Say "Finished Putting" $i "scripts to Firefox...Chrome"
    Set-Location $env:BASE.substring(0, 3)
    Set-Location $Env:BASE
    $FileTest = Test-Path -path $Filetmp
    if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
    Say "We are ALL DONE."
}
if ($env:USERDOMAIN -eq "TORCHLIGHT") {
    $filetmp = ($env:BASE + "\Put-Chrome.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    $Source = "D:\MyScripts\Chrome"
    $dest = "C:\Users\Dana\AppData\Roaming\Mozilla\Firefox\Profiles\cwm0sryc.default\chrome"
    Get-ChildItem -Path ($Source + "\*") | Sort-Object | Format-List Name | Out-file $Filetmp
    (Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | set-content $filetmp
    (Get-Content $filetmp) | Foreach-Object { $_.replace("Name : ", "") } | set-content $filetmp
    $i = 0
    $lines = (Get-Content $filetmp).count
    While ($i -lt $lines) {
        $Read = (Get-Content $filetmp)[$i]
        Copy-Item $Source\$read -Destination $dest\$read -Force
        Say "Putting $env:BASE\$read to Firefox...Chrome\$read"
        $i++
    }
    Copy-Item D:\MyScripts\userChrome.css -Destination $dest\userChrome.css -Force
    Say "Putting D:\MyScripts\userChrome.css to Firefox...Chrome\userChrome.css"
    $i++
    Copy-Item D:\MyScripts\userContent.css -Destination $dest\userContent.css -Force
    Say "Putting D:\MyScripts\userContent.css to Firefox...Chrome\userContent.css"
    $i++
    Say "Finished Putting" $i "scripts to Firefox...Chrome"
    Set-Location $env:BASE.substring(0, 3)
    Set-Location $Env:BASE
    $FileTest = Test-Path -path $Filetmp
    if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
    Say "We are ALL DONE."
}
