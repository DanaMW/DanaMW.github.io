rundll32.exe keymgr.dll, KRShowKeyMgr
