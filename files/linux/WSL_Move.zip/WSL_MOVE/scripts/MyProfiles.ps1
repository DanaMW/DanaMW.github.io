﻿#Profile
Import-Module posh-git
Import-Module oh-my-posh
Import-Module Get-ChildItemColor
Import-Module -Name PSReadline
Add-WindowsPSModulePath
Import-Module PsGet
function Test-Administrator {
    $user = [Security.Principal.WindowsIdentity]::GetCurrent();
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}
function Resolve-Error ($ErrorRecord = $Error[0]) {
    $ErrorRecord | Format-List * -Force
    $ErrorRecord.InvocationInfo | Format-List *
    $Exception = $ErrorRecord.Exception
    for ($i = 0; $Exception; $i++, ($Exception = $Exception.InnerException)) {
        "$i" * 80
        $Exception | Format-List * -Force
    }
}
function mklink ($target, $link) {
    New-Item -Path $link -ItemType SymbolicLink -Value $target
}
Set-Alias say Write-Host
Set-Alias sayout Write-Output
Set-Alias re Resolve-Error
Set-Alias l Get-ChildItemColor -option AllScope
Set-Alias ls Get-ChildItemColorFormatWide -option AllScope
Set-Alias la Get-Files.ps1
Set-Alias cc D:\bin\ccleaner\ccleaner64.exe
Set-Alias ssh-agent "D:\bin\git\usr\bin\ssh-agent.exe"
Set-Alias ssh-add "D:\bin\git\usr\bin\ssh-add.exe"
Set-PSReadLineKeyHandler -Key Tab -Function MenuComplete
Start-SshAgent -Quiet
$host.privatedata.ProgressForegroundColor = "white";
$host.privatedata.ProgressBackgroundColor = "red";
$ErrorView = ”CategoryView”
Write-Host "[PowerShell Core][Profile.ps1]: Loaded all Functions and Aliases"
#================================
#Microsoft.PowerShell_Profile
function prompt {
    $ESC = [char]27

    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal] $identity

    $(if (Test-Path variable:/PSDebugContext) { '[DBG]: ' }

        elseif ($principal.IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { "$ESC[91m[$ESC[36mAdmin$ESC[91m]$ESC[97m" }

        else { '' }

    ) + "$ESC[91m[" + "$ESC[33m" + "$($Env:USERNAME.substring(0, 1).toupper())" + "$($Env:USERNAME.substring(1))" + "$ESC[91m]" + "[" + "$ESC[97m" + $(Get-Location) + "$ESC[91m" + "]$ESC[97m" +

    $(if ($nestedpromptlevel -ge 1) { '>>' }) + "$ESC[33m:$ESC[97m "
    #if ($GitStatus) { Write-VcsStatus } + "$ESC[33m:$ESC[97m "
    #if ($GitStatus) { "$($GitStatus.RepoName)" + "$ESC[91m][$($GitStatus.Branch)$ESC[91m]]" + "$ESC[33m:$ESC[97m " }
}
Write-Host "[PowerShell Core][Microsoft.PowerShell_Profile.ps1]: Loaded all Functions and Aliases"
$MyVer = $PSVersiontable | Select-Object -property PSVERSION | Format-Table -HideTableheader | Out-String -NoNewLine
Say "PowerShell" $PSEdition $MyVer
Write-Host Welcome to $env:USERDOMAIN
#================================
#Microsoft.VSCode_Profile.ps1
function prompt {
    $realLASTEXITCODE = $LASTEXITCODE
    if (Test-Administrator) {
        Write-Host "[" -NoNewline -ForegroundColor red
        Write-Host "Admin" -NoNewline -ForegroundColor white
        Write-Host "]" -NoNewline -ForegroundColor red
    }
    Write-Host "[" -NoNewline -ForegroundColor red
    Write-Host "$ENV:USERNAME" -NoNewline -ForegroundColor yellow
    #Write-Host "@" -NoNewline -ForegroundColor white
    #Write-Host "$ENV:COMPUTERNAME" -NoNewline -ForegroundColor orange
    Write-Host "]" -NoNewline -ForegroundColor red
    if ($null -ne $s) {
        Write-Host "[`$s: " -NoNewline -ForegroundColor red
        Write-Host "$($s.Name)" -NoNewline -ForegroundColor Yellow
        Write-Host "]" -NoNewline -ForegroundColor red
    }
    Write-Host "[" -NoNewline -ForegroundColor red
    Write-Host $(Get-Location) -NoNewline -ForegroundColor cyan
    Write-Host "]" -NoNewline -ForegroundColor red
    Write-Host $(if ($nestedpromptlevel -ge 1) { '>>' }) -NoNewline -ForegroundColor cyan
    #if ($GitStatus) {
    #write-host "($GitStatus.RepoName)" -NoNewLine -ForegroundColor Green
    #Write-Host "[" -NoNewline -ForegroundColor red
    #write-Host "$GitStatus.Branch" -NoNewLine -ForegroundColor Green
    #Write-Host "]" -NoNewline -ForegroundColor red
    #}
    Write-Host ":" -NoNewline -ForegroundColor gray
    $global:LASTEXITCODE = $realLASTEXITCODE
    return " "
}
Write-Host "[PowerShell Core][Microsoft.VSCode_Profile.ps1]: Loaded all Functions and Aliases"
$MyVer = $PSVersiontable | Select-Object -property PSVERSION | Format-Table -HideTableheader | Out-String -NoNewLine
Say "PowerShell" $PSEdition $MyVer
Write-Host Welcome to $env:USERDOMAIN
