$FileVersion = "Version: 0.0.3"
[string]$Script = $args
[string]$ScriptElement = "Variable"
if (!($Script)) {
    $Script = Read-Host -Prompt="Enter D:\CompletePathToScriptToCheck"
    if (!($Script)) { Say "You need a script to check script variables, Doh."; break }
}
Clear-Host
Say "Find-ScriptVariables $FileVersion working on $Script"
$Errors = [System.Management.Automation.PSParseError[]] @()
[System.Management.Automation.PSParser]::Tokenize((Get-Content $Script), [ref]$Errors) | Where-Object { ($_.Type).ToString() -like $ScriptElement } | Sort-Object Content | Format-Table -AutoSize
