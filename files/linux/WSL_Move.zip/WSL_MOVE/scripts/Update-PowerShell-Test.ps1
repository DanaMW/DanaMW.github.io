﻿<#
	.SYNOPSIS
		A brief description of the Update-PowerShell.ps1 file.

	.DESCRIPTION
		Updates PowerShell scripts, modules and help

	.PARAMETER Verbose
		A description of the Verbose parameter.

	.NOTES
		My Modified Update-PowerShell.
#>
param
(
    [switch]$Verbose
)
$FileVersion = "0.0.3"
<#
$s = New-PSSession -ComputerName Server01
Get-Module -PSSession $s -ListAvailable
#>
Say "Running Update-PowerShell $FileVersion"
Say "Doing Modules"
Update-Module
# Update-Module -Module * -All -Verbose:$Verbose
Say "Doing Scripts"
Update-Script
# Update-Script -Script * -All -Verbose:$Verbose
Say "Doing Help"
Update-Help
