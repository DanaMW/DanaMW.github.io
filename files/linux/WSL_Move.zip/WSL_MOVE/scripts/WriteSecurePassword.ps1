$MyArgs = "$args"
$FileVersion = "Version: 0.0.6"
if ($MyArgs -eq "/?") {
    Say "WriteSecurePassword $FileVersion"
    Say ""
    Say "WriteSecurePassword <Optional-Path-File-To-Save>"
    Say "WriteSecurePassword alone writes the default file/location"
    Say ""
    return
}
if ($env:USERDOMAIN -eq "TINMAN") {
    Say "WriteSecurePassword $FileVersion"
    if (!($MyArgs)) {
        $MyArgs = "D:\Documents\Storage_And_Backup\Passwords\TinmanPasswordSecure.txt"
    }
    $Filetest = Test-Path -path $MyArgs
    if ($Filetest -eq $True) {
        $Random = Get-Random -Maximum 1000
        $File = ("D:\Documents\Storage_And_Backup\Passwords\TinmanPasswordSecure" + $Random + ".txt")
        Say "File Exists, Renaming to $File"
        Rename-Item -Path $MyArgs -NewName $file
    }
    Say "Writing $MyArgs"
    Say ""
    Read-Host -Credential $env:USERNAME -assecurestring | ConvertFrom-SecureString | Out-File $MyArgs
    Say ""
    Say "Completed Successfully"
    return
}
if ($env:USERDOMAIN -eq "TORCHLIGHT") {
    Say "WriteSecurePassword $FileVersion"
    if (!($MyArgs)) {
        $MyArgs = "C:\Users\dana\OneDrive\Documents\Storage_And_Backup\Passwords\TorchLightPasswordSecure.txt"
    }
    $Filetest = Test-Path -path $MyArgs
    if ($Filetest -eq $True) {
        $Random = Get-Random -Maximum 1000
        $File = ("C:\Users\dana\OneDrive\Documents\Storage_And_Backup\Passwords\TorchLightPasswordSecure" + $Random + ".txt")
        Say "File Exists, Renaming to $File"
        Rename-Item -Path $MyArgs -NewName $file
    }
    Say "Writing $MyArgs"
    Say ""
    Read-Host -Credential $env:USERNAME -assecurestring | ConvertFrom-SecureString | Out-File $MyArgs
    Say ""
    Say "Completed Successfully"
    return
}
