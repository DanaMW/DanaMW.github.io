$FileVersion = "Version: 0.0.3"
$MyArgs = $args
$OutNet = Get-NetAdapter | Where-Object { $_.Name -match "Wi-fi" -or $_.Name -match "Ethernet" -or $_.Name -match "Dualband WiFi" -and $_.name -notmatch "Microsoft Virtual WiFi Miniport Adapter" -and $_.status -eq "Up" } | Select-Object -ExpandProperty InterfaceIndex
$OutConnect = (Get-NetAdapter -InterfaceIndex $OutNet)
if ($MyArgs[0] -eq "READ") {
    Say "       Name:" ($OutConnect).name
    Say "Description:" ($OutConnect).InterfaceDescription
    Say "      Index:" $OutNet
    Say " Connection:" ($OutConnect).MediaConnectionState
    Say "CimInstance:" ($OutConnect).CimClass
    if ($MyArgs[1] -eq "ALL") {
        $OutConnect | Get-NetAdapterAdvancedProperty | Format-List *
    }
    return
}
if ($MyArgs[0] -eq "DISABLE") {
    #-InputObject <CimInstance#MSFT_NetAdapter[]> -InterfaceDescription ($OutConnect).InterfaceDescription -Name <string[]>
    Disable-NetAdapter -Name ($OutConnect).name -Confirm:$false -AsJob | Wait-Job
    return
}
if ($MyArgs[0] -eq "ENABLE") {
    Enable-NetAdapter -Name "Ethernet" -Confirm:$false -AsJob | Wait-Job
    #If ((Get-NetAdapter -Name $Aname).ifOperStatus -ne "Up") { Enable-NetAdapter -Name $Aname -Confirm:$false -AsJob | Wait-Job }
    return
}
<#
Get-NetAdapter
Get-NetIPConfiguration
Get-NetAdapter -InterfaceIndex 12 |Format-List
Get-NetAdapter | Disable-NetAdapter -WhatIf
Get-NetAdapter -InterfaceIndex 7 | Get-NetAdapterAdvancedProperty |Format-List *
Set-NetAdapterAdvancedProperty -InterfaceDescription 'Dell Wireless 1830 802.11ac' -DisplayName 'Wake On Packet' -DisplayValue 'Disabled' -WhatIf
What if: Set-NetAdapterAdvancedProperty 'Wi-Fi' -DisplayName 'Wake On Magic Packet' -DisplayValue 'Disabled'
#>
<#
If ((Get-NetAdapter -Name $Aname).ifOperStatus -ne 'Up') { Enable-NetAdapter -Name "Dual Band WiFi" -Confirm:$false }
If ((Get-NetAdapter -Name "Ethernet").Status -ne 'Up') { Enable-NetAdapter -Name "Ethernet"-Confirm:$false }
If ((Get-NetAdapter -Name 'Dual Band').LinkSpeed -lt 'Up') { Enable-NetAdapter -Name 'Dual Band'-Confirm:$false }
    {
    Get-NetAdapter | Disable-NetAdapter -Confirm:$false -AsJob | Wait-Job
    Enable-NetAdapter -Name 'Dual Band'-Confirm:$false
    Enable-NetAdapter -Name 'Ethernet' -Confirm:$false
    }
#>
