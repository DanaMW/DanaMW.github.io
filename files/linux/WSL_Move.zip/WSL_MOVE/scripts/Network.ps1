$FileVersion = "0.0.4"
$MyArgs = $args
$temp = Get-NetAdapter
$count = $temp.count
$OutNet = Get-NetAdapter | Where-Object { $_.Name -match "Wi-fi" -or $_.Name -match "Ethernet" -or $_.Name -match "WiFi" -and $_.name -notmatch "Microsoft Virtual WiFi Miniport Adapter" -and $_.status -eq "Up" } | Select-Object -ExpandProperty InterfaceIndex
WC "~white~Found~ ~darkyellow~$count~ ~white~Connections~"
$OutConnect = Get-NetAdapter -InterfaceIndex $OutNet
if ($MyArgs[0] -eq "SHOW") {
    $i = 0
    while ($i -lt $count) {
        WC "~white~-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-~"
        WC "~darkyellow~Connection~ ~cyan~$i~"
        WC "~white~-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-~"
        $tmp = ($OutConnect)[$i].name
        WC "       ~darkyellow~Name~~white~:~~cyan~ $tmp~"
        $tmp = ($OutConnect)[$i].InterfaceDescription
        WC "~darkyellow~Description~~white~:~~cyan~ $tmp~"
        $tmp = $OutNet[$i]
        WC "      ~darkyellow~Index~~white~:~~cyan~ $tmp~"
        $tmp = ($OutConnect)[$i].MediaConnectionState
        WC " ~darkyellow~Connection~~white~:~~cyan~ $tmp~"
        $tmp = ($OutConnect)[$i].CimClass
        WC "~darkyellow~CimInstance~white~:~~cyan~ $tmp~"
        WC ""
        $i++
    }
    WC "~white~-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-~"
    return
}
if ($MyArgs[0] -eq "DISABLE") {
    #-InputObject <CimInstance#MSFT_NetAdapter[]> -InterfaceDescription ($OutConnect).InterfaceDescription -Name <string[]>
    #Disable-NetAdapter -Name ($OutConnect).name -Confirm:$false -AsJob | Wait-Job
    return
}
if ($MyArgs[0] -eq "ENABLE") {
    #Enable-NetAdapter -Name "Ethernet" -Confirm:$false -AsJob | Wait-Job
    #If ((Get-NetAdapter -Name $Aname).ifOperStatus -ne "Up") { Enable-NetAdapter -Name $Aname -Confirm:$false -AsJob | Wait-Job }
    return
}
<#
Get-NetAdapter
Get-NetIPConfiguration
Get-NetAdapter -InterfaceIndex 12 |Format-List
Get-NetAdapter | Disable-NetAdapter -WhatIf
Get-NetAdapter -InterfaceIndex 7 | Get-NetAdapterAdvancedProperty |Format-List *
Set-NetAdapterAdvancedProperty -InterfaceDescription 'Dell Wireless 1830 802.11ac' -DisplayName 'Wake On Packet' -DisplayValue 'Disabled' -WhatIf
What if: Set-NetAdapterAdvancedProperty 'Wi-Fi' -DisplayName 'Wake On Magic Packet' -DisplayValue 'Disabled'
#>
<#
If ((Get-NetAdapter -Name $Aname).ifOperStatus -ne 'Up') { Enable-NetAdapter -Name "Dual Band WiFi" -Confirm:$false }
If ((Get-NetAdapter -Name "Ethernet").Status -ne 'Up') { Enable-NetAdapter -Name "Ethernet"-Confirm:$false }
If ((Get-NetAdapter -Name 'Dual Band').LinkSpeed -lt 'Up') { Enable-NetAdapter -Name 'Dual Band'-Confirm:$false }
    {
    Get-NetAdapter | Disable-NetAdapter -Confirm:$false -AsJob | Wait-Job
    Enable-NetAdapter -Name 'Dual Band'-Confirm:$false
    Enable-NetAdapter -Name 'Ethernet' -Confirm:$false
    }
#>
