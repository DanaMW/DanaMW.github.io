# The Base Form
$myForm = New-Object System.Windows.Forms.Form
$myForm.Text = "My Form Title"
$myForm.Size = New-Object System.Drawing.Size($width, $height)
$myForm.StartPosition = "CenterScreen"

# Add a Form Component
$myFormComponent = New-Object System.Windows.Forms.Button
#... Set component properties ...
$myForm.Controls.Add($myFormComponent)
#.. Add additional components to build a complete form ...
# Show Form
$myForm.Topmost = $True
$myForm.Add_Shown( {$myForm.Activate()})
[void] $myForm.ShowDialog()
<#
Each component you add should be isolated to itself and you can get/set whatever content you want there with variables.
Use the text property of the TextBox component. So for example:
#>
$myTextBox = New-Object System.Windows.Forms.TextBox
# Assign content to a string.
$myTextBox.Text = "Text Goes Here"
# Assign content to an existing variable.
$myTextBox.Text = $myString
# Store content in a variable.
$myString = $myTextBox.Text
