$infile = "D:\Downloads\Commands_PS.INFO"
$outfile = "D:\Downloads\Commands_PS.html"
[int]$Lines = 0
[int]$lines = (Get-Content $infile).count
[int]$rc = 0
While ($rc -le $lines) {
    [string]$read = (Get-Content $infile)[$rc]
    if ($null -eq $read) { break }
    $write = "<a>" + "$read" + "</a>"
    (Add-Content $outfile $write)
    $rc++
}
