[CmdLetBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$Confile,
    [Parameter(Mandatory = $false)]
    [AllowEmptyString()]
    [string]$Count,
    [Parameter(Mandatory = $false)]
    [string]$Read,
    [Parameter(Mandatory = $false)]
    [string]$Write,
    [Parameter(Mandatory = $false)]
    [string]$Section,
    [Parameter(Mandatory = $false)]
    [string]$SValue,
    [Parameter(Mandatory = $false)]
    [bool]$BValue,
    [Parameter(Mandatory = $false)]
    [string]$Sub
)
$Script:ConfigFile = $Confile
try { $Script:Config = Get-Content $Configfile -Raw | ConvertFrom-Json }
catch { Say -ForeGroundColor RED "Edit-Config $FileVersion - The file $Confile is missing!"; break }
($Config.$Write)[$Section].$Sub = [string]$SValue
$Config | ConvertTo-Json | Set-Content $ConfigFile
$Read = $Write
if (($Sub)) { $Feedback = ($Config.$Read)[$Section].$Sub }
else { $Feedback = ($Config.$Read.$Section) }
Say "$FeedBack"
<#
WORKING
MenuOptions = @();
$MenuOptions = @("One", "Two", "Three", "Four");
[int]$Count = $MenuOptions.count
$Count--
[int]$i = 0
while ($i -le $Count) {
    Say [$i] $MenuOptions[$i]
    $i++
}
$Ans = read-Host -Prompt "Menu Option"
if ($Ans -eq "Q") { break }
#>
<#
???
Say "Args0" $args[0]
Say "Args1" $args[1]
Say "Args2" $args[2]
Say "Args3" $args[3]
Say "Args4" $args[4]
Say "Args5" $args[5]
Say "Args6" $args[6]
Say "Args7" $args[7]
#read-host -Prompt "Read the lines a-hole"
$FancyLine = "~red~#=====================================================================================================#~"
WC $FancyLine
#>
