$FileVersion = "0.1.0"
[string]$MyArgs = $args
Function Stop {
    Read-Host -Prompt $args
}
[string]$hexword = [string]$MyArgs
$n = 0
while ($n -lt $hexword.length) {
    $hexchart = $hexword.substring($n, 1)
    if ($hexchart -eq "A") { $hexchar1 = 10 }
    if ($hexchart -eq "B") { $hexchar1 = 11 }
    if ($hexchart -eq "C") { $hexchar1 = 12 }
    if ($hexchart -eq "D") { $hexchar1 = 13 }
    if ($hexchart -eq "E") { $hexchar1 = 14 }
    if ($hexchart -eq "F") { $hexchar1 = 15 }
    else { [int]$hexchar1 = [int]$hexchart }
    [int]$hexval = (16 * ([int]$hexchar1))
    $n++
    $hexcharb = $hexword.substring($n, 1)
    if ($hexcharb -eq "A") { $hexchar2 = 10 }
    if ($hexcharb -eq "B") { $hexchar2 = 11 }
    if ($hexcharb -eq "C") { $hexchar2 = 12 }
    if ($hexcharb -eq "D") { $hexchar2 = 13 }
    if ($hexcharb -eq "E") { $hexchar2 = 14 }
    if ($hexcharb -eq "F") { $hexchar2 = 15 }
    else { [int]$hexchar2 = [int]$hexcharb }
    [int]$hexval = ($hexval + $hexchar2)
    [char]$hexval = ([char]$hexval)
    $hexcomp = "$hexcomp$hexval"
    $n++
    if ($n -gt $hexword.length) {
        $hexcomp = $hexcomp -replace "_", " "
        Say $hexcomp
        return
    }
}
Say ""
Say "Out-UnAscii $FileVersion"
Say ""
$hexcomp = $hexcomp -replace "_", " "
Say $hexcomp
Say ""
