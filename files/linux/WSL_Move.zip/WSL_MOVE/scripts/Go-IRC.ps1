$FileVersion = "0.1.6"
Say "Go $FileVersion Setting your location to Variable [IRC] $env:IRC"
Set-Location $env:IRC.substring(0, 3)
Set-Location $env:IRC
