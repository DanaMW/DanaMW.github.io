$coninfo = @{
    server   = "irc.dal.net"
    port     = 6667
    nick     = "Cog"
    user     = "d.meli"
    pwd      = "Clipper22"
    realname = "Dana Meli"
    hostname = "localhost.localdomain"
}

($env:BASE + "\irc-bot.ps1")
