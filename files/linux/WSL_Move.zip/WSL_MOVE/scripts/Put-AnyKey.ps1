$FileVersion = "0.0.1"
<# This will send any key to the keyboard #>
if (($args[0])) { $SKey = "$args[0]" }
$continue = $true
while ($continue) {
    if ([console]::KeyAvailable) {
        Say "Toggle with F12";
        $x = [System.Console]::ReadKey()
        switch ( $x.key) {
            F12 { $continue = $false }
        }
    }
    else {
        $wsh = New-Object -ComObject WScript.Shell
        if (!($SKey)) {
            $wsh.SendKeys('{CAPSLOCK}')
        }
        else {
            $wsh.SendKeys("$SKey")
        }
        Start-Sleep -mS 500
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($wsh) | Out-Null
        Remove-Variable wsh
    }
}
