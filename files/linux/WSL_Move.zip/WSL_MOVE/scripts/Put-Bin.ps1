$MyArgs = $args
$FileVersion = "Version: 0.1.15"
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Running Put Bin $FileVersion"
Say "Starting the put process."
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
if (!($MyArgs)) { $ans = Read-Host -Prompt "Put files in BackUp Folder? [Enter is NO (Y)es]" }
if ($ans -eq "Y" -or $MyArgs -eq "1") {
    # Copy-Item $env:BASE -Destination D:\My_BackUp_Folder -Recurse -Force
    $Filetmp = ($env:BASE + "\Put-Bin.tmp")
    $FileTest = Test-Path -path $Filetmp
    if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path $env:BASE -Attributes Directory -Name | Sort-Object | Out-File $Filetmp
    $lines = (Get-Content $filetmp).count
    $i = 0
    While ($i -lt $lines) {
        $dest = "D:\My_BackUp_Folder\bin"
        $read = (Get-Content $filetmp)[$i]
        $Dirchk = "$dest\$read"
        $FileTest = Test-Path -path $Dirchk -PathType Container
        if ($FileTest -ne $true) { New-Item -Path $dest\ -Name $read -ItemType "directory" }
        Say "Putting $env:BASE\$read to $dest\$read"
        Copy-Item $env:BASE\$read\* -Destination $dest\$read -Recurse -Force
        $i++
    }
    $filetmp = ($env:BASE + "\Put-Bin.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path ($env:BASE + "\*.*") | Sort-Object | Format-List Name | Out-File $Filetmp
    (Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
    (Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
    $i = 0
    $lines = (Get-Content $filetmp).count
    While ($i -lt $lines) {
        $dest = "D:\My_BackUp_Folder\bin"
        $Read = (Get-Content $filetmp)[$i]
        Copy-Item $env:BASE\$read -Destination $dest\$read -Force
        Say "Putting $env:BASE\$read to $dest\$read"
        $i++
    }
    $ans = ""
}
$ans = $null
Say ""
if (!($MyArgs)) { $ans = Read-Host -Prompt "Put PS1 Scripts to TorchLight? [Enter is NO (Y)es]" }
if ($ans -eq "Y" -or $MyArgs -eq "2") {
    $filetmp = ($env:BASE + "\Put-Bin.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path ($env:BASE + "\*") -Include "*.ps1" | Sort-Object | Format-List Name | Out-File $Filetmp
    (Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
    (Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
    $i = 0
    $lines = (Get-Content $filetmp).count
    While ($i -lt $lines) {
        $dest = "\\TorchLight\D\bin"
        $Read = (Get-Content $filetmp)[$i]
        Copy-Item $env:BASE\$read -Destination $dest\$read -Force
        Say "Putting $env:BASE\$read to $dest\$read"
        $i++
    }
    Say "Finished Putting" $i "PS1 scripts to" $dest
}
$ans = $null
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
if (!($MyArgs)) { $ans = Read-Host -Prompt "Put other folders in $env:BASE to TorchLight? (WITH EXEMPTIONS) [Enter is NO (Y)es]" }
if ($ans -eq "Y" -or $MyArgs -eq "3") {
    $Filetmp = ($env:BASE + "\Put-Bin.tmp")
    $FileTest = Test-Path -path $Filetmp
    if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path $env:BASE -Attributes Directory -Name | Sort-Object | Out-File $Filetmp
    $lines = (Get-Content $filetmp).count
    $i = 0
    While ($i -lt $lines) {
        $dest = "\\TorchLight\D\bin"
        $DontPut = "NO"
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "ConEmu") { $DontPut = "YES" }
        if ($read -eq "git") { $DontPut = "YES" }
        if ($read -eq "node_modules") { $DontPut = "YES" }
        if ($read -eq "uget") { $DontPut = "YES" }
        if ($read -eq "Rainmeter") { $DontPut = "YES" }
        if ($read -eq "aria2") { $DontPut = "YES" }
        if ($read -eq "hwinfo") { $DontPut = "YES" }
        if ($read -eq "tc") { $DontPut = "YES" }
        if ($read -eq "yakyak") { $DontPut = "YES" }
        if ($DontPut -eq "NO") {
            $Dirchk = "$dest\$read"
            $FileTest = Test-Path -path $Dirchk -PathType Container
            if ($FileTest -ne $true) { New-Item -Path $dest\ -Name $read -ItemType "directory" }
            Say "Putting $env:BASE\$read to $dest\$read"
            Copy-Item $env:BASE\$read\* -Destination $dest\$read -Recurse -Force
        }
        $i++
    }
    $filetmp = ($env:BASE + "\Put-Bin.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path ($env:BASE + "\*") -Include "*.ps1" | Sort-Object | Format-List Name | Out-File $Filetmp
    (Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
    (Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
    $i = 0
    $lines = (Get-Content $filetmp).count
    While ($i -lt $lines) {
        $dest = "\\TorchLight\D\bin"
        $Read = (Get-Content $filetmp)[$i]
        Copy-Item $env:BASE\$read -Destination $dest\$read -Force
        Say "Putting $env:BASE\$read to $dest\$read"
        $i++
    }
    $ans = ""
}
$ans = $null
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
if (!($MyArgs)) { $ans = Read-Host -Prompt "Put ALL ALL ALL folders in $env:BASE to TorchLight? [Enter is NO (Y)es]" }
if ($ans -eq "Y" -or $MyArgs -eq "4") {
    Read-Host -Prompt "MAKE SURE ALL SOFTWARE IN BIN IS OFF on TorchLight or you will get errors [Enter to continue]"
    Read-Host -Prompt "MAKE SURE YOUR SHUT DOWN GIT SSH SOFTWARE [Enter to continue]"
    $Filetmp = ($env:BASE + "\Put-Bin.tmp")
    $FileTest = Test-Path -path $Filetmp
    if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path $env:BASE -Attributes Directory -Name | Sort-Object | Out-File $Filetmp
    $lines = (Get-Content $filetmp).count
    $i = 0
    While ($i -lt $lines) {
        $dest = "\\TorchLight\D\bin"
        $DontPut = "NO"
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "ConEmu") { $DontPut = "YES" }
        if ($read -eq "Rainmeter") { $DontPut = "YES" }
        if ($read -eq "node_modules") { $DontPut = "YES" }
        if ($DontPut -eq "NO") {
            $Dirchk = "$dest\$read"
            $FileTest = Test-Path -path $Dirchk -PathType Container
            if ($FileTest -ne $true) { New-Item -Path $dest\ -Name $read -ItemType "directory" }
            Say "Putting $env:BASE\$read to $dest\$read"
            Copy-Item $env:BASE\$read\* -Destination $dest\$read -Recurse -Force
        }
        $i++
    }
    $filetmp = ($env:BASE + "\Put-Bin.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    Get-ChildItem -Path ($env:BASE + "\*") -Include "*.ps1" | Sort-Object | Format-List Name | Out-File $Filetmp
    (Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
    (Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
    $i = 0
    $lines = (Get-Content $filetmp).count
    While ($i -lt $lines) {
        $dest = "\\TorchLight\D\bin"
        $Read = (Get-Content $filetmp)[$i]
        Copy-Item $env:BASE\$read -Destination $dest\$read -Force
        Say "Putting $env:BASE\$read to $dest\$read"
        $i++
    }
    $ans = ""
}
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$Filetmp = ($env:BASE + "\Put-Bin.tmp")
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
Say "We are ALL DONE."
$ans = ""
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Clear the screen? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "Y" -Echo 1
if ($ans -eq "Y") { Clear-Host }
