$MyArgs = $args
$FileVersion = "0.2.2"
Say "Running Put Bin $FileVersion"
Say "Starting the put process."
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
$filetmp = ($env:BASE + "\Put-Bin.tmp")
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
Get-ChildItem -Path ($env:BASE + "\*") -Include "*.ps1" | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
While ($i -lt $lines) {
    $dest = "\\TorchLight\D\bin"
    $Read = (Get-Content $filetmp)[$i]
    Copy-Item $env:BASE\$read -Destination $dest\$read -Force
    Say "Copy $env:BASE\$read >> $dest\$read"
    $i++
}
Say "$i Files copied so far."
$dest = "\\TorchLight\D\bin\BinMenu"
$Read = "$env:BASE\BinMenu"
Say "Copy $read\*.* >> $dest"
$exclude = @('*.json', '*.ini')
Copy-Item "$read\*.*" -Exclude $exclude -Destination "$dest" -Force -Verbose
$i = ($i + 11)
Say "$i Files copied so far."
$dest = "\\TorchLight\D\bin\Delay-StartUp"
$Read = "$env:BASE\Delay-StartUp"
Say "Copy $read\*.* >> $dest"
Copy-Item "$read\*.*" -Exclude $exclude -Destination "$dest" -Force -Verbose
$i = ($i + 6)
Say "Finished copying $i files to where they belong."
$ans = $null
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$Filetmp = ($env:BASE + "\Put-Bin.tmp")
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
Say "We are ALL DONE."
$ans = ""
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Clear the screen? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "N" -Echo 1
if ($ans -eq "Y") { Clear-Host }
