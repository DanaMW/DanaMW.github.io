$FileVersion = "0.1.8"
Say "Go $FileVersion Setting your location to Software"
Set-Location "D:\"
Set-Location "D:\Software"
