$FileVersion = "Version: 0.1.6"
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Go $FileVersion Setting your location to Software"
Set-Location "D:\"
Set-Location "D:\Software"
