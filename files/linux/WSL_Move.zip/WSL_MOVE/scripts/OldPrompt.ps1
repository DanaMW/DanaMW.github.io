# Import-Module -Name MyTwitter;
function prompt {
    $(if (Test-Administrator) {
		"$ESC[91m[$ESC[36mAdmin$ESC[91m]$ESC[97m"
	}
    else { "" }
    ) + "$ESC[91m[$ESC[33m" + "$($Env:USERNAME.substring(0, 1).ToUpper())" + "$($Env:USERNAME.substring(1))" + "$ESC[91m][$ESC[97m" + $(Get-Location) + "$ESC[91m]$ESC[97m" +
    $(if ($nestedpromptlevel -ge 1) { '>>' }) + "$ESC[33m:$ESC[97m "
    return " "
}
# Get-Command -Module MyTwitter;