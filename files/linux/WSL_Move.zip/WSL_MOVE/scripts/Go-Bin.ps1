$FileVersion = "0.2.2"
Clear-Host
WC "~WHITE~Go Bin ~~RED~$FileVersion~"
WC "~WHITE~Setting your location to ...~"
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
WC "~RED~#~~darkred~======================================~~red~#~"
WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-~~RED~# ~~darkred~|~"
WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~==============================~~red~# ~~WHITE~| ~~darkred~|~"
WC "~darkred~| ~~WHITE~| ~~darkred~| ~~DARKCYAN~[~~WHITE~Welcome to your BIN folder~~DARKCYAN~] ~~darkred~| ~~WHITE~| ~~darkred~|~"
WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~==============================~~red~# ~~WHITE~| ~~darkred~|~"
WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-~~RED~# ~~darkred~|~"
WC "~RED~#~~darkred~======================================~~red~#~"
