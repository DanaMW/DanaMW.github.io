$FileVersion = "Version: 0.0.3"
Write-Output "Get-Profile $FileVersion Output"
Write-Output ""
$Profile
$Profile | Format-List -Force | Out-String| ForEach-Object {$_}
Read-Host -Prompt "[Tap Enter to Exit]"
