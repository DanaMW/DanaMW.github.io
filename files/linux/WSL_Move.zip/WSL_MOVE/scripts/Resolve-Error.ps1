<#
.SYNOPSIS
        Resolve-Error
        Created By: PowerShell Team
        Created By: Dana Meli
        Created Date: August, 2018
        Last Modified Date: August 08, 2018
.DESCRIPTION
        Parses out the error info.
.EXAMPLE
        Resolve-Error
.NOTES
        Still under development.
#>
$FileVersion = "Version: 0.0.1"
function Resolve-Error ($ErrorRecord = $Error[0]) {
    $ErrorRecord | Format-List * -Force
    $ErrorRecord.InvocationInfo |Format-List *
    $Exception = $ErrorRecord.Exception
    for ($i = 0; $Exception; $i++, ($Exception = $Exception.InnerException)) {
        "$i" * 80
        $Exception |Format-List * -Force
    }
}
