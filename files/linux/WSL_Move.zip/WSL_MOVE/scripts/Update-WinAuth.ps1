$FileVersion = "0.1.11"
Say -NoNewLine -ForeGroundColor white "Go $FileVersion Setting your location to "
Say -ForeGroundColor cyan "Github\WinAuth"
Set-Location "D:\"
Set-Location "D:\Development\GitHub\WinAuth"
Say "git fetch upstream" -Verbose
git.exe fetch upstream
Say "git merge upstream/master" -Verbose
git.exe merge upstream/master
Say "git push origin" -Verbose
git.exe push origin
#Clear-Host
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
