$FileVersion = "0.0.2"

C:\Windows\system32\lodctr.exe /R
C:\Windows\SysWOW64\lodctr.exe /R
# If you get the error "Error: Unable to rebuild performance counter setting from system backup store, error code is 2" repeat step 2.
#re-registers the computer´s performance libraries with the following
C:\Windows\System32\wbem\winmgmt.exe /RESYNCPERF
C:\Windows\SysWOW64\wbem\winmgmt.exe /RESYNCPERF


#Solution 02:
#On some websites it is requested to use the PerfStringBackup.ini located in %systemroot%\system32\. However this file do not include all performance counters. The reason here is that the PerfStringBackup.ini is created before an application added new performance counters. That means the file is never aktuell and therefore using this might cause issues with the performance counters!
#So please be carefull if you use:
#
#C:\Windows\System32\lodctr /r: perfstringbackup.ini
