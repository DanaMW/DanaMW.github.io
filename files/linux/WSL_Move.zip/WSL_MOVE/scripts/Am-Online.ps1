$FileVersion = "0.0.4"
# First we create the request.
$HTTP_Request = [System.Net.WebRequest]::Create('http://google.com')
# We then get a response from the site.
$HTTP_Response = $HTTP_Request.GetResponse()
# We then get the HTTP code as an integer.
$HTTP_Status = [int]$HTTP_Response.StatusCode
If ($HTTP_Status -eq 200) {
    Say "Am-Online $FileVersion Site is OK!";
    $myExit = 0;
}
else {
    Say "Am-Online $FileVersion The Site may be down, please check!";
    $myExit = 1;
}
# Finally, we clean up the http request by closing it.
$HTTP_Response.Close();
return $myExit
