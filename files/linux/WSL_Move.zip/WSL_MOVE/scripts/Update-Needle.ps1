$FileVersion = "0.1.27"
Say -NoNewLine -ForeGroundColor white "Go $FileVersion Setting your location to "
Say -ForeGroundColor cyan "Github\Needle"
Set-Location "D:\"
Set-Location "D:\Development\GitHub\Needle"
# Say "git fetch upstream" -Verbose
# git.exe fetch upstream
# Start-Sleep -s 2
# Say "git merge upstream/master" -Verbose
# git.exe merge upstream/master
# Start-Sleep -s 2
# Say "git push origin" -Verbose
# git.exe push origin
$ans = ""
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Do you want to run NPM? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "N" -Echo 1 -Max 2000
if ($ans -eq "Y") {
    Say "npm install"
    npm install
    Say "npm update"
    npm update
    # Say "npm run zip"
    # npm run zip
    # Move-Item -Path ./Needle.zip -Destination D:\Downloads\Needle.xpi
    LA ($env:DOWNLOADS + "\*.*")
}
<#
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Clear the screen? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "N" -Echo 1 -Max 2000
if ($Ans -eq "Y") { Clear-Host }
#>
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
