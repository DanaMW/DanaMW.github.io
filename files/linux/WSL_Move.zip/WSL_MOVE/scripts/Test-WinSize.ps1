<#
.SYNOPSIS
        Test
        Created By: Dana Meli
        Created Date: August, 2018
        Last Modified Date: March 15, 2019
.DESCRIPTION
        This script is designed to create a menu of all exe files in subfolders off a set base.
        It is designed to use an ini file created Internally.
        Also has great Settings Manager, it's companion script BinSM.ps1.
.EXAMPLE
        Test.ps1
.NOTES
        Still under development.
#>
Param([String]$Test)

$FileVersion = "0.0.1"
Say "New Test File $FileVersion"
$continue = $true
While ($continue) {
    #$height = (Get-Host).UI.RawUI.WindowSize.Height
    #$width = (Get-Host).UI.RawUI.WindowSize.Width
    #$saveW = $width
    #$saveH = $height
    #$Key = $Host.UI.RawUI.ReadKey('NoEcho, IncludeKeyUp, IncludeKeyDown')
    #if ($saveW -ne $width -or $saveH -ne $height) {
    #    Say "Window Size Height:" $height
    #    Say " Window Size Width:" $width
    #}
    #if (($Key)) { Say "  Key Press:" $Key }
    if ([console]::KeyAvailable) {
        Say "Toggle with F12";
        $x = [System.Console]::ReadKey("NoEcho").Key
        switch ( $x.key) {
            F12 { $continue = $false }
        }
    }
    else {
        $height = (Get-Host).UI.RawUI.WindowSize.Height
        $width = (Get-Host).UI.RawUI.WindowSize.Width
        Say "Window Size Height:" $height
        Say " Window Size Width:" $width
        $wsh = New-Object -ComObject WScript.Shell
        $wsh.SendKeys('{CAPSLOCK}')
        sleep 1
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($wsh) | Out-Null
        Remove-Variable wsh
    }
}
