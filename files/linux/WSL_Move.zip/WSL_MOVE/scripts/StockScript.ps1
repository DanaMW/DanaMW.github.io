﻿param([string]$myargs)
	if ($myargs -eq "")
	{
        Say
		Say 'Listing all your enviroment Variables.'
        Say 'All sorted and formatted for your pleasure.'
        Get-ChildItem Env: | Sort-Object Name | Format-Table -Wrap -AutoSize
        Say
        Say 'Complete'
		return
	}
	#$TheArgs = "$myargs $args"

    $arg1 = $myargs.substring(0,1).toupper()+$myargs.substring(1).tolower()
    $arg2 = $myargs.toupper()
    Say
    Say "Displaying the Enviroment Variable $arg1 if it exists"
    Get-ChildItem Env:"$arg2" | Format-Table -Wrap -AutoSize
