﻿<#
.SYNOPSIS
        Get-Movies
        Created By: Dana Meli
        Created Date: August, 2018
        Last Modified Date: March 21, 2021

.DESCRIPTION
        This returns a Text file of all the movies in D:\Movies.

.EXAMPLE
        Get-Movies

.NOTES
        Still under development.

#>
$FileVersion = "0.1.6"
Say "Get-Movies $FileVersion"
$Folder = "D:\Movies\*"
$Filetxt = ($env:DOWNLOADS + "\MyMoviesList.txt")
$Filetest = Test-Path -Path $Filetxt
if ($Filetest -eq $true) { Remove-Item –Path $Filetxt }
Get-ChildItem -Path $Folder -Name -Recurse | Sort-Object | Out-File $Filetxt
