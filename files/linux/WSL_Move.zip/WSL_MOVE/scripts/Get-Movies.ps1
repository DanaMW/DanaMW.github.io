﻿<#
.SYNOPSIS
        Get-Movies
        Created By: Dana Meli
        Created Date: August, 2018
        Last Modified Date: December 20, 2018
.DESCRIPTION
        This returns a Text file of all the movies in \\TorchLight\Movies.
.EXAMPLE
        Get-Movies
.NOTES
        Still under development.
#>
$FileVersion = "Version: 0.1.4"
Say "Get-Movies $FileVersion"
$Folder = "\\TorchLight\Movies\*"
$Filetxt = ($env:DOWNLOADS + "\MyMoviesList.txt")
$Filetest = Test-Path -path $Filetxt
if ($Filetest -eq $true) { Remove-Item –path $Filetxt }
Get-ChildItem -Path $Folder -Name -Recurse | Sort-Object | Out-File $Filetxt
