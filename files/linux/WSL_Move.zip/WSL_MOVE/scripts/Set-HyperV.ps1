$FileVersion = "Version: 0.0.1"
if ($MyArgs -eq "ON") {
    Say "Enabling Hyper-V" $FileVersion
    Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V –All
}

if ($MyArgs -eq "OFF") {
    Say "Disabling Hyper-V" $FileVersion
    Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V-All
}
