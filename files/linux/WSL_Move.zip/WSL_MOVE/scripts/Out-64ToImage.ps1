$MyArgs = $args
$FileVersion = "Version: 0.1.2"
[string]$64file = $MyArgs
$Filetest = Test-Path -path $64file
if ($Filetest -ne $true) {
    Say "The file you are trying to use does not exist."
    Say "The Parameter must be the full path and filename."
    Say "Out-64ToImage C:\Somepath\Somefile.txt"
    break
}
[string]$fileout = $64file.Substring(0, $64file.LastIndexOf('.'))
Say "Out-64ToImage $FileVersion Reading in base64 file $64file"
[string]$b64 = (Get-Content $64file)
$itype = ($b64 -split ",")[0]
if (($itype -match "ico") -eq "True") { $itype = ".ico" }
if (($itype -match "png") -eq "True") { $itype = ".png" }
if (($itype -match "jpg") -eq "True") { $itype = ".jpg" }
#svg+xml
if (($itype -match "svg") -eq "True") { $itype = ".svg" }
$fileout = "$fileout$itype"
$filetmp = $fileout
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Fileout }
[string]$b64 = ($b64 -split ",")[1]
Say "Out-64ToImage $FileVersion Writing out image file $fileout"
$bytes = [Convert]::FromBase64String($b64)
[IO.File]::WriteAllBytes($fileout, $bytes)
