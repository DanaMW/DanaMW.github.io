$FileVersion = "Version: 0.1.16"
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Go $FileVersion Setting your location to Github\Stylus"
Set-Location "D:\"
Set-Location "D:\Development\GitHub\stylus"
Say "git fetch upstream" -Verbose
git.exe fetch upstream
Start-Sleep -s 2
Say "git merge upstream/master" -Verbose
git.exe merge upstream/master
Start-Sleep -s 2
Say "git push origin" -Verbose
git.exe push origin
#}
$ans = ""
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Do you want to run NPM? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "N" -Echo 1
if ($ans -eq "Y") {
    Say "npm install"
    npm.cmd install
    Say "npm run update"
    npm.cmd run update
    Say "npm run zip"
    npm.cmd run zip
    Move-Item -Path ./stylus.zip -Destination D:\Downloads\stylus.xpi
    LA ($env:DOWNLOADS + "\*.*")
}
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Clear the screen? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "Y" -Echo 1
if ($Ans -eq "Y") { Clear-Host }
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
