$FileVersion = "Version: 0.0.4"
Say "Running Repair Perflib" $Fileversion
Say -ForegroundColor White "Info: Running Lodctr /R in System32"
C:\Windows\system32\lodctr.exe /R
Say ""
Say "ExitCode:" $LASTEXITCODE
if ($LASTEXITCODE -eq "0") { Say "Info: Successfully ran Lodctr in System32" }
else {
    Say -ForegroundColor "Info: ReRunning Lodctr /R in System32"
    C:\Windows\system32\lodctr.exe /R
    Say ""
    Say "ExitCode:" $LASTEXITCODE
    if ($LASTEXITCODE -eq "0") { Say "Info: Successfully ran Lodctr in System32" }
    else { Say -ForegroundColor YELLOW "Something Went Wrong, check your stupid code bitch"; return }
}
Start-Sleep -s 2
Say -ForegroundColor White "Info: Running Lodctr /R in SysWOW64"
C:\Windows\SysWOW64\lodctr.exe /R
Say ""
Say "ExitCode:" $LASTEXITCODE
if ($LASTEXITCODE -eq "0") { Say "Info: Successfully ran Lodctr in SysWOW64" }
else {
    Say -ForegroundColor WHITE "Info: ReRunning Lodctr in SysWOW64"
    C:\Windows\SysWOW64\lodctr.exe /R
    Say ""
    Say "ExitCode:" $LASTEXITCODE
    if ($LASTEXITCODE -eq "0") { Say "Info: Successfully ran Lodctr in SysWOW64" }
    else { Say -ForegroundColor YELLOW "Something Went Wrong, check your stupid code bitch"; return }
}
Start-Sleep -s 2
Say -ForegroundColor WHITE "Info: Running WinMGMT /RESYNCPERF in System32"
C:\Windows\System32\wbem\winmgmt.exe /RESYNCPERF
Say "ExitCode:" $LASTEXITCODE
if ($LASTEXITCODE -ne "0") { Say -ForegroundColor YELLOW "Something Went Wrong, check your stupid code bitch"; return }
else { Say "Info: Successfully ran Winmgmt.exe in System32" }
Start-Sleep -s 2
Say -ForegroundColor WHITE "Info: Running WinMGMT /RESYNCPERF in SysWOW64"
C:\Windows\SysWOW64\wbem\winmgmt.exe /RESYNCPERF
Say "ExitCode:" $LASTEXITCODE
if ($LASTEXITCODE -ne "0") { Say -ForegroundColor -YELLOW "Something Went Wrong, check your stupid code bitch"; return }
else { Say "Info: Successfully ran Winmgmt.exe in SysWOW64" }
