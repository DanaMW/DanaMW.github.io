$FileVersion = "Version: 0.0.2"
Say "Delete Windows Store Install Cache" $FileVersion
Remove-Item -Path "C:\Windows\SoftwareDistribution\Download\*" -Recurse -Force
