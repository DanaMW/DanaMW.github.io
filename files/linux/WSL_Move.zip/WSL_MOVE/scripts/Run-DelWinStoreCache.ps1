$FileVersion = "0.0.3"
Say "Delete Windows Store Install Cache $FileVersion"
Remove-Item -Path "C:\Windows\SoftwareDistribution\Download\*" -Recurse -Force
