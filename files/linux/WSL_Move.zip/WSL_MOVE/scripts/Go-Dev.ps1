$FileVersion = "0.1.6"
Say "Go $FileVersion Setting your location to Variable [DEV] $env:DEV"
Set-Location $env:DEV.substring(0, 3)
Set-Location $env:DEV
