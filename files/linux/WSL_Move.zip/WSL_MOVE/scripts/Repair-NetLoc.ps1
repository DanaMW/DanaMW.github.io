$FileVersion = "0.0.24"
$Con = Get-NetConnectionProfile -Name "Unidentified network" -InterfaceAlias "Ethernet" -ErrorAction SilentlyContinue;
if (!($Con)) { $Con = Get-NetConnectionProfile -InterfaceAlias "Ethernet" -ErrorAction SilentlyContinue; }
if (!($Con)) { return }
Say -NoNewLine "Repair-NetLocation $FileVersion "
Say -NoNewLine -ForeGroundColor cyan "["
Say -NoNewLine -ForeGroundColor white $Con.InterfaceAlias
Say -NoNewLine -ForeGroundColor white " is set to "
if ($Con.NetworkCategory -eq "Private") {
    Say -NoNewLine -ForeGroundColor green $Con.NetworkCategory
    Say -NoNewLine -ForeGroundColor cyan "] "
    WC "~cyan~[~~green~Network appears correct~~cyan~]~"
}
elseif ($Con.NetworkCategory -ne "Private") {
    Say -NoNewLine -ForeGroundColor red $Con.NetworkCategory
    Say -NoNewLine -ForeGroundColor cyan "] "
    Say ""
    Say -NoNewLine -ForeGroundColor cyan "["
    Say -NoNewLine -ForeGroundColor red "Setting Ethernet to Private"
    Say -NoNewLine -ForeGroundColor cyan "] "
    Set-NetConnectionProfile -InterfaceAlias $Con.InterfaceAlias -InterfaceIndex $Con.InterfaceIndex -NetworkCategory Private
    # Say -NoNewLine -ForeGroundColor cyan "["
    # Say -NoNewLine -ForeGroundColor green "Network is now correct"
    # Say -NoNewLine -ForeGroundColor cyan "] "
    # Say ""
    WC "~cyan~[~~green~Network is now correct~~cyan~]~"
    return
}
return
