$commands = {
    #OR
    While (1) {

        Say "do some work"

        $again = Read-Host "again?"
        if ($again -eq "y") {
            &$commands
        }
        else {
            Say "end"
        }
    }
}
