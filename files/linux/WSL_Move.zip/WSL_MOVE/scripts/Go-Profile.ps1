$FileVersion = "0.1.7"
Say "Go $FileVersion Setting your location to Profiles Folder"
Set-Location "C:\"
Set-Location "C:\Users\dana\Documents\PowerShell\"
