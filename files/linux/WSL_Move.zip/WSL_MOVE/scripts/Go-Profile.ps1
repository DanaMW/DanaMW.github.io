$FileVersion = "Version: 0.1.6"
Say "Go $FileVersion Setting your location to Profiles Folder"
Set-Location "C:\"
Set-Location "C:\Users\Dana\Documents\PowerShell\"
