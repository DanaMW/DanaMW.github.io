$FileVersion = "Version 0.0.3"
$DoWhat = "$args"
if (!($DoWhat)) { $DoWhat = "SHOW" }
if ($DoWhat -eq "SHOW") {
    Say "NetSH" $FileVersion
    NETSH LAN show hostednetwork
    NETSH LAN show hostednetwork setting=security
}
if ($DoWhat -eq "START") {
    Say "NetSH" $FileVersion
    NETSH WLAN start hostednetwork
    NETSH WLAN show hostednetwork
}

if ($DoWhat -eq "STOP") {
    Say "NetSH" $FileVersion
    NETSH WLAN stop hostednetwork
}
