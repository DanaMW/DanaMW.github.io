$FileVersion = "0.0.6"
Say "NetSH $FileVersion"
$MyArgs = ($args)
if (!($MyArgs)) { $MyArgs = "SHOW" }
if ($MyArgs -eq "SHOW") {
    Say "NetSH $FileVersion
    NETSH LAN show hostednetwork
    NETSH LAN show hostednetwork setting=security
}
if ($MyArgs -eq "START") {
    Say "NetSH $FileVersion
    NETSH WLAN start hostednetwork
    NETSH WLAN show hostednetwork
}

if ($MyArgs -eq "STOP") {
    Say "NetSH $FileVersion"
    NETSH WLAN stop hostednetwork
}
