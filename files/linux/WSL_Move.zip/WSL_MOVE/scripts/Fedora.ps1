$FileVersion = "0.0.4"
Say "Run Fedora $FileVersion"
wsl -d fedoraremix
