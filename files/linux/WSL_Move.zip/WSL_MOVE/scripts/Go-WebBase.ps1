$FileVersion = "0.1.7"
Say "Go $FileVersion Setting your location to " $env:WebBase
Set-Location "D:\"
Set-Location $env:WebBase
