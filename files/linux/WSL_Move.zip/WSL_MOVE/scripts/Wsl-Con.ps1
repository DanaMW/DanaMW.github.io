# This sample file demonstrates ability to use 256 colors
# in Windows subsystem for Linus started in ConEmu tab.
# TAGS: ConEmu, cygwin/msys connector, wslbridge.
ConEmuC -osverinfo > nul
if ($LASTEXITCODE -eq 2560) {
    Say "All Good"
}
else {
    Say "Windows 10 is required"
    return
}
#if "%~1" = = "-run" goto do_run
#ConEmuC -c "-new_console:d:%~dp0" "%~0" -new_console:c:h9999:C:"%LOCALAPPDATA%\lxss\bash.ico" -run
#Set-Location  "%~dp0"
#Say "H
#"%~dp0..\conemu-cyg-64.exe" --wsl -t ./wsl-boot.sh
