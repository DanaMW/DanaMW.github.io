$FileVersion = "0.1.6"
Say "Go $FileVersion Setting your location to Adult"
Set-Location $env:ADULT.substring(0, 3)
Set-Location $env:ADULT
