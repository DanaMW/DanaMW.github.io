param([string]$MyArgs)
$FileVersion = "0.0.2"
$Serv = Get-Service -Name "bluetooth*"
if ($Serv.Status -eq "Running") {
    $BT = "ON"
    Say "Bluetooth is active."
}
if ($Serv.Status -ne "Running") {
    $BT = "OFF"
    Say "Bluetooth is down."
}
if ($MyArgs -eq "ON" -and $BT -eq "OFF") {
    net start "bthserv"
    Say "Starting Bluetooth."
}
elseif ($MyArgs -eq "ON" -and $BT -eq "ON") {
    say "Bluetooth is already on."
}
elseif ($MyArgs -eq "OFF" -and $BT -eq "ON") {
    net stop "bthserv"
    Say "Stopping Bluetooth"
}
elseif ($MyArgs -eq "OFF" -and $BT -eq "OFF") {
    say "Bluetooth is already off."
}
Else { Say "All Done." }
