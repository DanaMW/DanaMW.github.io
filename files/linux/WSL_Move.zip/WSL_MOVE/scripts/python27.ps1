& C:\Py\Python27\python.exe $args
