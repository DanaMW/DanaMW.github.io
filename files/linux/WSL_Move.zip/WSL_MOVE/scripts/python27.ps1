& C:\Python27\python.exe $args
