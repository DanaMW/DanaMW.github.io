$FileVersion = "Version: 0.1.7"
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Go $FileVersion Setting your location to discord-twitter-bot"
Set-Location "D:\"
Set-Location "d:\Development\GitHub\discord-twitter-bot"
Say "git fetch upstream" -Verbose
git.exe fetch upstream
Say "git merge upstream/master" -Verbose
git.exe merge upstream/master
Say "git push origin" -Verbose
git.exe push origin
Clear-Host
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
