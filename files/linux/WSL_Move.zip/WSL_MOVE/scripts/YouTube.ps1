$FileVersion = "0.0.2"
$host.ui.RawUI.WindowTitle = "YouTube $FileVersion"
if (!($args)) {
    Say ""
    Say "Nothing entered to search for, your fired."
    Say "Waste of time complete."
    Say "Simply type the search line YOUTUBE [<something to search>]"
    Say ""
    return
}
[string]$Search = $args
if ($Search -match " ") {
    $Search = $Search.Trim().Replace(" ", "+")
}
Say "YouTube $FileVersion Searching Youtube site for $Search"
$vids = "https://www.youtube.com/results?search_query=$Search"
if ($vids) { Start-Process $vids }
