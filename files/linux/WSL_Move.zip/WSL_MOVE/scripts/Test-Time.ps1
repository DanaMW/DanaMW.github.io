$MyArgs = $args
If (($MyArgs)) {
    $sw = [Diagnostics.Stopwatch]::StartNew()
    & $MyArgs
    $sw.Stop()
    Say "Search took" $sw.Elapsed
}
