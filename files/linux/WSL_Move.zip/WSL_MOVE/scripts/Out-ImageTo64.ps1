<#
.SYNOPSIS
        Out-ImageTo64.ps1
        Created By: Dana Meli
        Created Date: August, 2018
        Last Modified Date: March 24, 2019
.DESCRIPTION
        You feed this an image file and it returns to you Base64 ready to use in a script.
.EXAMPLE
        Out-ImageTo64 -File [<FullPathToImageFile>] -OutFile [<OptionalFullPathForTextFileOut>]
.NOTES
        Still under development.
#>
Param([String]$File, [String]$OutFile)
$FileVersion = "0.1.3"
if (!($File)) {
    Say ""
    Say "Unable to find image file: $File"
    Say "Out-ImageTo64 -File [<FullPathToImageFile>] -OutFile [<OptionalFullPathForTextFileOut>]"
    Say ""
    $ErrorActionPreference = "$ErrorHold";
    break
}
$Filetest = Test-Path -path $File
if ($Filetest -ne $True) {
    Say ""
    Say "Unable to find image file: $File"
    Say "Out-ImageTo64 -File [<FullPathToImageFile>] -OutFile [<OptionalFullPathForTextFileOut>]"
    Say ""
    break
}
if (!($OutFile)) {
    [String]$extOut = $File[-4..-1] -join ""
    [String]$Outfile = $File -replace "$extOut", ".txt"
}
[String]$ext = $File[-3..-1] -join ""
[String]$uri = "data:image/$($ext);base64,"
if (!($OutFile)) {
    Say -ForegroundColor RED "OutFile Did not work out, fix this stupid shit please."
    break
}
$host.ui.RawUI.WindowTitle = "Out-ImageTo64 $FileVersion"
if ((Test-Path $OutFile)) {
    Say ""
    Say "Output file $OutFile already exists, clearing file"
    Clear-Content $OutFile
}
else {
    Say ""
    Say "Creating output file: $OutFile"
}
Say "Converting $File"
Say "Writing $OutFile"
[String]$base64 = [convert]::ToBase64String((Get-Content $File -AsByteStream))
Write-Output ($uri + $base64) >> $OutFile
Say "We are all DONE"
