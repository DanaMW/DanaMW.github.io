$FileVersion = "0.0.5"
$ESC = [char]27
<# Settings Area #>
$normalline = "$ESC[31m#=====================================================================================#$ESC[37m"
$fancyline = "$ESC[31m|$ESC[37m=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=$ESC[31m|$ESC[37m"
$titleline = "$ESC[31m#==================================<$ESC[36m[ $ESC[37mAlarm Clock $ESC[36m]$ESC[31m>==================================#$ESC[37m"
$spacerline = "$ESC[31m|                                                                                     $ESC[31m|$ESC[37m"

<# $TestT = Get-Date; Say ($TestT).DayOfWeek ($TestT).hour:($TestT).minute #>
<# Get-Date | format-table * #>
Clear-Host
Say $normalline
Say $fancyline
Say $titleline
Say $fancyline
Say $normalline
$i = 0
while ($i -le 5) { Say $spacerline ; $i++ }
Say $normalline
Say $fancyline
Say $normalline
$pop = Read-Host -Prompt "Enter To Continue"
Start-Process "pwsh.exe" -ArgumentList ($env:BASE + "\BinMenu\BinMenu.ps1") -Verb RunAs
break
if ($pop -eq "") { break }
Do {
    #Switch
    Switch (Invoke-Menu -menu $menu -clear) {
        "E" {
            FixLine
            $cmd = Read-Host -Prompt "$ESC[31m[$ESC[97mExact Command Line $ESC[31m($ESC[97mEnter to Cancel$ESC[31m)]$ESC[97m"
            if ($cmd -ne '') {
                FixLine
                if ($cmd -match "ps1") {
                    FixLine
                    $temp = $cmd -split ' '
                    $cmd = $cmd.trimstart($temp[0])
                    $cmd1 = $temp[0] -replace '.ps1', ''
                    $tmp = ".ps1"
                    $cmd1 = $($cmd1 + $tmp)
                    Start-Process "pwsh.exe" -ArgumentList "$cmd1 $cmd" -Verb RunAs
                    FixLine
                }
                else { Start-Process "$cmd" -Verb RunAs }
                FixLine
            }
            FixLine
        }
        "R" { Start-Process "pwsh.exe" -ArgumentList ($env:BASE + "\BinMenu\BinMenu.ps1") -Verb RunAs; Clear-Host; return }
        "W" { Start-Process "pwsh.exe" -ArgumentList ($env:BASE + "\BinMenu\BinMenu.ps1") -Verb RunAs; Clear-Host; return }
        "C" { FixLine; Start-Process "C:\Program Files\Microsoft VS Code\Code.exe" -Verb RunAs; FixLine }
        "P" { FixLine; Start-Process "pwsh.exe" -Verb RunAs }
        "Q" { Clear-Host; Return }
        "S" {
            FixLine
            $cmd = Read-Host -Prompt "$ESC[31m[$ESC[97mWhat script to run? $ESC[31m($ESC[97mEnter to Cancel$ESC[31m)]$ESC[97m"
            if ($cmd -ne '') {
                FixLine
                $temp = $cmd -split ' '
                $cmd = $cmd.trimstart($temp[0])
                $cmd1 = $temp[0] -replace '.ps1', ''
                $tmp = ".ps1"
                $cmd1 = $($cmd1 + $tmp)
                Start-Process "pwsh.exe" -ArgumentList "$cmd1 $cmd" -Verb RunAs
                FixLine
            }
            FixLine
        }
        "A" { Start-Process "pwsh.exe" -ArgumentList ($env:BASE + "\BinMenu\BinMenu.ps1") -Verb RunAs; Clear-Host; return }
        "I" { Start-Process "pwsh.exe" -ArgumentList ($env:BASE + "\BinMenu\BinMenu.ps1") -Verb RunAs; Clear-Host; return }
        "1" { FixLine; $Line2 = (Select-String -Pattern "1B" $Fileini); $cow = $line2 -split "="; Start-Process $cow[1] -Verb RunAs; FixLine }
        Default {
            FixLine
            Say -NoNewLine "Sorry, that is not an option. Feel free to try again."
            Start-Sleep -Milliseconds 1500
            FixLine
        }
    } #switch
} While ($True)
