$MyArgs = $args
$FileVersion = "FileVersion: 0.0.5"
Say "Run Visual Studios $FileVersion"
if ($MyArgs -eq 1) {
    Say "Running Visual Studios Installer for you now."
    Start-Process "C:\Program Files (x86)\Microsoft Visual Studio\Installer\vs_installer.exe"
}
else {
    Say "Running Visual Studios for you now."
    Start-Process "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\IDE\devenv.exe"
}
