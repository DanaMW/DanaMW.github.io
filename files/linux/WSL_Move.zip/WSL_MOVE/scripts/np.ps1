param([string]$myargs)
$FileVersion = "Version: 0.0.3"
if ($myargs -eq "") {
    $CMD = ($env:BASE + "\NPP\NotePad++.exe")
    & $CMD
    return
}
$TheArgs = "$myargs $args"
$CMD = ($env:BASE + "\NPP\NotePad++.exe")
& $CMD $TheArgs
