param([string]$myargs)
$FileVersion = "0.0.5"
if ($myargs -eq "") {
    $CMD = ($env:BASE + "/NPP/notepad++.exe")
    & $CMD
    return
}
$TheArgs = "$myargs $args"
$CMD = ($env:BASE + "/NPP/notepad++.exe")
Say "Run NotePad++ $FileVersion"
& $CMD $TheArgs
