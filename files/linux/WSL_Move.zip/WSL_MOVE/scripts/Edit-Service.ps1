$FileVersion = "0.1.4"
$host.ui.RawUI.WindowTitle = "Edit-Service $FileVersion"
If (!($args)) {
    Clear-Host
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Use EDIT-SERVICE LIST to get a list of all Services."
    Say "Pass nothing, a partial or a whole service name to search after LIST"
    Say "This will bring up a list of matching possibles."
    Say "EDIT-SERVICE LIST AnythingToMatch - Empty brings up all."
    Say "Wildcard char * is added automatically to your entry."
    Say "=-=-=-=-=-=-=-=-=-=-=-= Other Options =-=-=-=-=-=-=-=-=-=-=-"
    Say "Use EDIT-SERVICE HELP for a complete listing of all options."
    Say ""
    Read-Host -Prompt [Enter to exit]
    $Key = "EXIT"
    return
}
#
# fix this shit below. My god man Powershell is easier than this mess.
#
[string]$WhoAmI = ("\\" + $env:USERDOMAIN)
if ($args) {
    [string]$MyArgs = $args
    $Key = ($MyArgs -split " ")[0]
    $key = $Key.trim()
    $Key = $Key.ToUpper()
    [string]$Service = $MyArgs -replace $Key, ""
    $Service = $Service.TrimStart(" ")
    $Service = $Service.Trimend(" ")
}
if ($null -eq $Key) { $Key = "HELP" }
if ($Key -eq "HELP") {
    Clear-Host
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Bringing up help for you."
    Say "=-=-=-=-=-=-=-=-=-=-=-=-="
    Say " Delete: Edit-Service DELETE <Exact_Service_Name>"
    Say " Help: Edit-Service HELP (For Here) or HELP <Option>"
    Say "   List: Edit-Service LIST (For All) or LIST <Partial_Or_Full_Match>"
    Say "    New:"
    Say " Remove: (The same as DELETE)"
    Say "Restart:"
    Say " :"
    Say "Suspend:"
    Say "=-=-=-=-=-=-=-=-=-=-=-=-="
}
if ($Key -eq "LIST") {
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running" $Key.ToUpper() "on services"
    if ($null -eq $service) { [string]$service = "*" }
    else { [string]$Service = "*" + $Service + "*" }
    Say "Generating you a list of SERVICES from" $service
    Get-Service $Service
    #(Get-Service $Service | Format-List | Write-Output )
}
if ($Key -eq "DELETE" -or $Key -eq "REMOVE") {
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running" $Key.ToUpper() "on services"
    if ($null -eq $service) { return }
    Say ""
    Say "Are you SURE you want to DELETE the SERVICE $Service ?"
    $ans = Read-Host -Prompt "[Enter is No, Exit (Y)es]"
    if ($ans -eq "Y") {
        Say "Attempting to DELETE $Service from your services"
        SC.EXE $WhoAmI delete $Service
        #Remove-Service
        #Remove-Service -Name "TestService"
        #Get-Service -DisplayName "Test Service" | Remove-Service
    }
    else { return }
}
if ($Key -eq "START") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    Start-Service -DisplayName $service
    return
}
if ($Key -eq "STOP") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    Stop-Service -DisplayName $service -Force
    return
}
if ($Key -eq "RESTART") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    Restart-Service -DisplayName $service
    return
}
if ($Key -eq "NEW") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    #New-Service
    return
}
if ($Key -eq "SUSPEND") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    #Suspend-Service
    return
}
if ($Key -eq "RESUME") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    #Resume-Service
    return
}
if ($Key -eq "GET") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    #Get-Service
    return
}
if ($Key -eq "SET") {
    if ($null -eq $service) { return }
    Say "Edit-Service $FileVersion"
    Say ""
    Say "Running $Key.ToUpper() on $service"
    #Set-Service
    return
}
Say "We are all DONE."
Say " "
