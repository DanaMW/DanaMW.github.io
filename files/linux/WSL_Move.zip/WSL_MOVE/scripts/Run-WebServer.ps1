$FileVersion = "0.0.2"
$MyArgs = $args
if ($env:USERDOMAIN -ne "TorchLight") { Say "Run-Web script is designed to run on TorchLight"; break }
$FileVersion = "Version 0.0.5"
Say "Now running RunWeb $FileVersion"
Say "This is the Run Config for PoshServer. The main script is in $env:WebBase"
Set-Location "C:\"
Set-Location $Env:WebBase
Say "We will now run the start script WebControl.ps1 $env:WebBase the Web Base Folder."
if (!($MyArgs)) {
    try {
        Start-Process "pwsh.exe" -ArgumentList "($env:WebBase + '\WebControl.ps1')" -WorkingDirectory "$env:WebBase" -Verb RunAs
    }
    catch {
        Say $LastErrorCode
        Say $Error
        Start-Sleep -s 20
    }
}
else {
    try {
        Start-Process "pwsh.exe" -ArgumentList "($env:WebBase + '\WebControl.ps1')" -NoLogo -WorkingDirectory "$env:WebBase" "$MyArgs" -Verb RunAs
    }
    catch {
        Say $LastErrorCode
        Say $Error
        Start-Sleep -s 20
    }
}
