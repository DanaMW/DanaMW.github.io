$FileVersion = "Version: 0.0.2"
# Adult Directory
$MakeDir = "D:\Adult"
$DirTest = Test-Path -path $MakeDir
if (!($DirTest)) {
    Say $MakeDir "does not exist, Creating..."
    New-Item -ItemType "Directory" -Path $MakeDir
}
else { Say $MakeDir "already there, skipping." }
Set-Location $MakeDir
if ($env:USERDOMAIN -eq "TORCHLIGHT") {
    # Pictures Directory
    $MakeDir = "D:\Adult\Pictures"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Pic_in Directory
    $MakeDir = "D:\Adult\Pic_In"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Videos Directiory
    $MakeDir = "D:\Adult\Videos"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Video_In Directory
    $MakeDir = "D:\Adult\Video_In"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # xXx Directory
    $MakeDir = "D:\Adult\xXx"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Asses
    $MakeDir = "D:\Adult\Pictures\Asses"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Beach
    $MakeDir = "D:\Adult\Pictures\Beach"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Blow
    $MakeDir = "D:\Adult\Pictures\Blow"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # BodyPaint
    $MakeDir = "D:\Adult\Pictures\BodyPaint"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Celebrity
    $MakeDir = "D:\Adult\Pictures\Celebrity"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # CheerLeader
    $MakeDir = "D:\Adult\Pictures\CheerLeader"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Dresses
    $MakeDir = "D:\Adult\Pictures\Dresses"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Faces
    $MakeDir = "D:\Adult\Pictures\Faces"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Flexible
    $MakeDir = "D:\Adult\Pictures\Flexible"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Gif
    $MakeDir = "D:\Adult\Pictures\Gifs"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Legs
    $MakeDir = "D:\Adult\Pictures\Legs"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Lingerie
    $MakeDir = "D:\Adult\Pictures\Lingerie"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Nude
    $MakeDir = "D:\Adult\Pictures\Nude"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # On-All-Fours
    $MakeDir = "D:\Adult\Pictures\On-All-Fours"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # On-Her-Knees
    $MakeDir = "D:\Adult\Pictures\On-Her-Knees"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Potty
    $MakeDir = "D:\Adult\Pictures\Potty"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # SchoolGirls
    $MakeDir = "D:\Adult\Pictures\SchoolGirls"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Stewardess
    $MakeDir = "D:\Adult\Pictures\Stewardess"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    # Twins
    $MakeDir = "D:\Adult\Pictures\Twins"
    $DirTest = Test-Path -path $MakeDir
    if (!($DirTest)) {
        Say $MakeDir "does not exist, Creating..."
        New-Item -ItemType "Directory" -Path $MakeDir
    }
    else { Say $MakeDir "already there, skipping." }
    make-link -target "D:\Adult\Pic_In" -Link "D:\Downloads\NewGirls"
    make-link -target "D:\Adult\Pictures" -Link "D:\Downloads\Girls"
    make-link -target "D:\Adult\xXx" -Link "D:\Downloads\xXx"
}
if ($env:USERDOMAIN -eq "TINMAN") {
    # Pictures Directory
    $TarDir = "\\TORCHLIGHT\D\Adult\Pictures"
    $LinkDir = "D:\Adult\Pictures"
    Make-Link -Target $TarDir -Link $LinkDir
    # Pic_in Directory
    $TarDir = "\\TORCHLIGHT\D\Adult\Pic_in"
    $LinkDir = "D:\Adult\Pic_In"
    Make-Link -Target $TarDir -Link $LinkDir
    # Videos Directiory
    $TarDir = "\\TORCHLIGHT\D\Adult\Videos"
    $LinkDir = "D:\Adult\Videos"
    Make-Link -Target $TarDir -Link $LinkDir
    # Video_In Directory
    $TarDir = "\\TORCHLIGHT\D\Adult\Video_In"
    $LinkDir = "D:\Adult\Video_in"
    # Video_In Directory
    $TarDir = "\\TORCHLIGHT\D\Adult\xXx"
    $LinkDir = "D:\Adult\xXx"
    Make-Link -Target $TarDir -Link $LinkDir
    make-link -target "D:\Adult\Pic_In" -Link "D:\Downloads\NewGirls"
    make-link -target "D:\Adult\Pictures" -Link "D:\Downloads\Girls"
    make-link -target "D:\Adult\Picture\xXx" -Link "D:\Downloads\xXx"
}
# NewGirls//(alias:NewPic In)
# Girls//(alias:Adult)
# >Girls/Asses//(alias:Nice Ass)
# >Girls/Beach//(alias:Beach)
# >Girls/Blow//(alias:Blowing)
# >Girls/BodyPaint//(alias:BodyPaint)
# >Girls/Celebrity//(alias:Celebrity)
# >Girls/Cheerleader//(alias:CheerLeaders)
# >Girls/Dresses//(alias:Dresses)
# >Girls/Face//(alias:Faces)
# >Girls/Flexible//(alias:Flexible)
# >Girls/Gifs//(alias:Gifs)
# >Girls/Legs//(alias:Legs)
# >Girls/Lingerie//(alias:Lingerie)
# >Girls/Nude//(alias:Nude)
# >Girls/On-All-Fours//(alias:She's On All Fours)
# >Girls/On-Her-Knees//(alias:She's On Her Knees)
# >Girls/Potty//(alias:Piss Pot)
# >Girls/SchoolGirls//(alias:SchoolGirls)
# >Girls/Shorts//(alias:Shorts)
# >Girls/Squatting//(alias:Squatting)
# >Girls/Stewardess//(alias:Stewardess)
# >Girls/Twins//(alias:Twins)
