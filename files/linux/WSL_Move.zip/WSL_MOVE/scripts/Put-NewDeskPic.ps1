$MyArgs = "$args"
$copyDir1 = "C:\Users\Dana\Pictures\Desktop\"
$copyDir2 = "D:\Pictures\Desktop\"
# Copy $MyArgs
