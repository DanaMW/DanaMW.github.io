$Fileversion = "0.0.5"
Say "Running Set Desktop background $FileVersion"
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$filetmp = ($env:BASE + "\Put-BackGround.tmp")
$Filetest = Test-Path -path $Filetmp
if (($Filetest)) { Remove-Item -path $Filetmp }
$PicFolder = "C:\Users\Dana\Pictures\Desktop"
Get-ChildItem -Path ($PicFolder + "\*.jpg") | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
$Hold = 30000
Function Set-WallPaper ([string]$File) {
    try {
        Set-ItemProperty -path "HKCU:Control Panel\Desktop" -name WallPaper -value $File
        Say $MyTime "Setting File" $File
        Start-Sleep -s 5
        rundll32.exe user32.dll, UpdatePerUserSystemParameters , 1 , True
    }
    catch { return $false }
}
while (1) {
    $MyTime = (Get-Date -Format HH:mm:ss)
    $Rand = get-random $lines
    $MyName = (Get-Content $filetmp)[$Rand]
    $MyFile = ($PicFolder + "\$MyName")
    Set-ItemProperty -path "HKCU:Control Panel\Desktop" -name WallPaper -value $MyFile
    RUNDLL32.EXE USER32.DLL, UpdatePerUserSystemParameters , 1 , True
    Say $MyTime "Setting File" $MyFile
    #Start-Sleep -S $Hold
    $ans = Put-Pause.ps1 -Max $hold -Echo 0
    if ($ans -eq "Q") {
        $Filetest = Test-Path -path $Filetmp
        if (($Filetest)) { Remove-Item -path $Filetmp }
        return
    }
}
$Filetest = Test-Path -path $Filetmp
if (($Filetest)) { Remove-Item -path $Filetmp }

<#
[Wallpaper.Setter]::SetWallpaper( 'C:\Wallpaper.bmp', 0 )
The second argument is for the styling:
0: Tile 1: Center 2: Stretch 3: No Change

Add-Type @"
using System;
using System.Runtime.InteropServices;
using Microsoft.Win32;
namespace Wallpaper
{
   public enum Style : int
   {
       Tile, Center, Stretch, NoChange
   }
   public class Setter {
      public const int SetDesktopWallpaper = 20;
      public const int UpdateIniFile = 0x01;
      public const int SendWinIniChange = 0x02;
      [DllImport("user32.dll", SetLastError = true, CharSet = CharSet.Auto)]
      private static extern int SystemParametersInfo (int uAction, int uParam, string lpvParam, int fuWinIni);
      public static void SetWallpaper ( string path, Wallpaper.Style style ) {
         SystemParametersInfo( SetDesktopWallpaper, 0, path, UpdateIniFile | SendWinIniChange );
         RegistryKey key = Registry.CurrentUser.OpenSubKey("Control Panel\\Desktop", true);
         switch( style )
         {
            case Style.Stretch :
               key.SetValue(@"WallpaperStyle", "2") ;
               key.SetValue(@"TileWallpaper", "0") ;
               break;
            case Style.Center :
               key.SetValue(@"WallpaperStyle", "1") ;
               key.SetValue(@"TileWallpaper", "0") ;
               break;
            case Style.Tile :
               key.SetValue(@"WallpaperStyle", "1") ;
               key.SetValue(@"TileWallpaper", "1") ;
               break;
            case Style.NoChange :
               break;
         }
         key.Close();
      }
   }
}
"@

[Wallpaper.Setter]::SetWallpaper( '', 0 )
#>













# function ([string]$desktopImage)
# {
#     set-itemproperty -path "HKCU:Control Panel\Desktop" -name WallPaper -value $desktopImage
#     RUNDLL32.EXE USER32.DLL,UpdatePerUserSystemParameters ,1 ,True
# }




<#
function Test-RegistryValue {
    param (
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]$Path,
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]$Value
    )
    try {
        Get-ItemProperty -Path $Path | Select-Object -ExpandProperty $Value -ErrorAction Stop | Out-Null
        return $true
    }
    catch { return $false }
}
function set-wallPaper ([string]$desktopImage) {
    Remove-ItemProperty -path "HKCU:\Control Panel\Desktop" -name WallPaper
    for ($i = 0; $i -le 5; $i++) {
        if (Test-RegistryValue -path "hkcu:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers" -value "BackgroundHistoryPath$i" ) {
            Remove-itemproperty -path "hkcu:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers" -name "BackgroundHistoryPath$i"
        }
    }

    set-itemproperty -path "HKCU:\Control Panel\Desktop" -name WallPaper -value $desktopImage
    Sleep -seconds 5
    RUNDLL32.EXE USER32.DLL, UpdatePerUserSystemParameters , 1 , True
    Get-ItemProperty -path "HKCU:\Control Panel\Desktop"
}
#>
