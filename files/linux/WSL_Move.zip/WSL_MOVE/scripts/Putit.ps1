$MyArgs = $args
$FileVersion = "0.0.2"
# Putit
Say "Putit $FileVersion"
# Say "Trusting the repo."
# ($BASE + "\Put-Trust.ps1")
if (!($MyArgs)) {
    Say "putit <moduletoinstall>"
    break
}
Say "Finding the module $MyArgs"
Find-Module $MyArgs
Say "Installing the module $MyArgs"
Install-Module $MyArgs
