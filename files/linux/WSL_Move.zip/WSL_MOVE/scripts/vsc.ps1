param([string]$myargs)
$FileVersion = "0.0.3"
if ($myargs -eq "") {
    Write-Output " "
    Write-Output "No params on the commandlime"
    Write-Output " "
    Write-Output "Simply opening VisualStudios Code"
    Write-Output "or use: VSC or CODE [<path><filename>]"
    & "C:\Program Files\Microsoft VS Code\Code.exe"
    return
}
$TheArgs = "$myargs $args"

Write-Output "Opening your editor VisualStudios Code"
Write-Output "Use: VSC or CODE <path><filename>"
& "C:\Program Files\Microsoft VS Code\Code.exe" "$TheArgs"
