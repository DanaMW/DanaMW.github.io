$FileVersion = "Version: 0.1.25"
$MyArgs = $args
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Put Repo $FileVersion"
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$ans = $null
if (!($MyArgs)) { $ans = Put-Pause -Prompt "~darkcyan~[~~white~Put StrangeScript files into the repo?~  ~red~(~~white~Y~~red~)~~darkyellow~es~, ~red~(~~white~N~~red~)~~darkyellow~o, Enter is No~~darkcyan~]~~white~:~ " -Default "N" -Echo 1 }
if ($ans -eq "Y" -or $MyArgs -eq "1") {
    $filetmp = ($env:BASE + "\Put-Repo.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    Add-Content -Path $filetmp -Value "3"
    Add-Content -Path $filetmp -Value ($env:BASE + "\AdiIRC")
    Add-Content -Path $filetmp -Value ($env:DEV + "\GitHub\StrangeScript\StrangeScript")
    Add-Content -Path $filetmp -Value "commands.ini"
    Add-Content -Path $filetmp -Value "vars.ini"
    Add-Content -Path $filetmp -Value "menus.ini"
    Add-Content -Path $filetmp -Value "[END]"
    Add-Content -Path $filetmp -Value "4"
    Add-Content -Path $filetmp -Value ($env:BASE + "\AdiIRC\Scripts")
    Add-Content -Path $filetmp -Value ($env:DEV + "\GitHub\StrangeScript\StrangeScript\Scripts")
    Add-Content -Path $filetmp -Value "aliases1.ini"
    Add-Content -Path $filetmp -Value "aliases2.ini"
    Add-Content -Path $filetmp -Value "script1.ini"
    Add-Content -Path $filetmp -Value "script2.ini"
    Say "Running Put Repo" $FileVersion
    Say "Starting the put process."
    $i = 0
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Source = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
    $i++
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Source = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
}
$ans = $null
if (!($MyArgs)) { $ans = Put-Pause -Prompt "~darkcyan~[~~white~Put PowerShell-TuneUp files into the repo?~  ~red~(~~white~Y~~red~)~~darkyellow~es~, ~red~(~~white~N~~red~)~~darkyellow~o, Enter is No~~darkcyan~]~~white~:~ " -Default "N" -Echo 1 }
if ($ans -eq "Y" -or $MyArgs -eq "2") {
    $filetmp = ($env:BASE + "\Put-Repo.tmp")
    $Filetest = Test-Path -path $Filetmp
    if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
    Add-Content -Path $filetmp -Value "20"
    Add-Content -Path $filetmp -Value "D:\Development\GitHub\PowerShell-TuneUp"
    Add-Content -Path $filetmp -Value "Check-Prof.ps1"
    Add-Content -Path $filetmp -Value "ClearLogs.ps1"
    Add-Content -Path $filetmp -Value "Edit-Config.ps1"
    Add-Content -Path $filetmp -Value "Env.ps1"
    Add-Content -Path $filetmp -Value "Ver.ps1"
    Add-Content -Path $filetmp -Value "Convert-Script.ps1"
    Add-Content -Path $filetmp -Value "Get-Firefox.ps1"
    Add-Content -Path $filetmp -Value "Get-Files.ps1"
    Add-Content -Path $filetmp -Value "Get-SysInfo.ps1"
    Add-Content -Path $filetmp -Value "Google.ps1"
    Add-Content -Path $filetmp -Value "Reboot.ps1"
    Add-Content -Path $filetmp -Value "Remove-Empty.ps1"
    Add-Content -Path $filetmp -Value "Remove-WindowsApps.ps1"
    Add-Content -Path $filetmp -Value "Repair-Windows.ps1"
    Add-Content -Path $filetmp -Value "Run-CheckDisk.ps1"
    Add-Content -Path $filetmp -Value "Put-Pause.ps1"
    Add-Content -Path $filetmp -Value "Put-Vivaldi.ps1"
    Add-Content -Path $filetmp -Value "Put-WinSize.ps1"
    Add-Content -Path $filetmp -Value "Put-WinPosition.ps1"
    Add-Content -Path $filetmp -Value "Search.ps1"
    Add-Content -Path $filetmp -Value "[END]"
    Add-Content -Path $filetmp -Value "2"
    Add-Content -Path $filetmp -Value "D:\Development\GitHub\PowerShell-TuneUp\aSay"
    Add-Content -Path $filetmp -Value "asay.ps1"
    Add-Content -Path $filetmp -Value "Notify.ps1"
    Add-Content -Path $filetmp -Value "[END]"
    Add-Content -Path $filetmp -Value "6"
    Add-Content -Path $filetmp -Value "D:\Development\GitHub\PowerShell-TuneUp\BinMenu-windows"
    Add-Content -Path $filetmp -Value "BinMenu.json"
    Add-Content -Path $filetmp -Value "BinMenu.ps1"
    Add-Content -Path $filetmp -Value "BinMenu.lnk"
    Add-Content -Path $filetmp -Value "BinScript.ps1"
    Add-Content -Path $filetmp -Value "BinSM.ps1"
    Add-Content -Path $filetmp -Value "BinIM.ps1"
    Add-Content -Path $filetmp -Value "[END]"
    Add-Content -Path $filetmp -Value "3"
    Add-Content -Path $filetmp -Value "D:\Development\GitHub\PowerShell-TuneUp\Delay-StartUp"
    Add-Content -Path $filetmp -Value "Delay-StartUp.json"
    Add-Content -Path $filetmp -Value "Delay-StartUp.ps1"
    Add-Content -Path $filetmp -Value "DelaySM.ps1"
    Add-Content -Path $filetmp -Value "[END]"
    Say "Running Put Repo" $FileVersion
    Say "Starting the put process."
    $i = 0
    $Source = $env:BASE
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
    $i++
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
    $i++
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
    $i++
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
    $i++
    $read = (Get-Content $filetmp)[$i]
    $count = $read; $i++
    $read = (Get-Content $filetmp)[$i]
    $Dest = $read; $i++
    $j = 1
    While ($j -le $count) {
        $read = (Get-Content $filetmp)[$i]
        if ($read -eq "[END]") { $j = ($count + 1) }
        Say "Putting $Source\$read to $dest\$read"
        Copy-Item $Source\$read -Destination $dest\$read -Force
        $i++
        $j++
    }
}
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$Filetmp = ($env:BASE + "\Put-Repo.tmp")
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
Say "We are ALL DONE."
$ans = ""
$ans = Put-Pause -Prompt "~darkcyan~[~~darkyellow~Clear the screen? ~~red~(~~white~Y~~red~/~~white~N~~red~)~~darkcyan~]~~white~:~ " -Default "N" -Echo 1
if ($ans -eq "Y") { Clear-Host }
$ans = ""
