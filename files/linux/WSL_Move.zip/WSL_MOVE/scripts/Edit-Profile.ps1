$FileVersion = "0.1.11"
Say "Edit-Profile $FileVersion"
if ($env:SHELL -eq "/bin/bash") {
    Say "Linux was found"
    #$Edit = "Code"
    #$Prof1 = "/home/dana/.config/powershell/profile.ps1"
    #$Prof2 = "/home/dana/.config/powershell/Microsoft.PowerShell_profile.ps1"
    #$Prof3 = "/home/dana/.config/powershell/Microsoft.VSCode_profile.ps1"
    #$AllProfs = "$Prof1 $Prof2 $Prof3"
    #code $AllProfs
    code "/home/dana/.config/powershell/profile.ps1"
    code "/home/dana/.config/powershell/Microsoft.PowerShell_profile.ps1"
    code "/home/dana/.config/powershell/Microsoft.VSCode_profile.ps1"
}
elseif ($env:OS -eq "Windows_NT") {
    Say "Windows was found"
    $Edit = "C:\Program Files\Microsoft VS Code\Code.exe"
    $Prof1 = ($env:HOME + "\Documents\PowerShell\profile.ps1")
    $Prof2 = ($env:HOME + "\Documents\PowerShell\Microsoft.PowerShell_profile.ps1")
    $Prof3 = ($env:HOME + "\Documents\PowerShell\Microsoft.VSCode_profile.ps1")
    $AllProfs = "$Prof1 $Prof2 $Prof3"
    Start-Process -FilePath $edit -ArgumentList $AllProfs -Verb RunAs | Out-Null
}
else {
    Say "doh"
    Say "Fix this shit, it didn't detect an OS."
    break
}
<#
profile = @('
Import-Module posh-git;
Import-Module oh-my-posh;
Import-Module Get-ChildItemColor;
Import-Module -Name PSReadline;
Import-Module PsGet;
# Add-WindowsPSModulePath;
function Test-Administrator {
    $user = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}
function Resolve-Error ($ErrorRecord = $Error[0]) {
    $ErrorRecord | Format-List * -Force
    $ErrorRecord.InvocationInfo | Format-List *
    $Exception = $ErrorRecord.Exception
    for ($i = 0; $Exception; $i++, ($Exception = $Exception.InnerException)) {
        $Exception | Format-List * -Force
        "$i" * 80
    }
}
function Write-Color($message = "") {
    [string]$pipedMessage = @($Input)
    if (!$message) {
        if ( $pipedMessage ) {
            $message = $pipedMessage
        }
    }
    if ( $message ) {
        $colors = @("black", "blue", "cyan", "darkblue", "darkcyan", "darkgray", "darkgreen", "darkmagenta", "darkred", "darkyellow", "gray", "green", "magenta", "red", "white", "yellow");
        $defaultFGColor = $host.UI.RawUI.ForegroundColor
        $CurrentColor = $defaultFGColor
        $message = $message.split("~")
        foreach ( $string in $message ) {
            if ( $colors -contains $string.Tolower() -and $CurrentColor -eq $defaultFGColor ) { $CurrentColor = $string }
            else {
                Write-Host -NoNewline -f $CurrentColor $string
                $CurrentColor = $defaultFGColor
            }
        }
        Write-Host
    }
}
function Write-ColorPrompt($message = "") {
    [string]$pipedMessage = @($Input)
    if (!$message) {
        if ( $pipedMessage ) {
            $message = $pipedMessage
        }
    }
    if ( $message ) {
        $colors = @("black", "blue", "cyan", "darkblue", "darkcyan", "darkgray", "darkgreen", "darkmagenta", "darkred", "darkyellow", "gray", "green", "magenta", "red", "white", "yellow");
        $defaultFGColor = $host.UI.RawUI.ForegroundColor
        $CurrentColor = $defaultFGColor
        $message = $message.split("~")
        foreach ( $string in $message ) {
            if ( $colors -contains $string.Tolower() -and $CurrentColor -eq $defaultFGColor ) { $CurrentColor = $string }
            else {
                Write-Host -NoNewline -f $CurrentColor $string
                $CurrentColor = $defaultFGColor
            }
        }
        Write-Host -NoNewline
    }
}
Function Get-SmallVer {
    $MyVer = $PSVersiontable | Select-Object -Property PSVERSION | Format-Table -HideTableheader | Out-String -NoNewline
    return WC "~darkcyan~[~~darkyellow~PowerShell $PSEdition $MyVer~~darkcyan~]~~white~ ~"
}
Set-Alias ghost Run-Ghost.ps1;
Set-Alias say Write-Host;
Set-Alias sayout Write-Output;
Set-Alias re Resolve-Error;
Set-Alias ge Get-Error;
Set-Alias l Get-ChildItemColor -Option AllScope;
Set-Alias ls Get-ChildItemColorFormatWide -Option AllScope;
Set-Alias la Get-Files.ps1;
Set-Alias cc D:\bin\ccleaner\ccleaner64.exe;
Set-Alias whois "D:\bin\wscc\SysInternals Suite\WhoIs64.exe";
Set-Alias wc Write-Color;
Set-Alias wcp Write-ColorPrompt;
Set-Alias ClearRecycle Clear-RecycleBin;
Set-Alias ssh-agent "D:\bin\git\usr\bin\ssh-agent.exe";
Set-Alias ssh-add "D:\bin\git\usr\bin\ssh-add.exe";
Set-Alias wget Invoke-WebRequest;
Set-Alias mods Get-InstalledModule;
Set-Variable -Name BASE -Value D:\bin -Scope Global;
Set-Variable -Name ShellSpec -Value 'C:\Program Files\PowerShell\7\pwsh.exe' -Scope Global;
Set-Variable -Name UserModuleBasePath -Value 'C:\Users\dana\Documents\PowerShell\Modules' -Scope Global;
$agent_is_running = Get-Process | Where-Object { $_.ProcessName -like "ssh-agent*" };
if (!($agent_is_running)) { Start-SshAgent -Quiet; };
Set-PSReadlineKeyHandler -Key Tab -Function MenuComplete;
$host.privatedata.ProgressForegroundColor = "white";
$host.privatedata.ProgressBackgroundColor = "red";
# $host.UI.RawUI.BackgroundColor = “Black”;
$Host.UI.RawUI.ForegroundColor = “Gray”;
$Global:GetChildItemColorVerticalSpace = 0;
$Env:POWERSHELL_UPDATECHECK = 'GA';
# $ErrorView = 'CategoryView';
$Errorview = 'ConciseView';
D:\bin\repair-netloc.ps1;
WC "~darkcyan~[~~darkyellow~PowerShell Core~~darkcyan~][~~red~Profile.ps1~~darkcyan~]~~white~: Loaded all Functions and Aliases~";
')
Microsoft.PowerShell_profile = @('
function prompt {
    if ((Test-Administrator)) {
        Write-Host -NoNewline -ForegroundColor darkcyan "["
        Write-Host -NoNewline -ForegroundColor yellow "Admin"
        Write-Host -NoNewline -ForegroundColor darkcyan "]"
    }
    Write-Host -NoNewline -ForegroundColor darkcyan "["
    Write-Host -NoNewline -ForegroundColor red "$ENV:USERNAME"
    Write-Host -NoNewline -ForegroundColor darkcyan "]"
    Write-Host -NoNewline -ForegroundColor darkcyan "["
    Write-Host -NoNewline -ForegroundColor white $(Get-Location)
    Write-Host -NoNewline -ForegroundColor darkcyan "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor white ">>" }
    Write-Host -NoNewline -ForegroundColor white ":"
    return " "
}
WC "~darkcyan~[~~darkyellow~PowerShell Core~~darkcyan~][~~red~Microsoft.PowerShell_Profile.ps1~~darkcyan~]~~white~: Loaded Prompt~";
Get-SmallVer;
WC "~darkcyan~[~~white~Welcome to ~~red~$env:USERDOMAIN~~darkcyan~]~~white~ ~";
')
Microsoft.VSCode_profile = @('
function prompt {
    if ((Test-Administrator)) {
        Write-Host -NoNewline -ForegroundColor darkcyan "["
        Write-Host -NoNewline -ForegroundColor yellow "Admin"
        Write-Host -NoNewline -ForegroundColor darkcyan "]"
    }
    Write-Host -NoNewline -ForegroundColor darkcyan "["
    Write-Host -NoNewline -ForegroundColor red "$ENV:USERNAME"
    Write-Host -NoNewline -ForegroundColor darkcyan "]"
    Write-Host -NoNewline -ForegroundColor darkcyan "["
    Write-Host -NoNewline -ForegroundColor white $(Get-Location)
    Write-Host -NoNewline -ForegroundColor darkcyan "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor white ">>" }
    Write-Host -NoNewline -ForegroundColor gray ":"
    return " "
}
WC "~darkcyan~[~~darkyellow~PowerShell Core~~darkcyan~][~~red~Microsoft.VSCode_Profile.ps1~~darkcyan~]~~white~: Loaded all Functions and Aliases~";
Get-SmallVer;
WC "~darkcyan~[~~white~Welcome to ~~red~$env:USERDOMAIN~~darkcyan~]~";
')
#>
