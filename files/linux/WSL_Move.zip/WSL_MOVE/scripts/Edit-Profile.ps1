$FileVersion = "Version: 0.1.6"
Say "Edit-Profile $FileVersion"
$Edit = "C:\Program Files\Microsoft VS Code\Code.exe"
$Prof1 = ($env:HOME + "\Documents\PowerShell\profile.ps1")
$Prof2 = ($env:HOME + "\Documents\PowerShell\Microsoft.PowerShell_profile.ps1")
$Prof3 = ($env:HOME + "\Documents\PowerShell\Microsoft.VSCode_profile.ps1")
$AllProfs = "$Prof1 $Prof2 $Prof3"
Start-Process -FilePath $edit -ArgumentList $AllProfs -Verb RunAs | Out-Null
<#
profile = @('
Import-Module posh-git;
Import-Module oh-my-posh;
Import-Module Get-ChildItemColor;
Import-Module -Name PSReadline;
Add-WindowsPSModulePath;
Import-Module PsGet;
function Test-Administrator {
    $user = [Security.Principal.WindowsIdentity]::GetCurrent()
    (New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}
function Resolve-Error ($ErrorRecord = $Error[0]) {
    $ErrorRecord | Format-List * -Force
    $ErrorRecord.InvocationInfo | Format-List *
    $Exception = $ErrorRecord.Exception
    for ($i = 0; $Exception; $i++, ($Exception = $Exception.InnerException)) {
        $Exception | Format-List * -Force
        "$i" * 80
    }
}
function Write-Color($message = "") {
    [string]$pipedMessage = @($Input)
    if (!$message) {
        if ( $pipedMessage ) {
            $message = $pipedMessage
        }
    }
    if ( $message ) {
        $colors = @("black", "blue", "cyan", "darkblue", "darkcyan", "darkgray", "darkgreen", "darkmagenta", "darkred", "darkyellow", "gray", "green", "magenta", "red", "white", "yellow");
        $defaultFGColor = $host.UI.RawUI.ForegroundColor
        $CurrentColor = $defaultFGColor
        $message = $message.split("~")
        foreach ( $string in $message ) {
            if ( $colors -contains $string.Tolower() -and $CurrentColor -eq $defaultFGColor ) { $CurrentColor = $string }
            else {
                write-host -NoNewLine -f $CurrentColor $string
                $CurrentColor = $defaultFGColor
            }
        }
        write-host
    }
}
function Write-ColorPrompt($message = "") {
    [string]$pipedMessage = @($Input)
    if (!$message) {
        if ( $pipedMessage ) {
            $message = $pipedMessage
        }
    }
    if ( $message ) {
        $colors = @("black", "blue", "cyan", "darkblue", "darkcyan", "darkgray", "darkgreen", "darkmagenta", "darkred", "darkyellow", "gray", "green", "magenta", "red", "white", "yellow");
        $defaultFGColor = $host.UI.RawUI.ForegroundColor
        $CurrentColor = $defaultFGColor
        $message = $message.split("~")
        foreach ( $string in $message ) {
            if ( $colors -contains $string.Tolower() -and $CurrentColor -eq $defaultFGColor ) { $CurrentColor = $string }
            else {
                write-host -NoNewLine -f $CurrentColor $string
                $CurrentColor = $defaultFGColor
            }
        }
        write-host -NoNewline
    }
}
Function Get-SmallVer {
    $MyVer = $PSVersiontable | Select-Object -property PSVERSION | Format-Table -HideTableheader | Out-String -NoNewLine
    return WC "~red~[~~white~PowerShell $PSEdition $MyVer~~red~]~"
}
Set-Alias ghost Run-Ghost.ps1;
Set-Alias say Write-Host;
Set-Alias sayout Write-Output;
Set-Alias re Resolve-Error;
Set-Alias l Get-ChildItemColor -option AllScope;
Set-Alias ls Get-ChildItemColorFormatWide -option AllScope;
Set-Alias la Get-Files.ps1;
Set-Alias cc D:\bin\ccleaner\ccleaner64.exe;
Set-Alias whois "D:\bin\wscc\SysInternals Suite\WhoIs64.exe"
Set-Alias wc Write-Color;
Set-Alias wcp Write-ColorPrompt;
Set-Alias ssh-agent "D:\bin\git\usr\bin\ssh-agent.exe";
Set-Alias ssh-add "D:\bin\git\usr\bin\ssh-add.exe";
$agent_is_running = Get-Process | Where-Object { $_.ProcessName -like "ssh-agent*" };
if (!($agent_is_running)) { Start-SshAgent -Quiet; };
Set-PSReadlineKeyHandler -Key Tab -Function MenuComplete;
$host.privatedata.ProgressForegroundColor = "white";
$host.privatedata.ProgressBackgroundColor = "red";
$host.UI.RawUI.BackgroundColor = “Black”;
$Host.UI.RawUI.ForegroundColor = “Gray”;
$Global:GetChildItemColorVerticalSpace = 0
$ErrorView = ”CategoryView”;
WC "~red~[~~yellow~PowerShell Core~~red~][~~cyan~Profile.ps1~~red~]~~white~: Loaded all Functions and Aliases~";
')
Microsoft.PowerShell_profile = @('
function prompt {
    if ((Test-Administrator)) {
        Write-Host -NoNewline -ForegroundColor red "["
        Write-Host -NoNewline -ForegroundColor white "Admin"
        Write-Host -NoNewline -ForegroundColor red "]"
    }
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor yellow "$ENV:USERNAME"
    Write-Host -NoNewline -ForegroundColor red "]"
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor cyan $(Get-Location)
    Write-Host -NoNewline -ForegroundColor red "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor cyan ">>" }
    Write-Host -NoNewline -ForegroundColor gray ":"
    return " "
}
WC "~red~[~~yellow~PowerShell Core~~red~][~~cyan~Microsoft.PowerShell_Profile.ps1~~red~]~~white~: Loaded Prompt~";
Get-SmallVer;
WC "~red~[~~white~Welcome to ~~cyan~$env:USERDOMAIN~~red~]~";
')
Microsoft.VSCode_profile = @('
function prompt {
    if ((Test-Administrator)) {
        Write-Host -NoNewline -ForegroundColor red "["
        Write-Host -NoNewline -ForegroundColor white "Admin"
        Write-Host -NoNewline -ForegroundColor red "]"
    }
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor yellow "$ENV:USERNAME"
    Write-Host -NoNewline -ForegroundColor red "]"
    Write-Host -NoNewline -ForegroundColor red "["
    Write-Host -NoNewline -ForegroundColor cyan $(Get-Location)
    Write-Host -NoNewline -ForegroundColor red "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor cyan ">>" }
    Write-Host -NoNewline -ForegroundColor gray ":"
    return " "
}
WC "~red~[~~yellow~PowerShell Core~~red~][~~cyan~Microsoft.VSCode_Profile.ps1~~red~]~~white~: Loaded all Functions and Aliases~";
Get-SmallVer;
WC "~red~[~~white~Welcome to ~~cyan~$env:USERDOMAIN~~red~]~";
')
#>
