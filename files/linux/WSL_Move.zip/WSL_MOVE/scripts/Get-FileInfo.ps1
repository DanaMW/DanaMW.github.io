param([string]$File, [string]$Info)
$FileVersion = "Version: 0.0.4"
if (!($File)) {
    $File = Read-Host -Prompt "Enter a complete path-to-filename for info"
    if (!($File)) {
        Say "Include -File [<FullPathFileName>]"
        return
    }
    $Info = Read-Host -Prompt "INFO parameter [Enter for None]"
}
if ($Info -eq "All") {
    Say "FileInfo $FileVersion Output"
    $(Get-Item $File) | Format-List
    Say ""
    Say ".........[Name]:" $(Get-Item $File).Name
    Say ".....[FullName]:" $(Get-Item $File).FullName
    Say ".....[Basename]:" $(Get-Item $File).Basename
    Say "....[Extension]:" $(Get-Item $File).Extension
    Say "[DirectoryName]:" $(Get-Item $File).DirectoryName
    Say ""

}
if ($Info -ne "") { $(Get-Item $File).$Info }
else { $(Get-Item $File) }
