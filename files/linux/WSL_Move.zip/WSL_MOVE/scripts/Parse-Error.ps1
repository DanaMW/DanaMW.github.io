<#
.SYNOPSIS
        Parse-Error
        Created By: Dana Meli
        Created Date: August, 2018
        Last Modified Date: August 08, 2018
.DESCRIPTION
        Parses out the library info.
.EXAMPLE
        Parse [<variable>]  (without any quotes for normal variables)
        Parse [<'$variable'>] (with single quotes for variables from your "Variable:" drive)
.NOTES
        Still under development.
#>
param([string]$Parser)
$FileVersion = "Version: 0.0.1"
$host.ui.RawUI.WindowTitle = "Parser " + $FileVersion
if ($myargs -eq "") {
    return
}
$MyArgs = "$Parser$args"

$($error) | Format-List -Expand Both -Force | Format-Table -Wrap | Out-String -Stream
#| Write-Output
#Format-List -Force
#Format-Table -Force
