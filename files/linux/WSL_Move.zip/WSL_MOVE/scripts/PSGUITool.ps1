#################################################### Functions #######################################################


############################################## AD Info function

function ADInfo {

    $Server = $InputBox.text;

    If ($Server) {
        # Testing connection
        If (!(Test-Connection -Cn $Server -BufferSize 16 -Count 1 -ea 0 -Quiet)) {
            Write-Warning   "Failed to connect to $Server"
            $ErrorMsg = "Failed to connect to $Server"
            $outputBox.text = $ErrorMsg
        }
        Else {
            $outputBox.text = "Gathering AD info - Please wait...." | Out-String
            $DCInfo = @()

            # Query for DC info
            $dcin = (Get-ADDomainController -Server $Server)

            # Adding properties to object
            $DCObject1 = New-Object PSCustomObject
            $DCObject1 | Add-Member -Type NoteProperty -Name "Domain Controller" -Value $dcin.name
            $DCObject1 | Add-Member -Type NoteProperty -Name "Enabled" -Value $dcin.enabled
            $DCObject1 | Add-Member -Type NoteProperty -Name "Ipv4Address" -Value $dcin.ipv4address
            $DCObject1 | Add-Member -Type NoteProperty -Name "Domain" -Value $dcin.domain
            $DCObject1 | Add-Member -Type NoteProperty -Name "Forest" -Value $dcin.forest
            $DCObject1 | Add-Member -Type NoteProperty -Name "Global Catalog" -Value $dcin.isglobalcatalog
            $DCObject1 | Add-Member -Type NoteProperty -Name "LDAP Port" -Value $dcin.ldapport
            $DCObject1 | Add-Member -Type NoteProperty -Name "SSL Port" -Value $dcin.sslport
            $DCObject1 | Add-Member -Type NoteProperty -Name "Operating system" -Value $dcin.operatingsystem
            $DCObject1 | Add-Member -Type NoteProperty -Name "Site" -Value $dcin.Site

            # Adding object to first array
            $DCInfo += $DCObject1

            If ($DCINFO) {
                $DCINFO = $DCInfo | Out-String
                $outputBox.text = $DCInfo
            }
            Else {
                $TestResult = "Failed to gather information"
                $outputBox.text = $TestResult
            }
        }
    }
    Else {

        $TestResult = "Server name has not been provided"
        $outputBox.text = $TestResult

    }
}



############################################## OS Info function

function OSInfo {

    $Server = $InputBox.text;

    If ($Server) {
        # Testing connection
        If (!(Test-Connection -Cn $Server -BufferSize 16 -Count 1 -ea 0 -Quiet)) {
            Write-Warning   "Failed to connect to $Server"
            $ErrorMsg = "Failed to connect to $Server"
            $outputBox.text = $ErrorMsg
        }
        Else {
            $outputBox.text = "Gathering OS info - Please wait...." | Out-String
            $DCSystem = @()

            # Query for DC info
            $ntds = ((Get-Service -name ntds -ComputerName $server).status)
            $netlogon = ((Get-Service -name netlogon -ComputerName $server).status)
            $boot = Invoke-Command $Server -scriptblock { [Management.ManagementDateTimeConverter]::ToDateTime((Get-WmiObject Win32_OperatingSystem).LastBootUpTime) | Select-Object -expandproperty datetime }

            # Get OS details using WMI query
            $os = Get-WmiObject win32_operatingsystem -ComputerName $Server | Select-Object LastBootUpTime, LocalDateTime, organization, Caption, OSArchitecture

            # Get bootup time and local date time
            $LastBootUpTime = [Management.ManagementDateTimeConverter]::ToDateTime(($os).LastBootUpTime)
            $LocalDateTime = [Management.ManagementDateTimeConverter]::ToDateTime(($os).LocalDateTime)

            # Calculate uptime - this is automatically a timespan
            $up = $LocalDateTime - $LastBootUpTime
            $uptime = "$($up.Days) days, $($up.Hours)h, $($up.Minutes)mins"

            # Get computer system details
            $ComputerSystemInfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $Server

            $DomainQuery = $ComputerSystemInfo.domain
            $nl = Invoke-Command $server -scriptblock { param($domainquery)nltest.exe /sc_query:$domainquery } -ArgumentList $DomainQuery | Where-Object { $_ -match "Trusted DC Name" }
            $securechannel = $nl.Substring(18)

            # Use switch to determine machine type
            switch ($ComputerSystemInfo.Model) {
                # Check for Hyper-V Machine Type
                "Virtual Machine" { $MachineType = "VM" }

                # Check for VMware Machine Type
                "VMware Virtual Platform" { $MachineType = "VM" }

                # Check for Oracle VM Machine Type
                "VirtualBox" { $MachineType = "VM" }

                # Check for Oracle VM Machine Type
                "HVM domU" { $MachineType = "Xen" }

                # Otherwise it is a physical Box
                default { $MachineType = "Physical" }
            }

            # Adding properties to object
            $DCObject2 = New-Object PSCustomObject

            # Checking network adapters and their IP address
            $NetAdapters = Get-WmiObject Win32_NetworkAdapterConfiguration -ComputerName $Server -Namespace "root\CIMV2" | Where-Object { $_.IPEnabled -eq "True" }

            ForEach ($Item in $NetAdapters) {
                $NetAdapName = $Item.Description
                $DCObject2 | Add-Member -Type NoteProperty -Name "$NetAdapName" -Value $Item.IPAddress[0]
            }

            # Checking memory and cpu usage and C: drive free space
            $PhysicalRAM = (Get-WMIObject -class Win32_PhysicalMemory -ComputerName $server | Measure-Object -Property capacity -Sum | ForEach-Object { [Math]::Round(($_.sum / 1GB), 2) })
            $PhysicalRAM = ("$PhysicalRAM" + " GB")
            $Mem = (Get-WmiObject -Class win32_operatingsystem -ComputerName $Server | Select-Object @{Name = "MemoryUsage"; Expression = { � { 0:N2 }� -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory) * 100) / $_.TotalVisibleMemorySize) } }).MemoryUsage
            $Mem = ("$Mem" + " %")
            $Cpu = (Get-WmiObject win32_processor -ComputerName $Server | Measure-Object -property LoadPercentage -Average | Select-Object Average).Average
            $Cpu = ("$Cpu" + " %")
            $FreeSpace = (Get-WmiObject win32_logicaldisk -ComputerName $Server | Where-Object { $_.deviceID -eq "C:" } | Select-Object @{n = "FreeSpace"; e = { [math]::Round($_.FreeSpace / 1GB, 2) } }).freespace
            $FreeSpace = ("$FreeSpace" + " GB")
            $DiskName = (Get-WmiObject win32_logicaldisk -ComputerName $Server | Where-Object { $_.deviceID -eq "C:" }).deviceID
            $DiskName = ("$DiskName" + " drive free space")

            # Add collected properties to object
            $DCObject2 | Add-Member -Type NoteProperty -Name "Domain" -Value $ComputerSystemInfo.domain
            $DCObject2 | Add-Member -Type NoteProperty -Name "Organization" -Value $os.organization
            $DCObject2 | Add-Member -Type NoteProperty -Name "Machine Type" -Value $MachineType
            $DCObject2 | Add-Member -Type NoteProperty -Name "Operating system" -Value $os.Caption
            $DCObject2 | Add-Member -Type NoteProperty -Name "Version" -Value $os.OSArchitecture
            $DCObject2 | Add-Member -Type NoteProperty -Name "Bootup time" -Value $boot
            $DCObject2 | Add-Member -Type NoteProperty -Name "Up Time" -Value $uptime
            $DCObject2 | Add-Member -Type NoteProperty -Name "NTDS Service" -Value $ntds
            $DCObject2 | Add-Member -Type NoteProperty -Name "Netlogon service" -Value $netlogon
            $DCObject2 | Add-Member -Type NoteProperty -Name "Secure channel" -Value $securechannel
            $DCObject2 | Add-Member -Type NoteProperty -Name "Physical RAM" -Value $PhysicalRAM
            $DCObject2 | Add-Member -Type NoteProperty -Name "$DiskName" -Value $FreeSpace
            $DCObject2 | Add-Member -Type NoteProperty -Name "Memory usage %" -Value $Mem
            $DCObject2 | Add-Member -Type NoteProperty -Name "CPU usage %" -Value $Cpu

            # Adding object to first array
            $DCSystem += $DCObject2



            If ($DCSystem) {
                $outputBox.text = $DCSystem | Out-String
            }
            Else {
                $TestResult = "Failed to gather information"
                $outputBox.text = $TestResult
            }
        }
    }
    Else {
        $TestResult = "Server name has not been provided"
        $outputBox.text = $TestResult
    }
}


############################################## OS Info function

function Certificates {

    $Server = $InputBox.text;

    If ($Server) {
        # Testing connection
        If (!(Test-Connection -Cn $Server -BufferSize 16 -Count 1 -ea 0 -Quiet)) {
            Write-Warning   "Failed to connect to $Server"
            $ErrorMsg = "Failed to connect to $Server"
            $outputBox.text = $ErrorMsg
        }
        Else {
            $outputBox.text = "Gathering certificates details - Please wait...." | Out-String
            $Certificates = @()
            $certs = (Invoke-Command $server -scriptblock { Get-ChildItem Cert:\LocalMachine\My })

            ForEach ($cert in $certs) {
                # Adding properties to object
                $DCObject3 = New-Object PSCustomObject
                $DCObject3 | Add-Member -Type NoteProperty -Name "Certificate name" -Value $cert.DnsNameList.punycode
                $DCObject3 | Add-Member -Type NoteProperty -Name "Certificate issuer" -Value $cert.issuer
                $DCObject3 | Add-Member -Type NoteProperty -Name "Certificate expiration date" -Value $cert.notafter
                $DCObject3 | Add-Member -Type NoteProperty -Name "Certificate thumbprint" -Value $cert.thumbprint

                # Adding object to first array
                $Certificates += $DCObject3
            }

            If ($Certificates) {
                $outputBox.text = $Certificates | Format-List | Out-String
            }
            Else {
                $TestResult = "Failed to gather information"
                $outputBox.text = $TestResult
            }


        }
    }
    Else {
        $TestResult = "Server name has not been provided"
        $outputBox.text = $TestResult
    }

}



###################### CREATING PS GUI TOOL #############################

#### Form settings #################################################################
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

$Form = New-Object System.Windows.Forms.Form
$Form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedSingle #modifies the window border
$Form.Text = "PowerShellBros.com"
$Form.Size = New-Object System.Drawing.Size(1010, 400)
$Form.StartPosition = "CenterScreen" #loads the window in the center of the screen
$Form.BackgroundImageLayout = "Zoom"
$Form.MinimizeBox = $False
$Form.MaximizeBox = $False
$Form.WindowState = "Normal"
$Form.SizeGripStyle = "Hide"
$Icon = [system.drawing.icon]::ExtractAssociatedIcon($PSHOME + "\powershell.exe")
$Form.Icon = $Icon

#### Title - Powershell GUI Tool ###################################################
$Label = New-Object System.Windows.Forms.Label
$LabelFont = New-Object System.Drawing.Font("Calibri", 18, [System.Drawing.FontStyle]::Bold)
$Label.Font = $LabelFont
$Label.Text = "Powershell GUI Tool"
$Label.AutoSize = $True
$Label.Location = New-Object System.Drawing.Size(415, 40)
$Form.Controls.Add($Label)

#### Input window with "Server name" label ##########################################
$InputBox = New-Object System.Windows.Forms.TextBox
$InputBox.Location = New-Object System.Drawing.Size(10, 50)
$InputBox.Size = New-Object System.Drawing.Size(180, 20)
$Form.Controls.Add($InputBox)
$Label2 = New-Object System.Windows.Forms.Label
$Label2.Text = "Server name:"
$Label2.AutoSize = $True
$Label2.Location = New-Object System.Drawing.Size(15, 30)
$Form.Controls.Add($Label2)

#### Group boxes for buttons ########################################################
$groupBox = New-Object System.Windows.Forms.GroupBox
$groupBox.Location = New-Object System.Drawing.Size(10, 95)
$groupBox.size = New-Object System.Drawing.Size(180, 270)
$groupBox.text = "DC Health checks:"

$Form.Controls.Add($groupBox)

###################### BUTTONS ##########################################################

#### OS Info Button #################################################################
$OSInfo = New-Object System.Windows.Forms.Button
$OSInfo.Location = New-Object System.Drawing.Size(15, 30)
$OSInfo.Size = New-Object System.Drawing.Size(150, 60)
$OSInfo.Text = "OS Info"
$OSInfo.Add_Click( { OSInfo })
$OSInfo.Cursor = [System.Windows.Forms.Cursors]::Hand
$groupBox.Controls.Add($OSInfo)

#### Certificates ###################################################################
$Certificate = New-Object System.Windows.Forms.Button
$Certificate.Location = New-Object System.Drawing.Size(15, 110)
$Certificate.Size = New-Object System.Drawing.Size(150, 60)
$Certificate.Text = "Certificates"
$Certificate.Add_Click( { Certificates })
$Certificate.Cursor = [System.Windows.Forms.Cursors]::Hand
$groupBox.Controls.Add($Certificate)

#### AD Information #################################################################
$ADInfo = New-Object System.Windows.Forms.Button
$ADInfo.Location = New-Object System.Drawing.Size(15, 190)
$ADInfo.Size = New-Object System.Drawing.Size(150, 60)
$ADInfo.Text = "AD Info"
$ADInfo.Add_Click( { ADInfo })
$ADInfo.Cursor = [System.Windows.Forms.Cursors]::Hand
$groupBox.Controls.Add($ADInfo)

###################### END BUTTONS ######################################################

#### Output Box Field ###############################################################
$outputBox = New-Object System.Windows.Forms.RichTextBox
$outputBox.Location = New-Object System.Drawing.Size(200, 100)
$outputBox.Size = New-Object System.Drawing.Size(780, 265)
$outputBox.Font = New-Object System.Drawing.Font("Consolas", 8 , [System.Drawing.FontStyle]::Regular)
$outputBox.MultiLine = $True
$outputBox.ScrollBars = "Vertical"
$outputBox.Text = " `
          Welcome to your first Powershell GUI Tool - Type Domain Controller name and press one of the available buttons."
$Form.Controls.Add($outputBox)

##############################################

$Form.Add_Shown( { $Form.Activate() })
[void] $Form.ShowDialog()
