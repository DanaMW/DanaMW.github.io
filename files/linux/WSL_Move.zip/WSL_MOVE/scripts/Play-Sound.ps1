$MyArgs = $args
if (!($MyArgs)) { $MyArgs = "D:\System Sounds\DanaDefault\Dongs.mp3" }
& 'D:\bin\VLC\vlc.exe' --qt-start-minimized --play-and-exit --qt-notification=0 $MyArgs

# Not Working
#$PlayWav = New-Object System.Media.SoundPlayer
#$PlayWav.SoundLocation = 'D:\System Sounds\DanaDefault\NOTIFY.WAV'
#$PlayWav.playsync()

#Not Working
#$PlayWav=New-Object System.Media.SoundPlayer
#$PlayWav.SoundLocation= ’C:\Foo\Soundfile.wav’
#$PlayWav.playsync()

# Not Working
#Add-Type -AssemblyName presentationCore
#$mediaPlayer = New-Object system.windows.media.mediaplayer
#$mediaPlayer.open('D:\System Sounds\DanaDefault\Dongs.mp3')
#$mediaPlayer.Play()
1
