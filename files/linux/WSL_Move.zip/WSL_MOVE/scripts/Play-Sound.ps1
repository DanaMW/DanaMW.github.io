$MyArgs = $args
$FileVersion = "0.0.5"
if (!($MyArgs)) { $MyArgs = 'D:\Sounds\System Sounds\DanaDefault\dana-Dongs.mp3' }
$isFile = Test-Path -PathType Leaf -Path $MyArgs
if (($isFile)) {
    #$PlayWav = New-Object System.Media.SoundPlayer
    #$PlayWav.SoundLocation = "$MyArgs"
    #$PlayWav.playsync()
    & 'D:\bin\VLC\vlc.exe' --qt-start-minimized --play-and-exit --qt-notification=0 $MyArgs
}
else {
    Say "Play-Sound $FileVersion"
    Say "Error: File not found :$MyArgs"
    Say ""
    break
}
