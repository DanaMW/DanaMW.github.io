$FileVersion = "0.0.1"
Set-Location C:\
Set-Location C:\Program Files\Hyper-V
C:\Windows\System32\mmc.exe "C:\Windows\System32\virtmgmt.msc"
