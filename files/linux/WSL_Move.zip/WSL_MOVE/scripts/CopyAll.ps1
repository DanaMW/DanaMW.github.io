<#
.SYNOPSIS
        CopyAll
        Created By: Dana Meli
        Created Date: April, 2019
        Last Modified Date: July 17, 2019
.DESCRIPTION
        This script is designed to create any needed directories and copy all files in them.
        It checks last  modified date and only copies newer unless the /ALL parameter is used.
.EXAMPLE
        CopyAll "C:\SourceDirectory" "D:\DestinationDirectory"
        CopyAll "C:\SourceDirectory" "D:\DestinationDirectory" /ALL
        CopyAll -GetDir C:\SourceDirectory -PutDir D:\DestinationDirectory
        CopyAll -GetDir C:\SourceDirectory -PutDir D:\DestinationDirectory /ALL
.NOTES
        Still under development.
#>
Param([string]$GetDir, [string]$PutDir, [string]$IsAll)
$FileVersion = "Version: 0.1.11"
if (!($GetDir)) {
    Say ""
    Say 'CopyAll needs a SOURCE and DESTINATION directory.'
    Say 'CopyAll "C:\SourceDirectory" "D:\DestinationDirectory"'
    Say 'CopyAll "C:\SourceDirectory" "D:\DestinationDirectory" /ALL'
    Say 'CopyAll -GetDir C:\SourceDirectory -PutDir D:\DestinationDirectory'
    Say 'CopyAll -GetDir C:\SourceDirectory -PutDir D:\DestinationDirectory /ALL'
    Say ""
    return
}
if (!($PutDir)) {
    Say ""
    Say 'CopyAll needs a SOURCE and DESTINATION directory.'
    Say 'CopyAll "C:\SourceDirectory" "D:\DestinationDirectory"'
    Say 'CopyAll "C:\SourceDirectory" "D:\DestinationDirectory" /ALL'
    Say 'CopyAll -GetDir C:\SourceDirectory -PutDir D:\DestinationDirectory'
    Say 'CopyAll -GetDir C:\SourceDirectory -PutDir D:\DestinationDirectory /ALL'
    Say ""
    return
}
if ($IsAll -eq "/ALL") { [bool]$CopyAll = 1 }
Else { [bool]$CopyAll = 0 }
Say "GetDir:" $GetDir
Say "PutDir:" $PutDir
Say "CopyAll:" $CopyAll
Say "Running Put CopyFiles $FileVersion"
Say "Starting the put process."
If (($CopyAll)) { Say "Copy All Selected." }
else { Say "Copy Only Newer Selected." }
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
$Filetmp = ($env:BASE + "\CopA-Doc.tmp")
$FileTest = Test-Path -path $Filetmp
if (($FileTest)) { Remove-Item -path $Filetmp }
$Dirtmp = ($env:BASE + "\CopA-Dir.tmp")
$FileTest = Test-Path -path $Dirtmp
if ($FileTest -eq $true) { Remove-Item -path $Dirtmp }
$FileTest = Test-Path -path $PutDir -PathType Container
if (!($FileTest)) {
    Say "Directory does not exist, creating $PutDir"
    New-Item -Path $PutDir -Name $Read -ItemType "directory"
}
Get-ChildItem -Path $GetDir -Attributes Directory -Name -Recurse | ? { ($_ -notmatch 'node_modules' ) } | ? { ($_ -notmatch 'git' ) } | Sort-Object | Out-File $Dirtmp
Say "File Loaded:" $Dirtmp
$Lines = (Get-Content $Dirtmp).count
Say "The file has $Lines Lines"
$cd = 0
$i = 0
Say "Checking All Directories, this could take a few minutes."
While ($i -lt $Lines) {
    $Read = (Get-Content $Dirtmp)[$i]
    $Dirchk = "$PutDir\$Read"
    $FileTest = Test-Path -path $Dirchk -PathType Container
    if (!($FileTest)) {
        Say "Creating Directory: $PutDir\$Read"
        try { New-Item -Path $PutDir\ -Name $Read -ItemType "directory" -ErrorAction SilentlyContinue | Out-Null }
        catch { continue }
        $cd++
    }
    $i++
}
#Clear-Variable "i"
#Clear-Variable "Lines"
#Clear-Variable "Read"
Get-ChildItem -Path $GetDir -Name -File -Recurse | ? { ($_ -notmatch 'node_modules' ) } | ? { ($_ -notmatch 'git' ) } | Sort-Object | Out-File $Filetmp
$Lines = (Get-Content $filetmp).count
$cf = 0
$i = 0
Say "The Files List has $Lines lines in it."
Say "Now we are finally coping files."
$Reader = New-Object IO.StreamReader ($filetmp, [Text.Encoding]::UTF8, $true, 4MB)
While ($i -lt $Lines) {
    #$Read = (Get-Content $filetmp)[$i]
    $Read = $reader.ReadLine()
    if (($read.EndOfStream)) { $i = $Lines }
    If (($CopyAll)) {
        Say "Copying $PutDir\$Read"
        Copy-Item $GetDir\$Read -Destination $PutDir\$Read -Recurse -Force
        $cf++
    }
    else {
        $lastModDateGet = (Get-Item "$GetDir\$Read").LastWriteTime
        $lastModDatePut = (Get-Item "$PutDir\$Read").LastWriteTime
        if ($lastModDateGet -gt $lastModDatePut) {
            Say "Copying $PutDir\$Read"
            Copy-Item $GetDir\$Read -Destination $PutDir\$Read -Recurse -Force
            $cf++
        }
    }
    $i++
}
$reader.close()
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$FileTest = Test-Path -path $Filetmp
if (($FileTest)) {
    Say "Removing Item:" $Filetmp
    Remove-Item -path $Filetmp
}
$FileTest = Test-Path -path $Dirtmp
if (($FileTest)) {
    Say "Removing Item: $Dirtmp"
    Remove-Item -path $Dirtmp
}
Say "Created $cd Missing Directories."
Say "Copied $cf Newer Files"
Say "We are ALL DONE."
