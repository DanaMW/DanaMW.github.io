$FileVersion = "0.1.8"
if ($args) {
    [string]$Catch = $args[0]
    $Where = ("go-" + $Catch)
    $Where = $Where.trim()
    $Where = ($env:BASE + "\" + $where + ".ps1")
    $Filetest = Test-Path -Path $where
    if ($Filetest -eq $true) {
        & $where
        return
    }
}
else {
    Say "Go $FileVersion Setting your location to Local Github Repo"
    Set-Location $env:DEV.substring(0, 3)
    Set-Location ($env:DEV + "\GitHub\")
}
Say "git fetch upstream"
Say "git merge upstream/master"
Say "git push origin"
Say ""
