<#
.SYNOPSIS
        Go-Home
        Created By: Dana Meli
        Created Date: December, 2019
        Last Modified Date: March 18, 2021

.DESCRIPTION
        This script is part of my Go set. It Takes you to your ~ directory.
        Also has an extra option of NPM. This will take you home run NPM UPDATE
        and NPM UPDATE -G then put you back in $Base folder.

.EXAMPLE
        Go-Home

.EXAMPLE
        Go-Home NPM

.NOTES
        Still under development.

#>
$MyArgs = "$args"
$FileVersion = "0.2.5"
Clear-Host
if (!($MyArgs)) {
    WC "~WHITE~Go Home ~~RED~$FileVersion~"
    WC "~WHITE~Setting your location to ...~"
    Set-Location $env:HOME.substring(0, 3)
    Set-Location $env:HOME
    WC "~RED~#~~darkred~=======================================~~red~#~"
    WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=~~RED~# ~~darkred~|~"
    WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~===============================~~red~# ~~WHITE~| ~~darkred~|~"
    WC "~darkred~| ~~WHITE~| ~~darkred~| ~~DARKCYAN~[~~WHITE~Welcome to your HOME folder~~DARKCYAN~] ~~darkred~| ~~WHITE~| ~~darkred~|~"
    WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~===============================~~red~# ~~WHITE~| ~~darkred~|~"
    WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=~~RED~# ~~darkred~|~"
    WC "~RED~#~~darkred~=======================================~~red~#~"
    return
}
if (($MyArgs)) {
    if ($MyArgs -eq "NPM") {
        WC "~WHITE~Go Home ~~RED~$FileVersion~"
        WC "~WHITE~Setting your location to ...~"
        Set-Location $env:HOME.substring(0, 3)
        Set-Location $env:HOME
        WC "~RED~#~~darkred~=======================================~~red~#~"
        WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=~~RED~# ~~darkred~|~"
        WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~===============================~~red~# ~~WHITE~| ~~darkred~|~"
        WC "~darkred~| ~~WHITE~| ~~darkred~| ~~DARKCYAN~[~~WHITE~Welcome to your HOME folder~~DARKCYAN~] ~~darkred~| ~~WHITE~| ~~darkred~|~"
        WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~===============================~~red~# ~~WHITE~| ~~darkred~|~"
        WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=~~RED~# ~~darkred~|~"
        WC "~RED~#~~darkred~=======================================~~red~#~"
        Say 'Running "npm update" in the HOME (~) folder.'
        npm update
        Say 'Running "npm update" GLOBALLY (-g) in the HOME (~) folder.'
        npm update -g
        Set-Location $env:BASE.substring(0, 3)
        Set-Location $env:BASE
        Say "All done. Moved you back to the BASE ($Env:BASE) directory."
        return
    }
}
