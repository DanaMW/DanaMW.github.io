$FileVersion = "Version: 0.2.2"
Clear-Host
WC "~WHITE~Go Home ~~RED~$FileVersion~"
WC "~WHITE~Setting your location to ...~"
Set-Location $env:HOME.substring(0, 3)
Set-Location $env:HOME
WC "~RED~#~~darkred~=======================================~~red~#~"
WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=~~RED~# ~~darkred~|~"
WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~===============================~~red~# ~~WHITE~| ~~darkred~|~"
WC "~darkred~| ~~WHITE~| ~~darkred~| ~~DARKCYAN~[~~WHITE~Welcome to your HOME folder~~DARKCYAN~] ~~darkred~| ~~WHITE~| ~~darkred~|~"
WC "~darkred~| ~~WHITE~| ~~RED~#~~darkred~===============================~~red~# ~~WHITE~| ~~darkred~|~"
WC "~darkred~| ~~red~#~~WHITE~=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=~~RED~# ~~darkred~|~"
WC "~RED~#~~darkred~=======================================~~red~#~"
