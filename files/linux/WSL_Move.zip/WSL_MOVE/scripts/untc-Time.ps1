$FileVersion = "Version: 0.0.1"
$unx = "$args" $origin = $(New-Object -Type DateTime -ArgumentList 1970, 1, 1, 0, 0, 0, 0) $whatIWant = $origin.AddSeconds($unx) Say $whatIWant #return $whatIWant
