﻿param([string]$File1, [string]$File2)
$FileVersion = "0.0.9"
$Difftxt = ($env:BASE + "\Get-Diff.tmp")
if (!($File1)) {
    Say "Get-Diff $FileVersion"
    Say -ForegroundColor RED "Use Get-Diff File1 File2"
    Return
}
if (!($File2)) {
    Say "Get-Diff $FileVersion"
    Say -ForegroundColor RED "Use Get-Diff File1 File2"
    Return
}
$Filetest = Test-Path -Path $File1
if ($Filetest -ne "$true") { Say -ForegroundColor RED $File1 "does not exist"; return }
$Filetest = Test-Path -Path $File2
if ($Filetest -ne "$true") { Say -ForegroundColor RED $File2 "does not exist"; Return }
$Filetest = Test-Path -Path $DiffFile
if ($Filetest -eq "$true") { Remove-Item $Difftxt }
Compare-Object (Get-Content $File1) (Get-Content $File2) | Format-List | Out-File $Difftxt

<#
$path1 = Get-ChildItem -Recurse "d:\Downloads\aria2-0.3.5-an+fx\$($_.name)"
np
$path2 = Get-ChildItem -Recurse "d:\Development\GitHub\Download-Synthesis-Aria2\$($_.name)"
Diff -ReferenceObject $path1 -DifferenceObject $path2 -PassThru
$dif = compare (gc $path1) (gc $path2);if ($dif) {$_.name;$dif}
#>
