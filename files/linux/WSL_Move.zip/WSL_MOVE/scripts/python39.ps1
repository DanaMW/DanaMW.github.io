& C:\Py\Python39\python.exe $args
