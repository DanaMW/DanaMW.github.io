param([string]$myargs)
$FileVersion = "0.0.3"
if ($myargs -eq "") {
    $CMD = ($env:BASE + "\VLC\vlc.exe")
    & $CMD
    return
}
$TheArgs = "$myargs $args"
$CMD = ($env:BASE + "\VLC\vlc.exe")
$arg1 = '--video-x=-1920'
$arg2 = '--video-y=1080'
$arg3 = '--width=300'
$arg4 = '--height=300'

& $CMD $TheArgs $arg1 $arg2 $arg3 $arg4
