$MyArgs = "$args"
$FileVersion = "0.0.4"
$c = 0
#$Con = Get-NetConnectionProfile -Name "Unidentified network" -InterfaceAlias "Ethernet";
$Con = Get-NetConnectionProfile
$ac = $Con.count
if (!($MyArgs)) {
    Say "Repair-NetLocation $FileVersion"
    while ($c -lt $ac) {
        Say -NoNewLine "["
        Say -NoNewLine "$c"
        Say -NoNewLine "] "
        Say -NoNewLine $Con[$c].InterfaceAlias $Con[$c].interfaceIndex "is set to" $Con[$c].NetworkCategory
        Say ""
        $c++
    }
    $tp = WCP "~cyan~[~~darkyellow~Enter the number of the interface to toggle~~cyan~]~~darkred~(~~white~Q~~darkred~)~~white~uit~~white~:~ "
    $ans = Read-Host -Prompt $tc
    if ($ans -eq "Q") { return }
    if ($Con[$ans].NetworkCategory -eq "Private") {
        Set-NetConnectionProfile -InterfaceAlias $Con[$ans].InterfaceAlias -InterfaceIndex $Con[$ans].InterfaceIndex -NetworkCategory Public
        WC "~cyan~[~~red~Setting Ethernet to Public~~cyan~]~~white~.~"
    }
    elseif ($Con[$ans].NetworkCategory -eq "Public") {
        Set-NetConnectionProfile -InterfaceAlias $Con[$ans].InterfaceAlias -InterfaceIndex $Con[$ans].InterfaceIndex -NetworkCategory Private
        WC "~cyan~[~~red~Setting Ethernet to Private~~cyan~]~~white~.~"
    }
    WC "~cyan~[~~green~Network working correctly.~~cyan~]~~white~.~"
    return
}
