# Add all the modules for PowerShell
$FileVersion = "0.0.3"
& Putit BurntToast
& Putit DeviceManagement
& Find-Module Get-ChildItemColor
& Install-Module Get-ChildItemColor -AllowClobber
& Putit JSONCmdlets
& Putit MenuShell
& Putit NetworkingDsc
& Find-Module oh-my-posh
& Install-Module oh-my-posh -Force
& Find-Module Pester
& Install-Module Pester -Force
& Find-Module posh-git
& Install-Module posh-git -AllowClobber
& Putit PowerShellForGitHub
& Putit PowerShellGetGUI
# & Putit psake
& Putit PSCoreUpdate
& Putit PSDscResources
& Putit PSEnvironment
# & Putit PsGet
& Putit psInlineProgress
& Putit PSScriptAnalyzer
& Putit PSWindowsUpdate
& Putit ResolveAlias
& Putit RobocopyPS
& Putit ScriptBrowser
& Putit ShowUI
& Putit WinDiffStuff
& Putit WindowsPSModulePath
& Putit WinFormPS
& Putit WinGUI
& Putit WPFPS
& Putit xNetworking
& Putit xWindowsUpdate
