Function MyIn {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [string]$Prompt
    )
    Process {
        While (1) {
            Say -NoNewLine ($Prompt + " ")
            [Console]::ReadKey($true) | ForEach-Object {
                If ($_ -eq [char]13)
                { Write-Output $ReadKey }
                else {
                    $ReadKey = ($ReadKey + $_)
                    Continue
                }
            }
        }
        Finally { Write-Output $ReadKey }
    }
}
