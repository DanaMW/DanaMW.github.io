$FileVersion = "0.1.7"
$WhereTo = $args
$testpath = "D:\Development\GitHub\$Whereto"
$GoodGo = Test-Path -Path $testpath
if ($goodgo -eq "$True") {
    Say "Go $FileVersion Setting your location to Local $TestPath Repo"
    Set-Location $testpath.substring(0, 3)
    Set-Location $testpath
}
else {
    Say "Go $FileVersion Setting your location to Local Only Repo"
    Set-Location "C:\"
    Set-Location "C:\Users\Dana\AppData\GitRepo\"
}
Say "git fetch upstream"
Say "git merge upstream/master"
Say "git push origin"
Say ""
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
