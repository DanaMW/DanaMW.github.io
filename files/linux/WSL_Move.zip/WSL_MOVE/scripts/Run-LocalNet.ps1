Param([string]$Path)
$FileVersion = "0.0.3"

if ($Path -eq "H") {
    Say "Do-Net $FileVersion Setting your location to H  \\torchlight\bin"
    Set-Location \\torchlight\bin
}
if ($Path -eq "I") {
    Say "Do-Net $FileVersion Setting your location to H  \\torchlight\MyScripts"
    Set-Location \\torchlight\MyScripts
}
if ($Path -eq "J") {
    Say "Do-Net $FileVersion Setting your location to H  \\torchlight\Music"
    Set-Location \\torchlight\Music
}
if ($Path -eq "K") {
    Say "Do-Net $FileVersion Setting your location to H \\torchlight\Downloads"
    Set-Location \\torchlight\Downloads
}
if ($Path -eq "L") {
    Say "Do-Net $FileVersion Setting your location to H  \\torchlight\.git"
    Set-Location \\torchlight\.git
}
if ($Path -eq "M") {
    Say "Do-Net $FileVersion Setting your location to H  \\torchlight\Adult"
    Set-Location \\torchlight\Adult
}
else {
    Say "Do-Net $FileVersion"
    Say 'H is \\torchlight\bin'
    Say 'I is \\torchlight\MyScripts'
    Say 'J is \\torchlight\Music'
    Say 'K is \\torchlight\Downloads'
    Say 'L is \\torchlight\.git'
    Say 'M is \\torchlight\Adult'
}
