$FileVersion = "0.0.7"
$host.ui.RawUI.WindowTitle = "My VMware Launcher $FileVersion"
Say "Run VMWare $FileVersion"
Say "Running VMware for you now."
Say "Starting VMware services."
Start-Service -DisplayName VMware* -Verbose
Say "Starting VMware."
Start-Process "C:\Program Files (x86)\VMware\VMware Workstation\vmware.exe" -Wait
Say "Finished running VMware..."
Say "Stopping VMware services."
Stop-Service -DisplayName VMware* -Force -Verbose
return
