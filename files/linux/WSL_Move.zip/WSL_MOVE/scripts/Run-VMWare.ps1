$FileVersion = "FileVersion: 0.0.4"
Say "Run VMWare $FileVersion"
Say "Running VMWare for you now."
Start-Process "C:\Program Files (x86)\VMware\VMware Player\vmplayer.exe" -Wait
Say "Finished running VMWare..."
$ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Run VMWare again? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "N" -Echo 1 -Max 0
if ($ans -eq "Y") { Start-Process ($env:BASE + "\Run-VMWare.ps1") }
break
