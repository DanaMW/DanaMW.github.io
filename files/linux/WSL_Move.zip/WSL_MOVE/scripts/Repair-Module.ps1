$TheArgs = "$args".trim()
$FileVersion = "0.0.4"
if (!($TheArgs)) {
    Say "Repair-Module $FileVersion"
    Say -ForegroundColor Cyan "Yo, buddy, you need to include the module name to repair..."
    Say -ForegroundColor Yellow "Repair-Module oh-my-posh"
    Say -ForegroundColor Cyan "...like that. That wasn't hard was it? Good."
}
else {
    if ($env:SHELL -eq "/bin/bash") {
        Say "Linux was found"
        Say "Finding $TheArgs"
        Find-Module $TheArgs
        Say "Removing Module $TheArgs if it is there."
        Say "There will be errors if it is not installed, those are OK."
        Remove-Module $TheArgs
        Say "Removing Item" ("$UserModuleBasePath" + "/" + "$TheArgs") "if it is there."
        Remove-Item ("$UserModuleBasePath" + "/" + "$TheArgs") -Recurse -Force
        Say "OK Time to put the module back in your system."
        Install-Module $TheArgs
        Say "Finally this shit is done."
        return
        return

    }
    elseif ($env:OS -eq "Windows_NT") {
        Say "Windows was found"
        Say "Finding $TheArgs"
        Find-Module $TheArgs
        Say "Removing Module $TheArgs if it is there."
        Say "There will be errors if it is not installed, those are OK."
        Remove-Module $TheArgs
        Say "Removing Item" ("$UserModuleBasePath" + "\" + "$TheArgs") "if it is there."
        Remove-Item ("$UserModuleBasePath" + "\" + "$TheArgs") -Recurse -Force
        Say "OK Time to put the module back in your system."
        Install-Module $TheArgs
        Say "Finally this shit is done."
        return
    }
    else {
        Say "I mist be stupid or something I have NO idea what OS your running"
        break
    }
}
