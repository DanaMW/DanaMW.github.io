$FileVersion = "Version: 0.0.1"
$appName = "BinMenu"
$arguments = " -noProfile -nologo"
$wshshell = new-object -comobject wscript.shell
$volEnv = $wshShell.environment("volatile")
$qlf = join-path -path $volEnv.item("appdata") -childPath "Microsoft\Internet Explorer\Quick Launch"
$shortCut = $wshShell.CreateShortCut("$qlf\$appName.lnk")
$shortCut.TargetPath = $appName
$shortCut.Description = "Lanch $appName"
$shortCut.WorkingDirectory = "C:\"
$shortCut.HotKey = "CTRL+SHIFT+D"
$shortCut.Arguments = $arguments
$shortCut.Save()
