$FileVersion = "0.0.2"
$appName = "BinMenu"
$arguments = " -noProfile -nologo"
$wshshell = New-Object -ComObject wscript.shell
$volEnv = $wshShell.environment("volatile")
$qlf = Join-Path -Path $volEnv.item("appdata") -ChildPath "Microsoft\Internet Explorer\Quick Launch"
$shortCut = $wshShell.CreateShortCut("$qlf\$appName.lnk")
$shortCut.TargetPath = $appName
$shortCut.Description = "Lanch $appName"
$shortCut.WorkingDirectory = "C:\"
$shortCut.HotKey = "CTRL+SHIFT+D"
$shortCut.Arguments = $arguments
$shortCut.Save()
