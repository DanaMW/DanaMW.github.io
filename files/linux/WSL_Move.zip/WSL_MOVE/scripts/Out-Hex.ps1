$FileVersion = "0.1.0"
[string]$MyArgs = $args
Function Stop {
    Read-Host -Prompt $args
}
[string]$hexword = [string]$MyArgs
$hexval = [char[]]$hexword | ForEach-Object { '{0:x2}' -f [int]$_ }
$hexval = (-join $hexval)
$hexcomp1 = $hexval
$n = 0
While ($n -lt $hexval.length) {
    $hexcomp2 = $hexcomp2 + $hexval.substring($n, 2) + " "
    $n++; $n++

}
$hexval.trim('`r`n') | clip
Say ""
Say "Out-Hex $FileVersion"
Say "Option1 has been loaded into the ClipBoard"
Say ""
Say "Option1:" $hexcomp1
Say "Option2:" $hexcomp2
Say ""
