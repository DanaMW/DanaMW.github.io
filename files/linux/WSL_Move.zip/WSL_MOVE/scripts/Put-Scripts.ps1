# My Put-Scripts
$FileVersion = "Version: 0.1.23"
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Running Put Scripts $FileVersion"
Say "Starting the Put process."
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$filetmp = ($env:BASE + "\Put-Scripts.tmp")
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
$dest = "\\TorchLight\D\Development\GitHub\DanaMW.github.io\scripts\scripts"
Get-ChildItem -Path "D:\Development\GitHub\DanaMW.github.io\scripts\scripts\*" -Include "*.css" | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
While ($i -lt $lines) {
    $Read = (Get-Content $filetmp)[$i]
    Copy-Item D:\Development\GitHub\DanaMW.github.io\scripts\scripts\$read -Destination $dest\$read -Force
    Say "Putting D:\..\$read to $dest\$read"
    $i++
}
$oi = $i
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
$dest = "\\TorchLight\D\Development\GitHub\DanaMW.github.io\scripts\extra"
Get-ChildItem -Path "D:\Development\GitHub\DanaMW.github.io\scripts\extra\*" -Include "*.css" | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
While ($i -lt $lines) {
    $Read = (Get-Content $filetmp)[$i]
    Copy-Item D:\Development\GitHub\DanaMW.github.io\scripts\extra\$read -Destination $dest\$read -Force
    Say "Putting D:\..\$read to $dest\$read"
    $i++
}
$oi = ($oi + $i)
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
$dest = "\\TorchLight\D\Development\GitHub\DanaMW.github.io\scripts\contentadd"
Get-ChildItem -Path "D:\Development\GitHub\DanaMW.github.io\scripts\contentadd\*" -Include "*.css" | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
While ($i -lt $lines) {
    $Read = (Get-Content $filetmp)[$i]
    Copy-Item D:\Development\GitHub\DanaMW.github.io\scripts\contentadd\$read -Destination $dest\$read -Force
    Say "Putting D:\..\$read to $dest\$read"
    $i++
}
$oi = ($oi + $i)
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
$dest = "\\TorchLight\D\Development\GitHub\DanaMW.github.io\scripts\firefox"
Get-ChildItem -Path "D:\Development\GitHub\DanaMW.github.io\scripts\firefox\*" -Include "*.css" | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
While ($i -lt $lines) {
    $Read = (Get-Content $filetmp)[$i]
    Copy-Item D:\Development\GitHub\DanaMW.github.io\scripts\firefox\$read -Destination $dest\$read -Force
    Say "Putting D:\..\$read to $dest\$read"
    $i++
}
$oi = ($oi + $i)
$Filetest = Test-Path -path $Filetmp
if ($Filetest -eq $true) { Remove-Item -path $Filetmp }
$dest = "\\TorchLight\D\Development\GitHub\DanaMW.github.io\jscripts\scripts"
Get-ChildItem -Path "D:\Development\GitHub\DanaMW.github.io\jscripts\scripts\*" -Include "*.js" | Sort-Object | Format-List Name | Out-File $Filetmp
(Get-Content $filetmp) | Where-Object { $_.trim() -ne "" } | Set-Content $filetmp
(Get-Content $filetmp) | ForEach-Object { $_.replace("Name : ", "") } | Set-Content $filetmp
$i = 0
$lines = (Get-Content $filetmp).count
While ($i -lt $lines) {
    $Read = (Get-Content $filetmp)[$i]
    Copy-Item D:\Development\GitHub\DanaMW.github.io\jscripts\scripts\$read -Destination $dest\$read -Force
    Say "Putting D:\..\$read to $dest\$read"
    $i++
}
$oi = ($oi + $i)
Say "Finished Putting" $oi "script files to" $dest
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$filetmp = ($env:BASE + "\Put-Scripts.tmp")
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
Say "We are ALL DONE."
$Ans = Put-Pause -Prompt "~cyan~[~~darkyellow~Clear the screen? ~~darkcyan~(~~white~Y~~darkcyan~/~~white~N~~darkcyan~)~~cyan~]~~white~:~ " -Default "Y" -Echo 1
If ($Ans -eq "Y") { Clear-Host }
