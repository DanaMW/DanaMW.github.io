$FileVersion = "Version: 0.0.6"
Set-Location "D:\bin\yakyak".substring(0, 3)
Set-Location "D:\bin\yakyak"
$username = $env:USERNAME
if ($env:USERDOMAIN -eq "TINMAN") {
    $password = Get-Content 'D:\Documents\Storage_And_Backup\Passwords\TinmanPasswordSecure.txt' | ConvertTo-SecureString
}
if ($env:USERDOMAIN -eq "TORCHLIGHT") {
    $password = Get-Content 'C:\Users\dana\OneDrive\Documents\Storage_And_Backup\Passwords\TorchLightPasswordSecure.txt' | ConvertTo-SecureString
}
Say "Run YakYak $FileVersion Running..."
$credential = New-Object System.Management.Automation.PSCredential $username, $Password
Start-Process ($env:BASE + "\yakyak\yakyak.exe") -Credential $credential -WindowStyle Hidden
