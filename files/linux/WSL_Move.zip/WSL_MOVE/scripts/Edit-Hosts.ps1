$FileVersion = "0.1.5"
Say "Edit-Hosts $FileVersion"
Say "Look in this file for proper formats."
if ($env:SHELL -eq "/bin/bash") {
    Say "Linux was found"
    sudo nano /etc/hosts
}
elseif ($env:OS -eq "Windows_NT") {
    Say "Windows was found"
    $Editor = ($env:BASE + "\NPP\notepad++.exe")
    $HostFile1 = ($env:WINDIR + "\System32\drivers\etc\hosts")
    $HostFile2 = ($env:WINDIR + "\System32\drivers\etc\lmhosts.sam")
    $HostFile3 = ($env:WINDIR + "\System32\drivers\etc\networks")
    $AllHosts = "$HostFile1 $HostFile2 $HostFile3"
    Start-Process -FilePath $Editor -ArgumentList $AllHosts -Verb RunAs
}
else {
    Say "Doh"
}

# Linux Set
# /etc/hosts: static lookup table for host names
# <ip-address>   <hostname.domain.org>   <hostname>
# 127.0.0.1       localhost.localdomain.net localhost.localdomain localhost
# ::1             localhost.localdomain.net localhost.localdomain localhost
# 127.0.1.1       BlackArch.localdomain.net BlackArch.localdomain BlackArch
# 192.168.0.1     Router.localdomain.net Router.localdomain Router
# 192.168.0.2     TinMan.localdomain.net TinMan.localdomain Tinman
# 192.168.0.3     TorchLight.localdomain.net TorchLight.localdomain TorchLight
# 192.168.0.4     Fedora.localdomain.net Fedora.localdomain Fedora
# 192.168.0.5     Win7.localdomain.net Win7.localdomain Win7
# 192.168.0.6     Arch.localdomain.net Arch.localdomain Arch
#  192.168.0.7     Ubuntu.localdomain.net Ubuntu.localdomain Ubuntu
# 192.168.0.8     Redhat.localdomain.net Redhat.localdomain Redhat
# 192.168.0.10    Win10.localdomain.net Win10.localdomain Win10
# 192.168.0.11    Neon.localdomain.net Neon.localdomain Neon
# 192.168.0.12    BlackArch.localdomain.net BlackArch.localdomain BlackArch
# End of file

#Windows Set
# hosts @('
# 127.0.0.1		localhost
# 192.168.0.1		Router
# 192.168.0.1		Router.localdomain.net
# 192.168.0.2		TinMan
# 192.168.0.2		TinMan.localdomain.net
# 192.168.0.3		TorchLight
# 192.168.0.3		TorchLight.localdomain.net
# 192.168.0.4		Fedora
# 192.168.0.4		Fedora.localdomain.net
# 192.168.0.5		Win7
# 192.168.0.5		Win7.localdomain.net
# 192.168.0.6		Arch
# 192.168.0.6		Arch.localdomain.net
# 192.168.0.7		Ubuntu
# 192.168.0.7		Ubuntu.localdomain.net
# 192.168.0.8     Redhat
# 192.168.0.8     Redhat.localdomain.net
# 192.168.0.10	Win10
# 192.168.0.10	Win10.localdomain.net
# 192.168.0.11	Neon
# 192.168.0.11	Neon.localdomain.net
# 192.168.0.12	BlackArch
# 192.168.0.12	BlackArch.localdomain.net
# ')
# End of file

# imhosts.sam @('
# 127.0.0.1			localhost
# 192.168.0.1			Router
# 192.168.0.2			TinMan
# 192.168.0.3			TorchLight
# 192.168.0.4			Fedora
# 192.168.0.5			Win7
# 192.168.0.6			Arch
# 192.168.0.7			Ubuntu
# 192.168.0.8         Redhat
# 192.168.0.10		Win10
# 192.168.0.11		Neon
# 192.168.0.12		BlackArch
# ')
# End of file

# networks @('
# Copyright (c) 1993-1999 Microsoft Corp.
# This file contins network name/network number mappings for
# local networks. Network numbers are recognized in dotted decimal form.
# Format:
# <network name>  <network number>     [aliases...]  [#<comment>]
# loopback        127
# localhost		127.0.0.1
# Router			192.168.0.1
# TinMan			192.168.0.2
# TorchLight		192.168.0.3
# Fedora			192.168.0.4
# Win7			190.168.0.5
# Arch			192.168.0.6
# Ubuntu			192.168.0.7
# Redhat          192.168.0.8
# Win10			192.168.0.10
# Neon			192.168.0.11
# BlackArch		192.168.0.12
# ')
# End of file

# Hosts File
# Block Facebook IPv4
# 127.0.0.1   www.facebook.com
# 127.0.0.1   facebook.com
# 127.0.0.1   login.facebook.com
# 127.0.0.1   www.login.facebook.com
# 127.0.0.1   fbcdn.net
# 127.0.0.1   www.fbcdn.net
# 127.0.0.1   fbcdn.com
# 127.0.0.1   www.fbcdn.com
# 127.0.0.1   static.ak.fbcdn.net
# 127.0.0.1   static.ak.connect.facebook.com
# 127.0.0.1   connect.facebook.net
# 127.0.0.1   www.connect.facebook.net
# 127.0.0.1   apps.facebook.com
# Block Facebook IPv6
# ::1 www.facebook.com
# ::1 facebook.com
# ::1 login.facebook.com
# ::1 www.login.facebook.com
# ::1 fbcdn.net
# ::1 www.fbcdn.net
# ::1 fbcdn.com
# ::1 www.fbcdn.com
# ::1 static.ak.fbcdn.net
# ::1 static.ak.connect.facebook.com
# ::1 connect.facebook.net
# ::1 www.connect.facebook.net
# ::1 apps.facebook.com