$FileVersion = "Version: 0.1.3"
Say "Edit-Hosts $FileVersion"
Say "Look in this file for proper formats."
$Editor = ($env:BASE + "\NPP\NotePad++.exe")
$HostFile1 = ($env:WINDIR + "\System32\drivers\etc\hosts")
$HostFile2 = ($env:WINDIR + "\System32\drivers\etc\lmhosts.sam")
$HostFile3 = ($env:WINDIR + "\System32\drivers\etc\networks")
$AllHosts = "$HostFile1 $HostFile2 $HostFile3"
Start-Process -FilePath $Editor -ArgumentList $AllHosts -Verb RunAs
<#
hosts @('
127.0.0.1		localhost
192.168.0.1		Router
192.168.0.1		Router.localdomain.net
192.168.0.2		TinMan
192.168.0.2		TinMan.localdomain.net
192.168.0.3		TorchLight
192.168.0.3		TorchLight.localdomain.net
192.168.0.4		Fedora
192.168.0.4		Fedora.localdomain.net
192.168.0.5		Win7
192.168.0.5		Win7.localdomain.net
192.168.0.6		Arch
192.168.0.6		Arch.localdomain.net
192.168.0.7		Ubuntu
192.168.0.7		Ubuntu.localdomain.net
192.168.0.10	Win10
192.168.0.10	Win10.localdomain.net
192.168.0.11	Neon
192.168.0.11	Neon.localdomain.net
192.168.0.12	BlackArch
192.168.0.12	BlackArch.localdomain.net
')
imhosts.sam @('
127.0.0.1			localhost
192.168.0.1			Router
192.168.0.2			TinMan
192.168.0.3			TorchLight
192.168.0.4			Fedora
192.168.0.5			Win7
192.168.0.6			Arch
192.168.0.7			Ubuntu
192.168.0.10		Win10
192.168.0.11		Neon
192.168.0.12		BlackArch
')
networks @('
# Copyright (c) 1993-1999 Microsoft Corp.
# This file contins network name/network number mappings for
# local networks. Network numbers are recognized in dotted decimal form.
# Format:
# <network name>  <network number>     [aliases...]  [#<comment>]
loopback        127
localhost		127.0.0.1
Router			192.168.0.1
TinMan			192.168.0.2
TorchLight		192.168.0.3
Fedora			192.168.0.4
Win7			190.168.0.5
Arch			192.168.0.6
Ubuntu			192.168.0.7
Win10			192.168.0.10
Neon			192.168.0.11
BlackArch		192.168.0.12
')
#>
