#Taken from [here](http://bradlyfeeley.com/2008/09/03/update-a-github-fork-from-the-original-repo/)
#Add remonte branch:                              openstyles/stylus
#`git remote add --track master openstyles git://github.com/openstyles/stylus.git`
#Verify:
#`git remote`
#Fetch:
#`git fetch mleung`
#Merge:
#`git merge mleung/master`
#And then `git push` the updates to your fork

git fetch upstream
git merge upstream/master
git push origin

then:
npm install
npm run update
npm run zip

then:
delete the last two closing curly brackets and add:
  },
  "applications": {
    "gecko": {
      "id": "{7a7a4a92-a2a0-41d1-9fd7-1e92480d612d}"
    }
  }
}
