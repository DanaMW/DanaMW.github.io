$ans = Read-Host -Prompt $menuprompt
[Int32]$OutNumber = $null
if ([Int32]::TryParse($ans, [ref]$OutNumber)) {
    <# Work with a number if it is #>
    TheCommand -IntCom ("[" + $ans + "B]") -Argue ("[" + $ans + "C]")
}
else {
    <# Work with the string #>
}
