Configuration MyDscConfiguration {
    Node "TinMan" {
        WindowsFeature MyFeatureInstance {
            Ensure = 'Present'
            Name = 'RSAT'
        }
    }
}
MyDscConfiguration
