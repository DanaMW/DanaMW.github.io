$FileVersion = "Version: 0.1.7"
if ($args) {
    [string]$Catch1 = $args[0]
    [string]$Catch2 = $args[1]
    [string]$Catch3 = $args[2]
    [string]$Catch4 = $args[3]
    [string]$Catch5 = $args[4]
    [string]$Catch6 = $args[5]
    [string]$Catch7 = $args[6]
    [string]$Catch8 = $args[7]
}
if (!($Catch1)) {
    Say "Go $FileVersion"
    Say "Pick One, try again. Go-Place or Go Place"
    Say "With Repos Use Go-Github Repo or Go Local Repo"
    Get-Files.ps1 ($env:BASE + "\Go-*")
    return
}
if ($Catch1 -eq "..") {
    Say "Go $Catch1 Setting you up one Directory"
    Set-Location $Catch1
    return
}
if ($Catch1 -eq "ROOT") {
    if ($Catch2) {
        if ($Catch2[-1..-1] -ne "\") { $Catch2 = ($Catch2 + "\") }
        Say "Go $Catch1 Setting you to Root of $Catch2"
        Set-Location $Catch2
        return
    }
    else {
        $Catch2 = (Get-Location).Drive.Root
        Say "Go $Catch1 Setting you to Root of $Catch2"
        Set-Location $Catch2
        return
    }
}
else {
    $Where = ("Go-" + $Catch1)
    $Where = $Where.trim()
    $Where = ($env:BASE + "\" + $where + ".ps1")
    $Filetest = Test-Path -path $where
    if ($Filetest -eq $true) {
        & $where $Catch2
        return
    }
    else {
        if ($Catch1[-1..-1] -eq ":") { $Catch1 = ($Catch1 + "\") }
        Try { Set-Location $Catch1 -ErrorAction Stop }
        Catch [System.Exception] { Say -ForeGroundColor RED  "Go could not find the location:" $catch1.ToUpper() }
        Finally { Say "" }
        return
    }
}
