$FileVersion = "0.0.1"
#NOT WORKING
[reflection.assembly]::loadwithpartialname("System.Windows.Forms")
[reflection.assembly]::loadwithpartialname("System.Drawing")
$notify = new-object system.windows.forms.notifyicon
$notify.icon = [System.Drawing.SystemIcons]::Information
$notify.visible = $true
$notify.showballoontip(10, "New Chat!", "You have received New Chat!", [system.windows.forms.tooltipicon]::None)
