$FileVersion = "0.0.1"
$Global:OutGUID = '{' + [guid]::NewGuid().ToString() + '}'
Say $OutGUID
Say 'You can use the variable $OutGUID at any time now'
