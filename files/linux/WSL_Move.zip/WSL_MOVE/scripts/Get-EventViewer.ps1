Write-Output "List of custom views on the machine"
Write-Output ""
Get-ChildItem "C:\ProgramData\Microsoft\Event Viewer\Views" -Filter *.xml | ForEach-Object { Select-Xml -Path $_.FullName -XPath "//Name" } | Select-Object -ExpandProperty Node | Select-Object -ExpandProperty InnerXml

Write-Output ""
$view_name = Read-Host "Enter the name of custom view to execute"


# Get the file name of the view
$ViewFile = Get-ChildItem "C:\ProgramData\Microsoft\Event Viewer\Views" -Filter *.xml | Where-Object { (Select-Xml -Path $_.FullName -XPath "//Name").Node.InnerXml -eq $view_name }

Get-WinEvent -FilterXml ([xml]((Select-Xml -Path $ViewFile.FullName -XPath "//QueryList").node.OuterXml))
