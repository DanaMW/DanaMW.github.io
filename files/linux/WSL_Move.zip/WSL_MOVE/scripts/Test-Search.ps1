$search = Invoke-WebRequest "http://stackoverflow.com/search?q=$arg"

The cmdlet returns a response that can be filtered and iterated to write out on the console.

$results = $search.links | where href -like "*/questions/*"
foreach ($result in $results)
{
  $count += 1
    if ($result.href -notlike "*/questions/tagged*")
    {
        Write-Host [$count]  -foregroundcolor DarkMagenta
        Write-Host $result.InnerText
    }
}

Prefacing the results with a number will allow you to then select a result on your console and invoke another Invoke-WebRequest of the results to read the actual questions and answers to the post you selected on the forum.

$getlink = Read-Host "Select the linkt you want to view"
[int]$i = $getlink-1
# gets content of the selected post
$var = $results[$i].href
Write-Host You selected $results[$i].InnerText uri $var
$data = Invoke-WebRequest "http://stackoverflow.com$var"

Write-Host ************ Posted Question ************
# write the posted question
$data.ParsedHtml.getElementsByTagName("div") |  Where "id" -match "question-header" | Select -ExpandProperty InnerText
$data.ParsedHtml.getElementsByTagName("div") |  Where "classname" -match "^question" | Select -ExpandProperty InnerText

Write-Host ************ Posted Answer ************
# write the posted accepted-answer first
$data.ParsedHtml.getElementsByTagName("div") |  Where "classname" -match "answer accepted-answer" | Select -ExpandProperty InnerText

# write the posted all other answers
$data.ParsedHtml.getElementsByTagName("div") |  Where "classname" -match "answer" | Select -ExpandProperty InnerText
