<#
.SYNOPSIS
        Run-SetFileVer
        Created By: Dana Meli
        Created Date: April, 2018
        Last Modified Date: September 19, 2019

.DESCRIPTION
        This script is designed to Increment DeIncrement Get Set or Add
         the version number of any ps1 script. This is done in the format
         that I currently use. [$FileVersion = "Version: 0.0.0"]

.EXAMPLE
        Run-SetFileVer -File D:\bin\bin* -Action GET

.EXAMPLE
        Run-SetFileVer -File D:\bin\bin* -Action SET -Version 1.0.0

.EXAMPLE
        Run-SetFileVer -File D:\bin\SomeScript.ps1 -Action ADD -Version 0.0.1

.EXAMPLE
        Run-SetFileVer -File D:\bin\BinMenu.ps1 -Action INC/DEC/GET/SET/ADD -Version #.#.#

.NOTES
        Still under development.

#>
Param([String]$File, [String]$Action, [String]$Version)
$FileVersion = "Version: 0.0.4"
if (!($File)) {
    Say "Run-SetFileVer" $FileVersion
    Say ""
    Say "Run-SetFileVer -File C:\File\Pattern\ToUpdate -Action INC/DEC/GET/SET/ADD -Version #.#.#"
    Say ""
    return
}
if ($File -notmatch "PS1") {
    $File = ($File + ".ps1")
}
$old_ErrorActionPreference = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
#
# NOTES Exclude any file that matches more than once per file AND
# ADD should only add to files that dont currently have a version.
# AND the ps1 extension should be a given and add automatically.
# Exclude comments from add
# complete INC and DEC
#
if ($File -match "SetFileVer") {
    Say "Run-SetFileVer" $FileVersion
    Say ""
    Say "Can NOT be run on itself at this time"
    Say "Run-SetFileVer -File C:\File\Pattern\ToUpdate -Action INC/DEC/GET/SET/ADD -Version #.#.#"
    Say ""
    $ErrorActionPreference = $old_ErrorActionPreference
    return
}
$List = Get-Item $File
$FCount = $List.count
if (!($Action)) { $Action = "GET" }
if (!($Version)) { $Version = "0.0.1" }
if ($Action -eq "GET") {
    $i = 0; $t = 1
    Say "Run-SetFileVer" $FileVersion
    Say ""
    While ($i -le ($FCount - 1)) {
        Say "[$t]"  $list[$i]
        Get-Content $list[$i] | ForEach-Object { if ($_ -match "Version:") { Write-Host "[$t]" $_ } }
        Say ""
        $i++
        $t++
    }
    $ErrorActionPreference = $old_ErrorActionPreference
}
if ($Action -eq "INC") {
    $i = 0; $t = 1
    Say "Run-SetFileVer" $FileVersion
    Say ""
    While ($i -le ($FCount - 1)) {
        Say "[$t]"  $list[$i]
        #Get-Content $list[$i] | ForEach-Object { if ($_ -match "FileVersion =") { Write-Host $_ } }
        $i++
        $t++
    }
    $ErrorActionPreference = $old_ErrorActionPreference
}
if ($Action -eq "DEC") {
    $i = 0; $t = 1
    Say "Run-SetFileVer" $FileVersion
    Say ""
    While ($i -le ($FCount - 1)) {
        Say "[$t]"  $list[$i]
        #Get-Content $list[$i] | ForEach-Object { if ($_ -match "FileVersion =") { Write-Host $_ } }
        $i++
        $t++
    }
    $ErrorActionPreference = $old_ErrorActionPreference
}
if ($Action -eq "SET") {
    $i = 0; $t = 1
    Say "Run-SetFileVer" $FileVersion
    Say ""
    While ($i -le ($FCount - 1)) {
        Say "[$t]"  $list[$i]
        Get-Content $list[$i] | ForEach-Object { if ($_ -match "Version:") { $Find = $_ } }
        $Change = "$" + "FileVersion = `"Version: $Version`""
        (Get-Content $list[$i]).replace($find, $Change) | Set-Content $list[$i]
        Say "Success in SET Version $Version in $File"
        $i++
        $t++
    }
    $ErrorActionPreference = $old_ErrorActionPreference
}
if ($Action -eq "ADD") {
    $i = 0; $t = 1
    Say "Run-SetFileVer" $FileVersion
    Say ""
    While ($i -le ($FCount - 1)) {
        Say "[$t]"  $list[$i]
        Get-Content $list[$i][0] | ForEach-Object { if ($_ -match "Version:" -or $_ -match "Param" -or $_ -match "#>") { $Find = $_ } }
        $Change = "$" + "FileVersion = `"Version: $Version`""
        if (($find)) {
            if ($Find -match "Version:") {
                Say "$File already has a version. Exiting"
                Say ""
                return
            }
            (Get-Content $list[$i]).replace($find, "$Find`n$Change") | Set-Content $list[$i]
            Say "Success in ADD Version $Version in $File"
        }
        else {
            $Read = (Get-Content $list[$i])
            $Read = "$Change`n$Read"
            Set-Content $list[$i] $Read
            Say "Success in ADD Version $Version in $File"
        }
        Say $Find
        Say $Change
        Say $Version
        $i++
        $t++
    }
    $ErrorActionPreference = $old_ErrorActionPreference
}
$ErrorActionPreference = $old_ErrorActionPreference
Say "All Done."
