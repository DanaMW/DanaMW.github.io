$FileVersion = "0.0.9"
Say "Run Visual Studio $FileVersion"
$ANS = Put-Pause -Prompt "~DARKCYAN~[~~DARKRED~(~~WHITE~1~~DARKRED~)~~YELLOW~Installer~ ~DARKRED~(~~WHITE~2~~DARKRED~)~~YELLOW~Visual Studios~~DARKCYAN~]~~WHITE~: ~" -Max 0 -Echo 1
Say $ANS
if ($ANS -eq "1") {
    Say "Running Visual Studio Installer for you now."
    $Prog = "C:\Program Files (x86)\Microsoft Visual Studio\Installer\setup.exe"
    & $Prog
}
elseif ($ANS -eq "2") {
    Say "Running Visual Studio for you now."
    $Prog = "C:\Program Files\Microsoft Visual Studio\2022\Preview\Common7\IDE\devenv.exe"
    & $Prog
}
else { break }
