if ($args) {
    [string]$Catch0 = $args[0]
    [string]$Catch1 = $args[1]
    [string]$Catch2 = $args[2]
    [string]$Catch3 = $args[3]
    [string]$Catch4 = $args[4]
    [string]$Catch5 = $args[5]
    [string]$Catch6 = $args[6]
    [string]$Catch7 = $args[7]
    [string]$Catch8 = $args[8]
    [string]$Catch9 = $args[9]
}
$FileVersion = "0.0.15"
if ($Catch0 -eq "UP") {
    Say "Rachet Up"
    Say "uGet";
    Start-Process "D:/bin/uget/bin/uget.exe"
    Say "Rainmeter"
    Start-Process "D:/bin/Rainmeter/Rainmeter.exe"
    Say "ditto"
    Start-Process "D:/bin/ditto/ditto.exe"
    Say "ConEmu64"
    Start-Process "D:/bin/ConEmu/ConEmu64.exe"
    return
}
elseif ($Catch0 -eq "DOWN") {
    Say "Rachet Down"
    Say "uGet"; $uGet = Get-Process "uGet"; if (($uGet)) { Stop-Process $uGet.Id }
    Say "Rainmeter"; $Rainmeter = Get-Process "Rainmeter"; if (($Rainmeter)) { Stop-Process $Rainmeter.Id }
    Say "ditto"; $ditto = Get-Process "ditto"; if (($ditto)) { Stop-Process $ditto.Id }
    Say "pwsh"; $pwsh = Get-Process "pwsh"; if (($pwsh)) { Stop-Process $pwsh.Id }
    Say "Ubuntu"; $Ubuntu = Get-Process "Ubuntu"; if (($Ubuntu)) { Stop-Process $Ubuntu.Id }
    Say "Fedora"; $fedora = Get-Process "Fedora"; if (($fedora)) { Stop-Process $fedora.Id }
    Say "ConEmu"; $ConEmu64 = Get-Process "ConEmu64"; if (($ConEMu)) { Stop-Process $ConEmu64.Id }
    Say "OneDrive"; $OneDrive = Get-Process "OneDrive"; if (($OneDrive)) { Stop-Process $OneDrive.Id }
    Say "MegaSync"; $MegaSync = Get-Process "MegaSync"; if (($MegaSync)) { Stop-Process $MegaSync.Id }
    Say "ConEmu"; $ConEmu64 = Get-Process "ConEmu64"; if (($ConEMu)) { Stop-Process $ConEmu64.Id }
    Say "Done."
    return
}
elseif ($Catch0 -eq "KILL") {
    if (($Catch1)) {
        $ans = Get-Process $Catch1;
        Stop-Process $ans.Id
        Say $ans.name "was killed if you did not see an error."
    }
    else {
        Say "Kill was selected"
        Say "Enter the name of the program to get ride of."
        $ans = Read-Host -Prompt "[Enter name or (Q)uit]: "
        if ($ans -eq "Q") { return }
        else {
            Say $ans "was input.";
            $ans = Get-Process $ans;
            Stop-Process $ans.Id
            Say $ans.name "was killed if you did not see an error."
        }
    }
}
else {
    Say "Ratchet UP"
    Say "Ratchet DOWN"
    Say "Ratchet KILL [Named Program]"
    Say "Ratchet $FileVersion"
}
