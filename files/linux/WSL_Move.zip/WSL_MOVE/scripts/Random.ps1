$MyArgs = "$args"
if (!($MyArgs )) { $MyArgs = 1000 }
$Global:Random = (Get-Random $MyArgs)
Say $Random
