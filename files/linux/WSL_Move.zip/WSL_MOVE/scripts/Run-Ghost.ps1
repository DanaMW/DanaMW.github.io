$FileVersion = "Version: 0.0.5"
Say "Do-Ghost $FileVersion running now..."
Set-Variable -Name DEVMGR_SHOW_NONPRESENT_DEVICES -Value "1"
Set-Location "C:\"
Set-Location "C:\Windows\system32"
Start-Process DEVMGMT.MSC -Wait
Remove-Variable -Name DEVMGR_SHOW_NONPRESENT_DEVICES
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
