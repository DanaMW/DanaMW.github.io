$FileVersion = "0.0.4"

<#
Find all Thumbs.db and get them the fuck off my machine.
#>
Get-ChildItem "C:\" -Filter 'Thumbs.db' -Force -Recurse -ErrorAction SilentlyContinue |
Say "$_"
# Remove-Item "Thumbs.db"
# Get-ChildItem "D:\" -Filter 'Thumbs.db' -Force -Recurse |
# Remove-Item "Thumbs.db"
#Remove-Item "C:\" -include "Thumbs.db" -recurse -force -Verbose
#Remove-Item "D:\" -include "Thumbs.db" -recurse -force -Verbose
#Get-Item "C:\" -include "Thumbs.db" -Verbose
