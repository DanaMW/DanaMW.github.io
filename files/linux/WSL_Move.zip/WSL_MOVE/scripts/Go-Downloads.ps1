$FileVersion = "Version: 0.1.6"
Say "Go $FileVersion Setting your location to Variable [DOWNLOADS] $env:DOWNLOADS"
Set-Location $env:DOWNLOADS.substring(0, 3)
Set-Location $env:DOWNLOADS
