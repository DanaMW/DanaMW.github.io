WMIC bios get /format:list
