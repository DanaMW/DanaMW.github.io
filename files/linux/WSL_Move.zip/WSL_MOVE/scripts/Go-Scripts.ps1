$FileVersion = "Version: 0.1.6"
Say "Go $FileVersion Setting your location to D:\WebBase\wwwroot\Scripts\"
Set-Location "D:\"
Set-Location "D:\WebBase\wwwroot\Scripts\"
