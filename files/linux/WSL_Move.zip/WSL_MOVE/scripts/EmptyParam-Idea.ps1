#if (($PSCmdlet.MyInvocation.BoundParameters["about"].IsPresent)) {
#    Say "Put-Pause" $FileVersion
#    Say "Usage: Put-Pause.ps1 [[-Prompt] <string>] [[-max] <int>] [[-Default] <string>] [-about]"
#}
#or
#The below does it perfect

$Host.UI.RawUI.FlushInputBuffer()

#
#function clrkb {
#    while (
#        $Host.UI.RawUI.KeyAvailable) {
#        $Host.UI.RawUI.ReadKey() | Out-Null
#    }
#}
