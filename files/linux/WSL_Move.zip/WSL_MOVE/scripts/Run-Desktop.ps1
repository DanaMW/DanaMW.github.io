$FileVersion = "Version: 0.0.3"
Say "Do Github Desktop Setup $FileVersion"
Say "Running GithubDesktop"
& "C:\Users\Dana\AppData\Local\GitHubDesktop\GitHubDesktop.exe"
