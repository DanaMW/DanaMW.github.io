$FileVersion = "Version: 0.0.5"
Clear-Host
Say "Get More SysInfo $FileVersion"
systeminfo.exe /fo csv | ConvertFrom-Csv | Select-Object OS*, System*, Hotfix* | Format-List
#[Console]::SetCursorPosition(0, 26)
$menuPrompt = WCP "~DARKCYAN~[~~WHITE~Enter To Continue~~DARKCYAN~]~~WHITE~:~ "
$pop = Read-Host -Prompt $menuPrompt;
#systeminfo.exe
#[Console]::SetCursorPosition(0, 26)
# $menuPrompt = WCP "~cyan~[~~darkyellow~Enter To Continue~~cyan~]~~white~: ~"
#$pop = Read-Host -Prompt $menuPrompt
if ($pop -eq "") { break }
