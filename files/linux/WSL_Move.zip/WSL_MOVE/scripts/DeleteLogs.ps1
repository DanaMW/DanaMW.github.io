wevtutil el | Foreach-Object { wevtutil cl "$_" }
