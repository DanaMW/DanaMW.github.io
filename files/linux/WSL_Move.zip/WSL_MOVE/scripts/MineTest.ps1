$MyArgs = "$args"
$FileVersion = "0.0.3"
Say "Run Minetest $FileVersion"
if ($MyArgs -eq 0) {
    Say ""
    D:\MineTest\Bin\minetest.exe
}
if ($MyArgs -eq 1) {
    Say "Running CrazyLand"
    D:\MineTest\Bin\minetest.exe -Server -WorldName CrazyLand --Config D:\MineTest\Bin\crazyland.conf
}
if ($MyArgs -eq 2) {
    Say "Running Metropolis"
    D:\MineTest\Bin\minetest.exe --Server --WorldName Metropolis --Config D:\MineTest\Bin\Metropolis.conf
}
