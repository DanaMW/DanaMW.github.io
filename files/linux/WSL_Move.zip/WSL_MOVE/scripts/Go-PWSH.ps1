$FileVersion = "0.1.7"
Say "GO $FileVersion Setting your location to PowerShell Main"
Set-Location "C:\"
Set-Location "C:\Program Files\PowerShell"
