$FileVersion = "Version: 0.1.6"
Say "GO $FileVersion Setting your location to PowerShell Main"
Set-Location "C:\"
Set-Location "C:\Program Files\PowerShell"
