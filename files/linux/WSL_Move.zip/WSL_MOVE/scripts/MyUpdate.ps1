& Find-Module PowerShellGet
& Update-Module PowerShellGet
& Find-Script Update-PowerShell
& Update-Script Update-PowerShell
