$FileVersion = "0.0.2"
Say "MyUpdate $FileVersion"
& Find-Module PowerShellGet
& Update-Module PowerShellGet
& Find-Script Update-PowerShell
& Update-Script Update-PowerShell
