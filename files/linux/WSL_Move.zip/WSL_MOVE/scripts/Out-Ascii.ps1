$FileVersion = "Version: 0.1.0"
[string]$MyArgs = $args
Function Stop {
    Read-Host -Prompt $args
}
[string]$hexword = [string]$MyArgs
$n = 0
while ($n -lt $hexword.length) {
    $hexword = $hexword -replace " ", "_"
    [int]$hexchar = [int][char]$hexword.substring($n, 1)
    [int]$hexval1 = [Math]::Truncate([int]$hexchar / 16)
    [int]$hexval2 = (([int]$hexchar - ([int]$hexval1) * 16))
    if ($hexval1 -eq 10) { $hexval11 = "A" }
    if ($hexval1 -eq 11) { $hexval11 = "B" }
    if ($hexval1 -eq 12) { $hexval11 = "C" }
    if ($hexval1 -eq 13) { $hexval11 = "D" }
    if ($hexval1 -eq 14) { $hexval11 = "E" }
    if ($hexval1 -eq 15) { $hexval11 = "F" }
    else { $hexval11 = $hexval1 }
    if ($hexval2 -eq 10) { $hexval22 = "A" }
    if ($hexval2 -eq 11) { $hexval22 = "B" }
    if ($hexval2 -eq 12) { $hexval22 = "C" }
    if ($hexval2 -eq 13) { $hexval22 = "D" }
    if ($hexval2 -eq 14) { $hexval22 = "E" }
    if ($hexval2 -eq 15) { $hexval22 = "F" }
    else { $hexval22 = $hexval2 }
    [string]$hexchar = "$hexval11$hexval22"
    $hexcomp = "$hexcomp$hexchar"
    $n++
    if ($n -gt $hexword.length) { Say $hexcomp; return }
}
Say ""
Say "Out-Ascii $FileVersion"
Say ""
Say $hexcomp
Say ""
