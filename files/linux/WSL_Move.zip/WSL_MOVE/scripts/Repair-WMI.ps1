$FileVersion = "0.0.3"
$MyArgs = $args
Clear-Host
Say "$MyArgs"
if ($MyArgs -eq "REBUILD") {
    Say "WMI-Repair $FileVersion Rebuilding the WMI Repository"
    SC config winmgmt start= disabled
    net stop winmgmt
    Winmgmt /salvagerepository %windir%\System32\wbem
    Winmgmt /resetrepository %windir%\System32\wbem
    SC config winmgmt start= auto
}
if ($MyArgs -eq "REPAIR") {
    Say "WMI-Repair $FileVersion Repairing the WMI Repository"
    SC config winmgmt start= disabled
    net stop winmgmt
    Rename-Item -Path "C:\Windows\System32\wbem\repository" -NewName "C:\Windows\System32\wbem\repository.old"
    SC config winmgmt start= auto
    Say "A reboot is required now to complete the repair"
    $MyQ = Read-Host -Prompt "Reboot? (Y)es (N)o [Enter equals NO]"
    if ($MyQ -eq "Y") {
        Start-Process "pwsh.exe" -ArgumentList ($env:BASE + "\reboot.ps1")
    }
}
if ($MyArgs -eq "REGISTER") {
    Say "WMI-Repair $FileVersion Registering files in the WMI Repository"
    Say "Registering all of the DLL's, Recompiling the .mofs in the wbem folder, Registering WMI Service and Provider."
    Set-Location "C:"
    Set-Location "C:\Windows\System32\Wbem"
    #SC config winmgmt start= disabled
    #NET STOP winmgmt /y
    #for /f %%s in ('dir /b *.dll') do regsvr32 /s %
    #wmiprvse /regserver
    #winmgmt /regserver
    #sc config winmgmt start= auto
    #net start winmgmt
    #for /f %s in ('dir /s /b *.mof *.mfl') do mofcomp %s
    #b. Reboot the machine and test WMI
    #Warning: Rebuilding the WMI repository has resulted in some 3rd party products not working until their setup is re-run & their MOF re-added back to the repository.
    <#
    If /salvagerepository or /resetrepository does not resolve the issue, then manually rebuild repository:
    1. Change startup type to Window Management Instrumentation (WMI) Service to disabled
    2. Stop the WMI Service; you may need to stop IP Helper Service first or other dependent services before it allows you to stop WMI Service
    3. Rename the repository folder: C:\WINDOWS\system32\wbem\Repository to Repository.old
    4. Open a CMD Prompt with elevated privileges
    5. CD C:\windows\system32\wbem
    6. for /f %s in ('dir /b /s *.dll') do regsvr32 /s %s
    7. Set the WMI Service type back to Automatic and start WMI Service
    8. cd /d c:\ ((go to the root of the c drive, this is important))
    9. for /f %s in ('dir /s /b *.mof *.mfl') do mofcomp %s
    10. Reboot the server
    Win2012 Possible Fix.
    Go to C:\WINDOWS\system32\wbem\
    Rename Repository to Repository.old
    Locate a Repository.xxx folder from a date before WMI was broken and rename to Repository.
    Reboot Server
    #>
}
Say ""
Say "The Options for this sript are:"
Say "WMI-Repair [Rebuild] [Repair] or [Register]"
Say ""
