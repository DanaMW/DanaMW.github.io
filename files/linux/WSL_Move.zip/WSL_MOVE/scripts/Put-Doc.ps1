$MyArgs = $args
$FileVersion = "Version: 0.1.7"
if ($env:USERDOMAIN -ne "TINMAN") {
    Say "This script is designed to run only on TINMAN"
    Say "Exiting on" $env:USERDOMAIN
    break
}
Say "Running Put Documents $FileVersion"
Say "Starting the put process."
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
Say ""
$Filetmp = ($env:BASE + "\Put-Doc.tmp")
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
$Dirtmp = ($env:BASE + "\Put-Dir.tmp")
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
$GetDir = "D:\Documents"
$Dest = "C:\Users\Dana\OneDrive\Documents"
$Dirchk = $Dest
$FileTest = Test-Path -path $Dirchk -PathType Container
if ($FileTest -ne $true) {
    Say "Directory does not exist, creating $Dest"
    New-Item -Path $Dest -Name $Read -ItemType "directory"
}
Get-ChildItem -Path $GetDir -Attributes Directory -Name -Recurse | Sort-Object | Out-File $Dirtmp
$Lines = (Get-Content $Dirtmp).count
$i = 0
While ($i -lt $Lines) {
    $Read = (Get-Content $Dirtmp)[$i]
    $Dirchk = "$Dest\$Read"
    $FileTest = Test-Path -path $Dirchk -PathType Container
    if ($FileTest -ne $true) {
        Say "Directory does not exist, creating $Dest\$Read"
        New-Item -Path $Dest\ -Name $Read -ItemType "directory" | Out-Null
    }
    $i++
}
$MoveDir = $i
Clear-Variable "i"
Clear-Variable "Lines"
Clear-Variable "Read"
Get-ChildItem -Path $GetDir -Name -File -Recurse | Sort-Object | Out-File $Filetmp
$Lines = (Get-Content $filetmp).count
$i = 0
While ($i -lt $Lines) {
    $Read = (Get-Content $filetmp)[$i]
    $Dirchk = "$Dest\$Read"
    Say "Copying $Dest\$Read"
    Copy-Item $GetDir\$Read -Destination $Dest\$Read -Recurse -Force
    $i++
}
Set-Location $env:BASE.substring(0, 3)
Set-Location $Env:BASE
$FileTest = Test-Path -path $Filetmp
if ($FileTest -eq $true) { Remove-Item -path $Filetmp }
$FileTest = Test-Path -path $Dirtmp
if ($FileTest -eq $true) { Remove-Item -path $Dirtmp }
Say "Created $MoveDir Directories."
Say "Copied $i Files"
Say "We are ALL DONE."
