if (($args[0])) { $Catch1 = $args[0] }
if (($args[1])) { $Catch2 = $args[1] }
if (($args[2])) { $Catch3 = $args[2] }
if (($args[3])) { $Catch4 = $args[3] }
if (($args[4])) { $Catch5 = $args[4] }
if (($args[5])) { $Catch6 = $args[5] }
if (($args[6])) { $Catch7 = $args[6] }
if (($args[7])) { $Catch8 = $args[7] }
$FileVersion = "Version: 0.1.5"
if (!($Catch1)) {
    Say "Run" $FileVersion
    Say "Pick One, try again."
    Get-Files.ps1 ($env:BASE + "\Run-*")
    return
}
else {
    #find the file
    $Where = ("Run-" + $Catch1)
    $Where = ($PSScriptRoot + "\" + $where.trim() + ".ps1")
    $Filetest = Test-Path -path $where
    if ($Filetest -eq "True") {
        if ($null -ne $Catch2) { & $Where $Catch2 $Catch3 $Catch4 $Catch5 $Catch6 $Catch7 $Catch8 }
        else { & "$Where" }
        return
    }
    else {
        $Where = ("Run-" + $Catch1)
        $Worked = Get-Command $where -ErrorAction SilentlyContinue
        if ($null -ne $Worked) {
            if ($null -ne $Catch2) { & $Where $Catch2 $Catch3 $Catch4 $Catch5 $Catch6 $Catch7 $Catch8 }
            else { & "$Where" }
            return
        }
        else {
            Say "Run" $FileVersion
            Say "Pick One, try again."
            Get-Files.ps1 ($env:BASE + "\Run-*")
            return
        }
    }
}
