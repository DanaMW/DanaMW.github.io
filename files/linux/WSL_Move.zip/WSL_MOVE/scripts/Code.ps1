if (($args)) {
    Start-Process -FilePath "C:\Program Files\Microsoft VS Code\Code.exe" -ArgumentList $args
    return
}
else {
    Start-Process -FilePath "C:\Program Files\Microsoft VS Code\Code.exe"
    return
}
