$FileVersion = "0.0.2"
if (($args)) {
    Say "Run Code $FileVersion"
    Start-Process -FilePath "C:\Program Files\Microsoft VS Code\Code.exe" -ArgumentList $args
    return
}
else {
    Say "Run Code $FileVersion"
    Start-Process -FilePath "C:\Program Files\Microsoft VS Code\Code.exe"
    return
}
