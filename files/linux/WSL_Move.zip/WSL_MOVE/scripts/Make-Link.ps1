Param([String]$target, [String]$link)
$FileVersion = "Version: 0.0.5"
if (!($target) -or !($link)) {
    Say ""
    Say "Make-Link $FileVersion"
    Say 'Make-Link -Target "C:\RealDir" -link "C:\CreateLink"'
    Say "Target: Actual directory you are linking to."
    Say "Link..: Directory link to create to link to the real one."
    Say ""
    return
}
if (!($link)) {
    Say ""
    Say "Make-Link $FileVersion"
    Say 'Make-Link -Target "C:\RealDir" -link "C:\CreateLink"'
    Say "Target: Actual directory you are linking to."
    Say "Link..: Directory link to create to link to the real one."
    Say ""
    return
}
if (!(Test-Path $target)) {
    Say ""
    Say "Make-Link $FileVersion"
    Say -ForegroundColor Red "ERROR: The path" $target.ToUpper() "does not exist."
    Say ""
    return
}
New-Item -Path $link -ItemType SymbolicLink -Value $target
