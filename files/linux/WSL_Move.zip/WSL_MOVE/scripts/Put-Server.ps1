$MyArgs = $args
$fileVersion = "Version: 0.0.4"
if ($env:USERDOMAIN -ne "TORCHLIGHT") {
    Say "This script is designed to run only on TORCHLIGHT"
    Say "Exiting on" $env:USERDOMAIN
    break
}
if ($MyArgs = "ALL") {
    Say "Put Server All $FileVersion"
    [string]$sourceDirectory = "D:\WebBase\wwwroot\*"
    [string]$destinationDirectory = "C:\inetpub\wwwroot\"
    Copy-Item -Force -Verbose -Recurse $sourceDirectory -Destination $destinationDirectory
}
if (!($MyArgs)) {
    Say "Put Server SCRIPTS $FileVersion"
    [string]$sourceDirectory = "D:\WebBase\wwwroot\scripts\*"
    [string]$destinationDirectory = "C:\inetpub\wwwroot\scripts\"
    Copy-Item -Force -Verbose $sourceDirectory -Destination $destinationDirectory
}
