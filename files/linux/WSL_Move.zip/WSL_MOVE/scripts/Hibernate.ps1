Param([string]$turn)
$FileVersion = "0.1.2"
$Shelp = "YES"
if ($turn -eq "ON") {
    Say "Enabling Hibernate"
    $Shelp = "NO"
    powercfg.exe /hibernate ON
}
if ($turn -eq "ENABLE") {
    Say "Enabling Hibernate"
    $Shelp = "NO"
    powercfg.exe /hibernate ON
}
if ($turn -eq "OFF") {
    Say "Disabling Hibernate"
    $Shelp = "NO"
    powercfg.exe /hibernate OFF
}
if ($turn -eq "DISABLE") {
    Say "Disabling Hibernate"
    $Shelp = "NO"
    powercfg.exe /hibernate OFF
}
if ((Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\Power).HibernateEnabled -eq 1) { $tmp = "Hibernate Is Enabled" }
else { $tmp = "Hibernate Is Disabled" }
WC "~white~Hibernate Toggle~~darkcyan~/~~white~Check $FileVersion Reports ~~darkred~(~~darkyellow~$tmp~~darkred~)~"
if ($Shelp -eq "YES") {
    Say "Hibernate ON/OFF/ENABLE/DISABLE"
    Say "Hibernate -Turn ON/OFF/ENABLE/DISABLE"
}
