Param([string]$turn)
$FileVersion = "Version: 0.1.0"
if ($turn -eq "ON") {
    Say "Enabling Hibernate"
    powercfg.exe /hibernate ON
}
if ($turn -eq "OFF") {
    Say "Disabling Hibernate"
    powercfg.exe /hibernate OFF
}
if ((Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Control\Power).HibernateEnabled -eq 1) { $tmp = "Hibernate Is Enabled" }
else { $tmp = "Hibernate Is Disabled" }
Say "Hibernate Toggle/Check" $FileVersion "Reports" $tmp
