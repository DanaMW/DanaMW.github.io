﻿<#
.SYNOPSIS
        Put-Pathist
        Created By: Dana Meli
        Created Date: June, 2019
        Last Modified Date: June 18, 2020

.DESCRIPTION
        This returns a list for folders or files from the the specified path to a text file.

.EXAMPLE
        Put-Pathlist [-Target <C:\DirectoryToRead>] [-File <C:\FileToWrite.ext>] [{-Folder | -File | -All}]

        -Type is the list you want to write to file. List of files or list of folders.

.NOTES
        Still under development.
#>
Param([string]$Target, [String]$OutFile, [switch]$Folder, [switch]$File, [switch]$All)
$FileVersion = "0.0.4"
if (!$PSBoundParameters.ContainsKey('Target')) {
    Say -ForegroundColor RED "ERROR: A -Target diretory is required."
    WC "~red~~USAGE~~white~: ~~darkcyan~Put-Pathlist~ ~white~[~~cyan~-Target <C:\DirectoryToRead>~~white~] [~~cyan~-File <C:\FileToWrite.ext>~~white~] [~~cyan~{-Folder | -File | -All}~~white~]~"
    return
}
if (!$PSBoundParameters.ContainsKey('OutFile')) {
    Say -ForegroundColor RED "ERROR: A -Target diretory is required."
    WC "~red~~USAGE~~white~: ~~darkcyan~Put-Pathlist~ ~white~[~~cyan~-Target <C:\DirectoryToRead>~~white~] [~~cyan~-File <C:\FileToWrite.ext>~~white~] [~~cyan~{-Folder | -File | -All}~~white~]~"
    return
}
Say "Target $Target"
Say "OutFile $OutFile"
if (!($Folder) -and !($File) -and !($All)) {
    Say -ForegroundColor RED "ERROR: A Type must declared -Folder, -File or -All." $Folder
    WC "~red~~USAGE~~white~: ~~darkcyan~Put-Pathlist~ ~white~[~~cyan~-Target <C:\DirectoryToRead>~~white~] [~~cyan~-File <C:\FileToWrite.ext>~~white~] [~~cyan~{-Folder | -File | -All}~~white~]~"
    return
}
if (($Folder)) {
    $Type = "Container"
    $Pathtest = Test-Path -path $Target -PathType Container
    if ($Pathtest -ne $true) {
        Say -ForegroundColor RED "ERROR: Your -Target was not found."
        return
    }
}
if (($File)) {
    $Type = "Leaf"
    $Pathtest = Test-Path -path $Target -PathType Leaf
    if ($Pathtest -ne $true) {
        Say -ForegroundColor RED "ERROR: Your -Target was not found."
        return
    }
}
if (($All)) { $Type = "ALL" }
Say "Put-PathList $FileVersion"
$Filetest = Test-Path -path $OutFile
if ($Filetest -eq $true) { Remove-Item –path $OutFile }
if ($Type -eq "Container") { Get-ChildItem -Path $Target -Directory -Name | Sort-Object | Out-File $OutFile }
if ($Type -eq "Leaf") { Get-ChildItem -Path $Target -File -Name | Sort-Object | Out-File $OutFile }
if ($Type -eq "ALL") { Get-ChildItem -Path $Target -Name | Sort-Object | Out-File $OutFile }
