$FileVersion = "0.0.3"
Say "Running Test Key $Fileversion"
while (1) {
    # Cursor Position
    #$X = $host.ui.rawui.CursorPosition.X
    #$Y = $host.ui.rawui.CursorPosition.Y
    #Write-Output "X: $X | Y: $Y"
    #===================
    # The key Pressed (This one reads ALL keys)
    #$key = $Host.UI.RawUI.ReadKey('IncludeKeyUp, IncludeKeyDown')
    #$key = $Host.UI.RawUI.ReadKey()
    #if ($key.Character -eq 'x') { return }
    #==============
    # This does not read shift, control and the like
    $KeyPress = [System.Console]::ReadKey("true");
    #$KeyPress = Console.ReadKey(true)
    $K = $KeyPress.Key
    Say "Key Char: $k"
    if ($k -eq 'x') { return }
}
