$FileVersion = "Version: 0.0.16"
Clear-Host
Say "Update Github $FileVersion, Updating All"
Go-BetterDiscordApp.ps1
Go-BurntToast.ps1
Go-Clavier.ps1
Go-ConEmu.ps1
Go-GoogIeImagesRestored.ps1
Go-MyTwitter.ps1
Go-OneDrive.ps1
Go-PerfectScrollbar.ps1
Go-Rainmeter.ps1
Go-Savein.ps1
Go-Shotcut.ps1
Go-Stylus.ps1
Go-TwitBot.ps1
Go-WinAuth.ps1
Clear-Host
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
