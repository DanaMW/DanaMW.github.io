$FileVersion = "0.1.24"
Clear-Host
$C = 0
$PrettyBar = "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
Say "Update Github $FileVersion, Updating All"
Say -ForeGroundColor RED $PrettyBar
$C++
Update-WinAuth.ps1
Say -ForeGroundColor RED $PrettyBar
$C++
Update-userchromejs.ps1
Say -ForeGroundColor RED $PrettyBar
Say "All done updating my $C GitHub repositories"
Say ""
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
$ans = ""
$ans = Put-Pause -Prompt "~darkcyan~[~~darkyellow~Clear the screen? ~~red~(~~white~Y~~red~/~~white~N~~red~)~~darkcyan~]~~white~:~ " -Default "Y" -Echo 1
if ($ans -eq "Y") { Clear-Host }
$ans = ""
