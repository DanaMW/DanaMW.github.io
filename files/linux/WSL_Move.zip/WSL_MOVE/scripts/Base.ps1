<#
.SYNOPSIS
        Base
        Created By: Dana Meli
        Created Date: April, 2019
        Last Modified Date: December 31, 2019
.DESCRIPTION
        This script lists all my scripts that are BASE of groups.
        Such as Go, Edit, Get, Out, Put, Repair, Run and Update.
.EXAMPLE
        Base.ps1
.NOTES
        Still under development.
#>
$FileVersion = "Version: 0.1.4"
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
WC ""
WC "Base $FileVersion"
WC "Listing your BASE group scripts."
WC "~red~#~~darkred~=-=-=-=-=-=-=-=-=-~~red~#~"
WC "~darkred~| ~cyan~[~~white~ 1~~cyan~] ~~green~Edit.ps1~    ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 2~~cyan~] ~~green~Find.ps1~    ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 3~~cyan~] ~~green~Get.ps1~     ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 4~~cyan~] ~~green~Go.ps1~      ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 5~~cyan~] ~~green~Out.ps1~     ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 6~~cyan~] ~~green~Put.ps1~     ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 7~~cyan~] ~~green~Repair.ps1~  ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 8~~cyan~] ~~green~Run.ps1~     ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~ 9~~cyan~] ~~green~Test.ps1~    ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~10~~cyan~] ~~green~Update.ps1~  ~darkred~|~"
WC "~darkred~| ~cyan~[~~white~11~~cyan~] ~~green~Write.ps1~   ~darkred~|~"
WC "~red~#~~darkred~=-=-=-=-=-=-=-=-=-~~red~#~"
$menuPrompt = WCP "~darkcyan~[~~darkyellow~Select ~~white~1-11~~darkyellow~, Enter to Quit~~darkcyan~]~~white~: ~"
$Ans = Read-Host -Prompt $menuPrompt
if ($Ans -eq 1) { & ($env:BASE + "\Edit.ps1") }
if ($Ans -eq 2) { & ($env:BASE + "\Find.ps1") }
if ($Ans -eq 3) { & ($env:BASE + "\Get.ps1") }
if ($Ans -eq 4) { & ($env:BASE + "\Go.ps1") }
if ($Ans -eq 5) { & ($env:BASE + "\Out.ps1") }
if ($Ans -eq 6) { & ($env:BASE + "\Put.ps1") }
if ($Ans -eq 7) { & ($env:BASE + "\Repair.ps1") }
if ($Ans -eq 8) { & ($env:BASE + "\Run.ps1") }
if ($Ans -eq 9) { & ($env:BASE + "\Test.ps1") }
if ($Ans -eq 10) { & ($env:BASE + "\Update.ps1") }
if ($Ans -eq 11) { & ($env:BASE + "\Write.ps1") }
