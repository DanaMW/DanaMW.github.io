<#
.SYNOPSIS
        Base
        Created By: Dana Meli
        Created Date: April, 2019
        Last Modified Date: February 01, 2020
.DESCRIPTION
        This script lists all my scripts that are BASE of groups.
        Such as Edit, Find, Get, Go, Out, Put, Repair, Run, Test, Update, Write.
.EXAMPLE
        Base.ps1
.NOTES
        Still under development.
#>
$FileVersion = "0.1.8"
Set-Location $env:BASE.substring(0, 3)
Set-Location $env:BASE
$List = @("Edit.ps1", "Find.ps1", "Get.ps1", "Go.ps1", "Out.ps1", "Put.ps1", "Remove.ps1", "Repair.ps1", "Run.ps1", "Test.ps1", "Update.ps1", "Write.ps1")
$Count = $List.Count
$i = 0
$Count--
Clear-Host
$p = 1
[Console]::SetCursorPosition(0, $p); WC ""; $p++
[Console]::SetCursorPosition(0, $p); WC "Base $FileVersion"; $p++
[Console]::SetCursorPosition(0, $p); WC "Listing your BASE group scripts."; $p++
[Console]::SetCursorPosition(0, $p); WC "~red~#~~darkred~=-=-=-=-=-=-=-=-=-~~red~#~"; $p++
while ($i -le $Count) {
        [Console]::SetCursorPosition(0, $p)
        Say -NoNewLine -ForeGroundColor darkred "|"
        Say -NoNewLine -ForeGroundColor cyan "["
        Say -NoNewLine -ForeGroundColor white "$i"
        Say -NoNewLine -ForeGroundColor cyan "] "
        [Console]::SetCursorPosition(6, $p)
        Say -NoNewLine -ForeGroundColor green $List[$i]
        [Console]::SetCursorPosition(19, $p);
        Say -NoNewLine -ForeGroundColor darkred "|"
        $i++
        $p++
}
[Console]::SetCursorPosition(0, $p); WC "~red~#~~darkred~=-=-=-=-=-=-=-=-=-~~red~#~"; $p++
$menuPrompt = WCP "~darkcyan~[~~darkyellow~Select ~~white~0-$Count~~darkyellow~, ~~darkred~(~~white~Q~~darkred~)~~darkyellow~uit~~darkcyan~]~~white~: ~"
$Ans = Read-Host -Prompt $menuPrompt
if ($Ans -eq "Q") { return }
& ($env:BASE + "\" + $List[$Ans])
