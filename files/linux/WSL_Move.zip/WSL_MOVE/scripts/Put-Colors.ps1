$FileVersion = "Version: 0.0.8"
Say "Put Colors $FileVersion"
Say "These colors can be used with -ForeGroundColor or -BackGroundColor"
[enum]::GetValues([System.ConsoleColor]) | Foreach-Object { Write-Host $_ -ForegroundColor $_ }
Say ""
#Read In List
$BASE = $env:BASE
if (!($BASE)) { $BASE = Read-Host -Prompt "Enter the path to make your BASE directory (No trailing \)" }
if (!($BASE)) { Say -ForeGroundColor RED "The Environment Variable BASE must be set or this will not run, Set it or edit this script"; break }
Set-Location $BASE.substring(0, 3)
Set-Location $BASE
Clear-Host
$FileList = ($BASE + "\Put-Colors.list")
$Filetest = Test-Path -path $FileList
if (($Filetest)) { Say "Found Color List, Good." }
else { Say -ForeGroundColor "Error: You need the color list file."; return }
Say $fileVersion "Begin read list"
$LineCount = (Get-Content $FileList).count
$i = 0
#$host.UI.RawUI.ForegroundColor = "Gray"
While ($i -lt $LineCount) {
    $Read = $(Get-Content $FileList)[$i]
    if (!($Read)) { return }
    try { Say -ForeGroundColor $Read "$Read" -ErrorAction SilentlyContinue }
    catch { Say "$Read unknown." }
    $i++
}
$colors = [enum]::GetValues([System.ConsoleColor])
Foreach ($bgcolor in $colors) {
    Foreach ($fgcolor in $colors) { Write-Host "$fgcolor|"  -ForegroundColor $fgcolor -BackgroundColor $bgcolor -NoNewLine }
    Write-Host " on $bgcolor"
}
<#
Say "Done Writing EXE files to the Menu ini."
Say ""
$Filetest = Test-Path -path $FileTXT
if (($Filetest)) { Remove-Item –path $FileTXT }
$Filetest = Test-Path -path $FileCSV
if (($Filetest)) { Remove-Item –path $FileCSV }
Clear-Host
Start-Process "pwsh.exe" -ArgumentList ($BASE + "\BinMenu.ps1") -Verb RunAs
return
#>
<#
Read-Host -Prompt "Enter to continue"
while (1) {
    $ans = Read-Host -Prompt "Enter a HEX color code to see the color or (Q)uit"
    if ($ans = "Q") { return }
    else {
        $ShowColor = [System.Drawing.ColorTranslator]::FromHtml($ans)
        $ShowColor | Format-List *
        Say -ForegroundColor $ShowColor "This is your color."
        Start-Sleep -s 15
        Clear-Host
    }
}
#>
