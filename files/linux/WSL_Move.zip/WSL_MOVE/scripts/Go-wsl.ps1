$FileVersion = "0.2.2"
Clear-Host
WC "~WHITE~Go wsl ~~RED~$FileVersion~"
WC "~WHITE~Setting your location to wsl Ubuntu~"
Set-Location \\wsl$\Ubuntu
