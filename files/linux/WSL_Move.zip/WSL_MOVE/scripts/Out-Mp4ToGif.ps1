[CmdletBinding()]
Param(
    [Parameter()]
    [string]$origin,
    [Parameter()]
    [string]$destination,
    [Parameter()]
    [string]$options = $null,
    [Parameter()]
    [string]$log = $null
)

$palette = "${env:TEMP}\palette.png"
$filters = if ($options.Length -gt 0) { $options } else { "scale=512:-1:flags=bicubic" }
$logLevel = if ($log.Length -gt 0) { $log } else { "panic" }

ffmpeg -v $logLevel -i $origin -vf "$filters,palettegen" -y $palette
ffmpeg -v $logLevel -i $origin -i $palette -lavfi "$filters [x]; [x][1:v] paletteuse" -y $destination

<#
Syntax
{directory-where-script-is-saved}>.\Create-Gif.ps1 {origin-video} {destination-gif} -log {optional logging level} -options {optional filter options}
Examples
# Basic Usage
D:\Desktop>.\Create-Gif.ps1 D:\Captures\demo.mp4 D:\Captures\demo.gif
# With Options
D:\Desktop>.\Create-Gif.ps1 D:\Captures\demo.mp4 D:\Captures\demo.gif -options "trim=start=5:end=10,scale=320:-1:flags=lanczos"
# With Log
D:\Desktop>.\Create-Gif.ps1 D:\Captures\demo.mp4 D:\Captures\demo.gif -log debug
#>
