#Working Pause (Put-Pause.ps1)
$n_start = 0
$n_max = 5000
Say -NoNewLine "Requires Input: "
while ($n_start -lt $n_max) {
    Start-Sleep -MilliSeconds 100
    if ($host.UI.RawUI.KeyAvailable) {
        $key = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyUp,IncludeKeyDown")
        if ($key.KeyDown -eq 1) {
            $ans = $Key.Character
            $n_start = $n_max
        }
    }
    $n_start = ($n_start + 100)
}
Say $ans

# Second Set
Say "Press any key to continue..."
[void][System.Console]::ReadKey($true)

# Multi Key Pause
Function MyIn {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $False)]
        [string]$Prompt
    )
    Process {
        While (1) {
            Say -NoNewLine ($Prompt + " ")
            [Console]::ReadKey($true) | ForEach-Object {
                If ($_ -eq [char]13)
                { Write-Output $ReadKey }
                else {
                    $ReadKey = ($ReadKey + $_)
                    Continue
                }
            }
        }
        Finally { Write-Output $ReadKey }
    }
}
