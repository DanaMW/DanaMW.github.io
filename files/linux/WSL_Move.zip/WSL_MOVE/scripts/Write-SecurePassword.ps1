$MyArgs = "$args"
$FileVersion = "0.0.7"
if ($MyArgs -eq "/?") {
    Say "WriteSecurePassword $FileVersion"
    Say ""
    Say "WriteSecurePassword <Optional-Path-File-To-Save>"
    Say "WriteSecurePassword alone writes the default file/location"
    Say ""
    return
}
if ($env:USERDOMAIN -eq "TINMAN") {
    Say "Write-SecurePassword $FileVersion"
    if (!($MyArgs)) {
        $MyArgs = "D:\Downloads\Tinman-PasswordSecure.txt"
    }
    $Filetest = Test-Path -Path $MyArgs
    if ($Filetest -eq $True) {
        $Random = Get-Random -Maximum 1000
        $File = ("D:\Downloads\Tinman-PasswordSecure" + $Random + ".txt")
        Say "File Exists, Renaming to $File"
        Rename-Item -Path $MyArgs -NewName $file
    }
    Say "Writing $MyArgs"
    Say ""
    Read-Host -Credential $env:USERNAME -AsSecureString | ConvertFrom-SecureString | Out-File $MyArgs
    Say ""
    Say "Completed Successfully"
    return
}
if ($env:USERDOMAIN -eq "TORCHLIGHT") {
    Say "Write-SecurePassword $FileVersion"
    if (!($MyArgs)) {
        $MyArgs = "D:\Downloads\TorchLight-PasswordSecure.txt"
    }
    $Filetest = Test-Path -Path $MyArgs
    if ($Filetest -eq $True) {
        $Random = Get-Random -Maximum 1000
        $File = ("D:\Downloads\TorchLight-PasswordSecure" + $Random + ".txt")
        Say "File Exists, Renaming to $File"
        Rename-Item -Path $MyArgs -NewName $file
    }
    Say "Writing $MyArgs"
    Say ""
    Read-Host -Credential $env:USERNAME -AsSecureString | ConvertFrom-SecureString | Out-File $MyArgs
    Say ""
    Say "Completed Successfully"
    return
}
