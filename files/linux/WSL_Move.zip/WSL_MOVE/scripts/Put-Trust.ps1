$FileVersion = "0.0.4"
Say "Put-Trust $FileVersion"
Say "Setting Repository PSGallery to Trusted"
Say "Set-PSRepository -name PSGallery -InstallationPolicy Trusted"
Set-PSRepository -name PSGallery -InstallationPolicy Trusted
