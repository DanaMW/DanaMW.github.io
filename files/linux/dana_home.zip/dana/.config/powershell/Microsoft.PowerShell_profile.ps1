function prompt {
    Write-Host -NoNewline -ForegroundColor darkcyan "["
    Write-Host -NoNewline -ForegroundColor darkyellow "$ENV:LOGNAME"
    Write-Host -NoNewLine -ForeGroundColor white "@"
    Write-Host -NoNewline -ForegroundColor darkyellow "$ENV:MYDOMAIN"
    Write-Host -NoNewline -ForegroundColor darkcyan "]"
    Write-Host -NoNewline -ForegroundColor darkcyan "["
    Write-Host -NoNewline -ForegroundColor white $(Get-Location)
    Write-Host -NoNewline -ForegroundColor darkcyan "]"
    if ($nestedpromptlevel -ge 1) { Write-Host -NoNewline -ForegroundColor cyan ">>" }
    Write-Host -NoNewline -ForegroundColor white ":"
    return " "
}
WC "~darkcyan~[~~darkyellow~PowerShell Core~~darkcyan~][~~red~Microsoft.PowerShell_Profile.ps1~~darkcyan~]~~white~: Loaded Prompt~";
Get-SmallVer;
WC "~darkcyan~[~~darkyellow~Welcome to ~~red~Ubuntu~~white~@~~red~$ENV:MYDOMAIN~~darkcyan~]~";
