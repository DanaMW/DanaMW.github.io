// ==UserScript==
// @name         Fix Ij8KCd Styling On Google
// @version      0.0.2
// @namespace    https://raw.githubusercontent.com/danamw/discordweb/master/GoogleDark.user.js
// @description  It strips style for me.
// @author       Dana L. Meli-Wischman
// @icon         https://danamw.github.io/img/eyeball128.png
// @match        https://*.google.com/*
// @grant        none
// ==/UserScript==
/* jshint esversion: 6 */
/* require-jsdoc  */

(function() {
    'use strict';

    const defaultBg = '#4c0000';
    const defaultOpacity = '0.1';
    const hoverOpacity = '1';

    const applyBehavior = (el) => {
        if (el.dataset.styledByScript) return;
        el.dataset.styledByScript = 'true';

        // Set initial state
        el.style.setProperty('background', defaultBg, 'important');
        el.style.setProperty('opacity', defaultOpacity, 'important');
        el.style.setProperty('transition', 'opacity 0.5s ease', 'important');

        // Handle hover in
        el.addEventListener('mouseenter', () => {
            el.style.setProperty('opacity', hoverOpacity, 'important');
        });

        // Handle hover out
        el.addEventListener('mouseleave', () => {
            el.style.setProperty('opacity', defaultOpacity, 'important');
        });
    };

    const scanElements = () => {
        const elements = document.querySelectorAll('div.acUsEb .Ij8KCd');
        elements.forEach(applyBehavior);
    };

    const observer = new MutationObserver(scanElements);

    if (document.documentElement) {
        observer.observe(document.documentElement, {
            childList: true,
            subtree: true
        });
    }

    window.addEventListener('DOMContentLoaded', scanElements);
    window.addEventListener('load', scanElements);
    setInterval(scanElements, 200);
})();